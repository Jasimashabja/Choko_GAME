Phase 3.0 centralizes boss definitions, balance tables, and canon dialogue in scripts/boss_data.gd and saves persistent campaign progress to user://choko_save.json.
