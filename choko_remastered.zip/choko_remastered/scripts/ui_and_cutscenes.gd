extends RefCounted

## CHOKO — Phase 4.3: High-Craft Indie Title Menu (Instant-Start STORY / BOSSES / SETTINGS),
## Non-Spoiling Shaft Transitions, Typewriter Portrait Cutscenes, Souls-Like Trailing HP Bar,
## Low-Health Heartbeat Vignette, Scalable Multi-Touch & Laptop Brainrot Respawn.

const BossData := preload("res://scripts/boss_data.gd")
const BossController := preload("res://scripts/boss_controller.gd")
const SpriteBank := preload("res://scripts/sprite_bank.gd")

const W := 640.0
const H := 360.0
const C_BG := Color("#080a12")
const C_TEXT := Color("#f2ead5")
const C_MUTED := Color("#aba4b8")
const C_DIM := Color("#696578")
const C_WARM := Color("#e5ad68")
const C_WARM_HI := Color("#ffd999")
const C_RED := Color("#eb6d63")
const C_CYAN := Color("#77d8d0")
const C_CYAN_HI := Color("#c7fff4")
const C_COAL := Color("#3b3c49")

# --- TITLE / MAIN MENU (SLEEK CLEAN STACK: STORY | BOSSES | SETTINGS) ---
const RECT_TITLE_DIFF := Rect2(364, 96, 232, 36)
const RECT_TITLE_BTNS := [
	Rect2(364, 144, 232, 46), # 0: STORY (Instant Start — Zero Spoilers!)
	Rect2(364, 200, 232, 46), # 1: BOSSES (Boss Rush & Practice)
	Rect2(364, 256, 232, 46), # 2: SETTINGS (Audio, Touch & FX)
]
const RECT_TITLE_ENDING := Rect2(20, 316, 174, 30)

# --- BOSSES SELECT SCREEN ---
const RECT_BOSSES_BACK := Rect2(20, 10, 82, 28)
const RECT_BOSSES_DIFF := Rect2(318, 10, 134, 28)
const RECT_HUB_CARDS := [
	Rect2(20, 62, 294, 54),  # farhan
	Rect2(326, 62, 294, 54), # allan
	Rect2(20, 122, 294, 54), # john_paul
	Rect2(326, 122, 294, 54),# aaron
	Rect2(20, 182, 294, 54), # grandfather
	Rect2(326, 182, 294, 54),# dead_cat
]
const RECT_HUB_PRACTICE := Rect2(20, 246, 600, 44)
const RECT_HUB_STORY_BTN := Rect2(20, 298, 294, 38)
const RECT_HUB_SETTINGS_BTN := Rect2(326, 298, 294, 38)

# --- CUTSCENES & POST-GRANDFATHER BRANCH ---
const RECT_CUTSCENE_SKIP := Rect2(536, 12, 88, 30)
const RECT_POST_GF_SECRET := Rect2(28, 266, 284, 54)
const RECT_POST_GF_ESCAPE := Rect2(328, 266, 284, 54)

# --- PAUSE OVERLAY ---
const RECT_PAUSE_RESUME := Rect2(212, 126, 216, 36)
const RECT_PAUSE_RESTART := Rect2(212, 168, 216, 36)
const RECT_PAUSE_SETTINGS := Rect2(212, 210, 216, 36)
const RECT_PAUSE_MENU := Rect2(212, 252, 216, 36)

# --- SETTINGS & ACCESSIBILITY SCREEN (9 ROWS incl. DIFFICULTY) ---
const RECT_SETTINGS_ROWS := [
	Rect2(60, 52, 520, 25),
	Rect2(60, 81, 520, 25),
	Rect2(60, 110, 520, 25),
	Rect2(60, 139, 520, 25),
	Rect2(60, 168, 520, 25),
	Rect2(60, 197, 520, 25),
	Rect2(60, 226, 520, 25),
	Rect2(60, 255, 520, 25),
	Rect2(60, 284, 520, 25),
]
const RECT_SETTINGS_BACK := Rect2(226, 318, 188, 28)

# --- LAPTOP BRAINROT RESPAWN MENU ---
const RECT_RESPAWN_RETRY := Rect2(148, 292, 212, 36)
const RECT_RESPAWN_MENU := Rect2(372, 292, 120, 36)

# --- COMBAT MULTI-TOUCH POSITIONS ---
const BTN_PICK := Vector2(572.0, 278.0)
const BTN_COAL := Vector2(492.0, 224.0)
const BTN_DODGE := Vector2(572.0, 178.0)
const BTN_MINE := Vector2(404.0, 290.0)
const JOY_IDLE := Vector2(86.0, 278.0)

static func _text(canvas: CanvasItem, value: String, pos: Vector2, size: int, tint: Color, shadow: bool = true) -> void:
	var font := ThemeDB.fallback_font
	if shadow:
		canvas.draw_string(font, pos + Vector2(1.0, 1.5), value, HORIZONTAL_ALIGNMENT_LEFT, -1.0, size, Color(0.02, 0.02, 0.04, tint.a * 0.88))
	canvas.draw_string(font, pos, value, HORIZONTAL_ALIGNMENT_LEFT, -1.0, size, tint)

static func _text_centered(canvas: CanvasItem, value: String, center_x: float, baseline_y: float, size: int, tint: Color) -> void:
	var font := ThemeDB.fallback_font
	var w := font.get_string_size(value, HORIZONTAL_ALIGNMENT_LEFT, -1.0, size).x
	_text(canvas, value, Vector2(center_x - w * 0.5, baseline_y), size, tint)

static func _draw_panel(canvas: CanvasItem, r: Rect2, bg: Color, border: Color, top_accent: Color) -> void:
	canvas.draw_rect(Rect2(r.position + Vector2(2, 3), r.size), Color(0.0, 0.0, 0.0, 0.50))
	canvas.draw_rect(r, bg)
	canvas.draw_rect(r, border, false, 1.0)
	canvas.draw_rect(Rect2(r.position.x, r.position.y, r.size.x, 2.5), top_accent)

static func _draw_wrapped(canvas: CanvasItem, text: String, origin: Vector2, max_w: float, line_h: float, size: int, tint: Color) -> void:
	var font := ThemeDB.fallback_font
	var words := text.split(" ")
	var line := ""
	var y := origin.y
	for w in words:
		var word_str := str(w)
		var candidate: String = word_str if line.is_empty() else (line + " " + word_str)
		if font.get_string_size(candidate, HORIZONTAL_ALIGNMENT_LEFT, -1.0, size).x > max_w and not line.is_empty():
			_text(canvas, line, Vector2(origin.x, y), size, tint)
			y += line_h
			line = word_str
		else:
			line = candidate
	if not line.is_empty():
		_text(canvas, line, Vector2(origin.x, y), size, tint)

static func _draw_title_bg_animated(canvas: CanvasItem, sprites: SpriteBank, elapsed: float, dim_alpha: float = 0.0) -> void:
	var ttex: Texture2D = sprites.get_title_tex() if sprites != null else null
	if ttex != null:
		canvas.draw_texture_rect(ttex, Rect2(0, 0, W, H), false)
	else:
		canvas.draw_rect(Rect2(0, 0, W, H), Color("#0b0e18"))
	# Animated swaying mine lanterns & warm volumetric cones
	for lx in [76.0, 564.0]:
		var sw := sin(elapsed * 1.4 + lx * 0.02) * 5.0
		canvas.draw_line(Vector2(lx, 0), Vector2(lx + sw, 68), Color("#635766"), 2.0)
		var cone := PackedVector2Array([
			Vector2(lx - 6 + sw, 68), Vector2(lx + 6 + sw, 68),
			Vector2(lx + 58 + sw * 2.2, 250), Vector2(lx - 58 + sw * 2.2, 250)
		])
		canvas.draw_colored_polygon(cone, Color(1.0, 0.72, 0.36, 0.075))
		var pulse := 0.85 + 0.15 * sin(elapsed * 4.0 + lx)
		canvas.draw_circle(Vector2(lx + sw, 72), 22.0, Color(1.0, 0.58, 0.24, 0.18 * pulse))
		canvas.draw_rect(Rect2(lx + sw - 5, 66, 10, 14), Color("#3c3340"))
		canvas.draw_rect(Rect2(lx + sw - 3, 68, 6, 10), Color("#ffd694"))
	# Rising glowing quarry embers
	for i in range(26):
		var ex := fposmod(float(i * 61 + 29) + sin(elapsed * 1.2 + float(i)) * 16.0, W)
		var ey := H - fposmod(elapsed * (16.0 + float(i % 5) * 5.0) + float(i * 37), H)
		var a := 0.58 * clampf(ey / 120.0, 0.0, 1.0)
		canvas.draw_rect(Rect2(ex, ey, 2.0, 2.0), Color(1.0, 0.68, 0.34, a))
	if dim_alpha > 0.0:
		canvas.draw_rect(Rect2(0, 0, W, H), Color(0.03, 0.04, 0.07, dim_alpha))

# =============================================================================
# 1. CLEAN HIGH-CRAFT INDIE TITLE MENU (STORY INSTANT-START | BOSSES | SETTINGS)
# =============================================================================

static func draw_title_menu(canvas: CanvasItem, sprites: SpriteBank, save_data: Dictionary, selected_idx: int, elapsed: float) -> void:
	_draw_title_bg_animated(canvas, sprites, elapsed, 0.14)

	# Atmospheric dark-gradient framing on right half for ultra-clean menu contrast
	canvas.draw_rect(Rect2(340, 0, 300, H), Color(0.03, 0.04, 0.08, 0.52))
	canvas.draw_line(Vector2(340, 26), Vector2(340, 334), Color(0.90, 0.68, 0.42, 0.22), 1.0)

	# Left Hero Composition: Choko standing by a glowing coal seam on the underground railway
	var choko_pos := Vector2(168.0, 238.0 + sin(elapsed * 2.4) * 2.0)
	var lp := 0.85 + 0.15 * sin(elapsed * 3.6)
	canvas.draw_circle(choko_pos + Vector2(0, 14), 54.0, Color(1.0, 0.58, 0.26, 0.10 * lp))
	canvas.draw_rect(Rect2(choko_pos.x - 24, choko_pos.y + 34, 48, 8), Color(0.0, 0.0, 0.0, 0.42))
	if sprites != null and sprites.has_sheet("choko"):
		var frame_c := 0 if int(elapsed * 2.0) % 5 != 4 else 1
		sprites.draw_frame(canvas, "choko", frame_c, 0, 48, 48, choko_pos, false, Color.WHITE, 1.85)

	# Bold Left/Top Title Lockup (cinematic indie silhouette)
	_text(canvas, "CHOKO", Vector2(44, 96), 46, C_WARM_HI)
	canvas.draw_rect(Rect2(46, 106, 212, 2), C_WARM)
	_text(canvas, "REMASTERED", Vector2(46, 126), 15, C_CYAN_HI)
	_text(canvas, "THE LAST SHIFT  •  UNDERGROUND QUARRY ESCAPE", Vector2(46, 144), 9, C_MUTED)

	# Determine non-spoiling STORY subtitle (never reveals boss names!)
	var cleared: Array = save_data.get("cleared", [])
	var main_count := 0
	for cid in BossData.CAMPAIGN_ORDER:
		if cleared.has(cid):
			main_count += 1
	var gf_cleared := cleared.has("grandfather")
	var dc_cleared := cleared.has("dead_cat")

	var story_sub := "BEGIN THE ESCAPE"
	if main_count > 0 and main_count < 5:
		var rom: String = str(["I", "II", "III", "IV", "V"][clampi(main_count, 0, 4)])
		story_sub = "CONTINUE  •  SHAFT " + rom
	elif gf_cleared and not dc_cleared:
		story_sub = "CONTINUE  •  BLINKING LIGHT"
	elif dc_cleared:
		story_sub = "NEW ESCAPE  •  ALL SHAFTS CLEARED"

	# Difficulty Mode Toggle Pill right above STORY / BOSSES / SETTINGS
	var diff_mode := str(save_data.get("settings", {}).get("difficulty", "nightmare"))
	var is_nm := (diff_mode != "easy")
	var dr := RECT_TITLE_DIFF
	var d_bg := Color("#3b191d", 0.94) if is_nm else Color("#142e2a", 0.94)
	var d_ac := C_RED if is_nm else Color("#5ce6a8")
	_draw_panel(canvas, dr, d_bg, d_ac, d_ac)
	_text(canvas, "DIFFICULTY:", dr.position + Vector2(12, 16), 9, C_MUTED)
	_text(canvas, "NIGHTMARE" if is_nm else "EASY MODE", dr.position + Vector2(82, 17), 12, d_ac)
	_text(canvas, "TAP TO SWITCH", dr.position + Vector2(158, 16), 8, C_TEXT)
	var d_desc := "Souls-like combos, lead-aim & 2-3♥ strikes" if is_nm else "Forgiving HP, slower attacks, capped damage"
	_text(canvas, d_desc, dr.position + Vector2(12, 30), 8, Color(0.86, 0.84, 0.88, 0.82))
	var items := [
		["STORY", story_sub, C_WARM_HI, Color("#3a261e")],
		["BOSSES", "BOSS RUSH & PRACTICE", C_CYAN_HI, Color("#172733")],
		["SETTINGS", "AUDIO, TOUCH & DISPLAY", Color("#ddd2f0"), Color("#221e33")],
	]

	for i in range(3):
		var r: Rect2 = RECT_TITLE_BTNS[i]
		var it: Array = items[i]
		var is_sel := (selected_idx == i)
		var ac: Color = it[2]
		var base_bg: Color = it[3]
		var shift_x := -6.0 if is_sel else 0.0
		var draw_r := Rect2(r.position.x + shift_x, r.position.y, r.size.x, r.size.y)
		var bg := Color(base_bg.r + 0.08, base_bg.g + 0.08, base_bg.b + 0.10, 0.96) if is_sel else Color(base_bg.r, base_bg.g, base_bg.b, 0.86)
		_draw_panel(canvas, draw_r, bg, ac if is_sel else Color("#3c435c"), ac)
		canvas.draw_rect(Rect2(draw_r.position.x, draw_r.position.y, 5 if is_sel else 3, draw_r.size.y), ac)
		_text(canvas, str(it[0]), draw_r.position + Vector2(18, 22), 16, ac if is_sel else C_TEXT)
		_text(canvas, str(it[1]), draw_r.position + Vector2(18, 37), 9, C_TEXT if is_sel else C_MUTED)
		if is_sel:
			var arrow_x := draw_r.position.x + draw_r.size.x - 22.0 + sin(elapsed * 8.0) * 2.5
			_text(canvas, "▶", Vector2(arrow_x, draw_r.position.y + 28.0), 13, ac)

	# Post-completion optional Plane Escape replay pill (non-intrusive, bottom-left)
	if gf_cleared:
		var er := RECT_TITLE_ENDING
		_draw_panel(canvas, er, Color("#182c38", 0.92), Color("#46788c"), C_CYAN_HI)
		_text_centered(canvas, "★ PLANE ESCAPE ENDING", er.position.x + er.size.x * 0.5, er.position.y + 19.0, 10, C_CYAN_HI)

	_text(canvas, "CHOKO - REMASTERED  •  EASY & NIGHTMARE MODES", Vector2(366, 336), 9, Color(0.75, 0.72, 0.80, 0.68))

# =============================================================================
# 2. ATMOSPHERIC UNDERGROUND SHAFT TRANSITION CARD (ZERO SPOILERS AHEAD)
# =============================================================================

static func draw_shaft_transition(canvas: CanvasItem, boss_id: String, timer: float, duration: float, elapsed: float) -> void:
	canvas.draw_rect(Rect2(0, 0, W, H), Color("#06080f"))
	var info := BossData.get_shaft_transition(boss_id)
	var bcfg := BossData.get_boss(boss_id)
	var ac: Color = bcfg.get("accent_hi", C_WARM_HI)
	var prog := 1.0 - clampf(timer / maxf(0.01, duration), 0.0, 1.0)
	var alpha := clampf(prog * 3.5, 0.0, 1.0) * clampf((1.0 - prog) * 3.5, 0.0, 1.0)
	alpha = maxf(alpha, 0.25 if prog > 0.15 and prog < 0.85 else alpha)

	# Subtle animated descending vertical mine-shaft guide rails
	var rail_y := fposmod(elapsed * 75.0, 40.0)
	canvas.draw_line(Vector2(120, 0), Vector2(120, H), Color(0.28, 0.30, 0.38, 0.35 * alpha), 2.0)
	canvas.draw_line(Vector2(520, 0), Vector2(520, H), Color(0.28, 0.30, 0.38, 0.35 * alpha), 2.0)
	for i in range(-1, 10):
		var y := float(i) * 40.0 + rail_y
		canvas.draw_line(Vector2(114, y), Vector2(126, y), Color(0.55, 0.52, 0.60, 0.35 * alpha), 1.5)
		canvas.draw_line(Vector2(514, y), Vector2(526, y), Color(0.55, 0.52, 0.60, 0.35 * alpha), 1.5)

	_text_centered(canvas, str(info.get("kicker", "UNDERGROUND")), 320.0, 148.0, 12, Color(ac.r, ac.g, ac.b, alpha))
	canvas.draw_rect(Rect2(200, 158, 240, 2), Color(ac.r, ac.g, ac.b, alpha * 0.65))
	_text_centered(canvas, str(info.get("title", "")), 320.0, 188.0, 20, Color(C_TEXT.r, C_TEXT.g, C_TEXT.b, alpha))
	_text_centered(canvas, str(info.get("sub", "")), 320.0, 214.0, 11, Color(C_MUTED.r, C_MUTED.g, C_MUTED.b, alpha))

# =============================================================================
# 3. BOSSES & PRACTICE SELECT SCREEN (PORTRAIT CARDS + MASTERY TRACKING)
# =============================================================================

static func draw_bosses_screen(canvas: CanvasItem, sprites: SpriteBank, save_data: Dictionary, selected_idx: int, elapsed: float) -> void:
	_draw_title_bg_animated(canvas, sprites, elapsed, 0.72)

	canvas.draw_rect(Rect2(0, 0, W, 48), Color("#111524", 0.96))
	canvas.draw_rect(Rect2(0, 48, W, 2), C_CYAN)
	_draw_panel(canvas, RECT_BOSSES_BACK, Color("#1f2538"), Color("#434e6e"), C_MUTED)
	_text_centered(canvas, "◀ MENU", RECT_BOSSES_BACK.position.x + 41.0, RECT_BOSSES_BACK.position.y + 19.0, 11, C_TEXT)
	_text(canvas, "BOSSES & PRACTICE", Vector2(116, 30), 16, C_CYAN_HI)
	var b_diff := str(save_data.get("settings", {}).get("difficulty", "nightmare"))
	var b_is_nm := (b_diff != "easy")
	var bdr := RECT_BOSSES_DIFF
	_draw_panel(canvas, bdr, Color("#3a191e") if b_is_nm else Color("#142e2a"), C_RED if b_is_nm else Color("#5ce6a8"), C_RED if b_is_nm else Color("#5ce6a8"))
	_text_centered(canvas, "MODE: NIGHTMARE" if b_is_nm else "MODE: EASY", bdr.position.x + bdr.size.x * 0.5, bdr.position.y + 18.0, 10, C_RED if b_is_nm else Color("#5ce6a8"))

	var cleared_list: Array = save_data.get("cleared", [])
	var mastery: Dictionary = save_data.get("mastery", {})
	var gf_cleared := cleared_list.has("grandfather")
	var main_count := 0
	for cid in BossData.CAMPAIGN_ORDER:
		if cleared_list.has(cid):
			main_count += 1
	_text(canvas, "CLEARED " + str(main_count) + "/5" + (" + SECRET" if cleared_list.has("dead_cat") else ""), Vector2(462, 29), 11, C_WARM_HI if main_count >= 5 else C_TEXT)

	var ids := ["farhan", "allan", "john_paul", "aaron", "grandfather", "dead_cat"]
	for i in range(ids.size()):
		var bid: String = ids[i]
		var r: Rect2 = RECT_HUB_CARDS[i]
		var info := BossData.get_boss(bid)
		var is_secret := (bid == "dead_cat")
		var unlocked := (not is_secret) or gf_cleared
		var is_cleared := cleared_list.has(bid)
		var is_sel := (selected_idx == i)
		var accent: Color = info.get("accent", C_WARM)

		var bg := Color("#191e2e", 0.95) if unlocked else Color("#11131d", 0.92)
		if is_sel:
			bg = Color("#252d46", 0.98)
		var border := C_WARM_HI if is_sel else (Color("#363f59") if unlocked else Color("#232533"))
		_draw_panel(canvas, r, bg, border, accent if unlocked else Color("#353442"))
		canvas.draw_rect(Rect2(r.position.x, r.position.y, 4, r.size.y), accent if unlocked else Color("#353442"))

		var port_rect := Rect2(r.position.x + 10, r.position.y + 6, 42, 42)
		canvas.draw_rect(port_rect, Color("#0d1019"))
		if unlocked and sprites != null:
			var ptex: Texture2D = sprites.get_portrait_by_id(bid)
			if ptex != null:
				canvas.draw_texture_rect(ptex, port_rect, false)
		else:
			canvas.draw_rect(port_rect, Color("#242736"), false, 1.0)
			_text_centered(canvas, "?", port_rect.position.x + 21.0, port_rect.position.y + 28.0, 18, C_DIM)

		var tx := r.position.x + 60.0
		if unlocked:
			_text(canvas, str(i + 1) + ". " + str(info["name"]), Vector2(tx, r.position.y + 21.0), 13, C_TEXT)
			if is_cleared:
				var bm: Dictionary = mastery.get(bid, {})
				var best_t := int(roundf(float(bm.get("best_time", 0.0))))
				var no_hit := bool(bm.get("no_hit", false))
				var best_pd := int(bm.get("best_pd", 0))
				var badge := ("★ NO-HIT " if no_hit else "CLEARED ") + (str(best_t) + "s" if best_t > 0 else "")
				_text(canvas, badge, Vector2(r.position.x + r.size.x - 102.0, r.position.y + 20.0), 10, C_WARM_HI if no_hit else C_CYAN_HI)
				_text(canvas, "HP " + str(int(info["max_hp"])) + " • POSTURE " + str(int(info["max_posture"])) + " • PD " + str(best_pd), Vector2(tx, r.position.y + 40.0), 9, C_MUTED)
			else:
				_text(canvas, str(info["arena_name"]), Vector2(tx, r.position.y + 39.0), 10, C_MUTED)
				if is_secret:
					_text(canvas, "SECRET", Vector2(r.position.x + r.size.x - 56.0, r.position.y + 20.0), 10, Color("#9ecae8"))
		else:
			_text(canvas, "6. ???  [LOCKED]", Vector2(tx, r.position.y + 21.0), 13, C_DIM)
			_text(canvas, "Defeat Grandfather to unlock the Sealed Catacomb", Vector2(tx, r.position.y + 39.0), 10, C_DIM)

	var pr := RECT_HUB_PRACTICE
	var p_bg := Color("#162330", 0.95) if selected_idx != 6 else Color("#22364a", 0.98)
	_draw_panel(canvas, pr, p_bg, C_WARM_HI if selected_idx == 6 else Color("#2f4c5e"), C_CYAN)
	var sp_rect := Rect2(pr.position.x + 10, pr.position.y + 6, 32, 32)
	if sprites != null:
		var stex: Texture2D = sprites.get_portrait_by_id("sentinel")
		if stex != null:
			canvas.draw_texture_rect(stex, sp_rect, false)
	_text(canvas, "PRACTICE: QUARRY SENTINEL", pr.position + Vector2(52, 20), 12, C_CYAN_HI)
	_text(canvas, "Non-Campaign Training Construct  •  Test 4-Way Movement, Perfect Dodge & Counter-Strike", pr.position + Vector2(52, 36), 10, C_MUTED)

	_draw_panel(canvas, RECT_HUB_STORY_BTN, Color("#3a251d", 0.94), Color("#784f3c"), C_WARM_HI)
	_text_centered(canvas, "PLAY STORY MODE", RECT_HUB_STORY_BTN.position.x + 147.0, RECT_HUB_STORY_BTN.position.y + 24.0, 11, C_TEXT)

	_draw_panel(canvas, RECT_HUB_SETTINGS_BTN, Color("#201e30", 0.94), Color("#4b4569"), Color("#d4c8e8"))
	_text_centered(canvas, "SETTINGS", RECT_HUB_SETTINGS_BTN.position.x + 147.0, RECT_HUB_SETTINGS_BTN.position.y + 24.0, 11, C_TEXT)

	var sel_ids := ["farhan", "allan", "john_paul", "aaron", "grandfather", "dead_cat", "sentinel"]
	var sel_bid: String = sel_ids[clampi(selected_idx, 0, sel_ids.size() - 1)]
	var hint := str(BossData.get_boss(sel_bid).get("mechanic_hint", ""))
	if sel_bid == "dead_cat" and not gf_cleared:
		hint = "DEFEAT GRANDFATHER TO UNLOCK THE SEALED CATACOMB"
	_text_centered(canvas, hint, W * 0.5, 353.0, 10, Color(0.92, 0.88, 0.74, 0.88))

# =============================================================================
# 4. SETTINGS & ACCESSIBILITY SCREEN (8 INTERACTIVE ROWS)
# =============================================================================

static func draw_settings(canvas: CanvasItem, settings: Dictionary, selected_row: int) -> void:
	canvas.draw_rect(Rect2(0, 0, W, H), Color(0.02, 0.025, 0.05, 0.92))
	_draw_panel(canvas, Rect2(36, 10, 568, 344), Color("#141826"), Color("#38425e"), C_CYAN)
	_text(canvas, "SETTINGS & ACCESSIBILITY", Vector2(60, 40), 16, C_TEXT)
	_text(canvas, "Tap any row to cycle  •  Saved automatically", Vector2(342, 39), 10, C_MUTED)

	var music_v := int(roundf(float(settings.get("music_vol", 0.75)) * 100.0))
	var sfx_v := int(roundf(float(settings.get("sfx_vol", 0.85)) * 100.0))
	var op_v := int(roundf(float(settings.get("touch_opacity", 0.85)) * 100.0))
	var sc_v := float(settings.get("touch_scale", 1.0))
	var sc_str := "0.85X" if sc_v < 0.92 else ("1.15X" if sc_v > 1.08 else "1.00X")
	var sh_v := float(settings.get("shake_scale", 1.0))
	var sh_str := "OFF" if sh_v <= 0.05 else ("LOW" if sh_v < 0.75 else "FULL")
	var fl_v := float(settings.get("flash_scale", 1.0))
	var fl_str := "OFF" if fl_v <= 0.05 else ("LOW" if fl_v < 0.75 else "FULL")
	var hap_str: String = "ON" if bool(settings.get("haptics", true)) else "OFF"
	var dbg_str: String = "ON" if bool(settings.get("debug_hitboxes", false)) else "OFF"
	var diff_str: String = "EASY" if str(settings.get("difficulty", "nightmare")) == "easy" else "NIGHTMARE"

	var rows := [
		["DIFFICULTY MODE", diff_str],
		["MUSIC VOLUME", str(music_v) + "%"],
		["SFX VOLUME", str(sfx_v) + "%"],
		["TOUCH CONTROL OPACITY", str(op_v) + "%"],
		["TOUCH BUTTON SCALE", sc_str],
		["SCREEN SHAKE", sh_str],
		["HIT FLASH INTENSITY", fl_str],
		["VIBRATION / HAPTICS", hap_str],
		["HITBOX DEBUG OVERLAY (F3)", dbg_str],
	]

	for i in range(rows.size()):
		var r: Rect2 = RECT_SETTINGS_ROWS[i]
		var sel := (i == selected_row)
		canvas.draw_rect(r, Color("#262e47") if sel else Color("#1b2033"))
		var bar_c := C_WARM_HI if sel else (C_RED if (i == 0 and diff_str == "NIGHTMARE") else (Color("#5ce6a8") if i == 0 else C_CYAN))
		canvas.draw_rect(Rect2(r.position.x, r.position.y, 4, r.size.y), bar_c)
		var pair: Array = rows[i]
		_text(canvas, str(pair[0]), r.position + Vector2(16, 17), 11, C_TEXT)
		_text(canvas, "<  " + str(pair[1]) + "  >", r.position + Vector2(392, 17), 11, bar_c if i == 0 else (C_WARM_HI if sel else C_CYAN_HI))

	var rb := RECT_SETTINGS_BACK
	_draw_panel(canvas, rb, Color("#2f374d"), Color("#546080"), C_WARM)
	_text_centered(canvas, "DONE / BACK", rb.position.x + rb.size.x * 0.5, rb.position.y + 19.0, 12, C_TEXT)

# =============================================================================
# 5. TYPEWRITER CUTSCENES WITH 96x96 FRAMED PORTRAITS
# =============================================================================

static func draw_cutscene(canvas: CanvasItem, sprites: SpriteBank, kind: String, boss_id: String, lines: Array, line_idx: int, char_count: int, post_gf_choice: bool, elapsed: float, victory_summary: String = "") -> void:
	if kind == "plane_escape":
		_draw_plane_escape_art(canvas, elapsed)
	elif kind == "dead_cat_discovery":
		_draw_discovery_art(canvas, elapsed)
	elif kind == "story_prologue":
		_draw_title_bg_animated(canvas, sprites, elapsed, 0.34)
	else:
		canvas.draw_rect(Rect2(0, 0, W, H), Color(0.02, 0.025, 0.05, 0.58))

	var info := BossData.get_boss(boss_id)
	var accent: Color = info.get("accent", C_WARM)
	if kind == "story_prologue":
		canvas.draw_rect(Rect2(0, 0, W, 52), Color(0.04, 0.05, 0.09, 0.90))
		canvas.draw_rect(Rect2(0, 50, W, 2), C_WARM_HI)
		_text(canvas, "PROLOGUE  •  THE SHIFT", Vector2(24, 32), 17, C_WARM_HI)
	elif kind == "boss_intro":
		canvas.draw_rect(Rect2(0, 0, W, 68), Color(0.04, 0.05, 0.09, 0.92))
		canvas.draw_rect(Rect2(0, 66, W, 2), accent)
		_text(canvas, str(info["name"]), Vector2(24, 28), 20, info.get("accent_hi", C_TEXT))
		_text(canvas, str(info["title"]) + "  •  " + str(info["arena_name"]), Vector2(24, 46), 10, C_MUTED)
		_text(canvas, str(info.get("mechanic_hint", "")), Vector2(24, 60), 10, C_WARM_HI)
	elif kind == "boss_victory":
		canvas.draw_rect(Rect2(0, 0, W, 68), Color(0.04, 0.06, 0.10, 0.92))
		canvas.draw_rect(Rect2(0, 66, W, 2), C_CYAN)
		_text(canvas, str(info["name"]) + " DEFEATED", Vector2(24, 28), 19, C_CYAN_HI)
		_text(canvas, str(info["arena_name"]), Vector2(24, 46), 10, C_MUTED)
		if not victory_summary.is_empty():
			_text(canvas, victory_summary, Vector2(24, 60), 10, C_WARM_HI)
	elif kind == "dead_cat_discovery":
		canvas.draw_rect(Rect2(0, 0, W, 46), Color(0.03, 0.04, 0.07, 0.90))
		canvas.draw_rect(Rect2(0, 45, W, 1), Color("#6d97ba"))
		_text(canvas, "CONCEALED MAINTENANCE PASSAGE", Vector2(24, 30), 15, Color("#b8dcf5"))
	elif kind == "plane_escape":
		canvas.draw_rect(Rect2(0, 0, W, 46), Color(0.05, 0.06, 0.11, 0.72))
		_text(canvas, "THE LAST SHIFT  •  PLANE ESCAPE", Vector2(24, 30), 15, C_WARM_HI)

	if not post_gf_choice:
		var sr := RECT_CUTSCENE_SKIP
		_draw_panel(canvas, sr, Color("#1e2336"), Color("#434d6e"), C_MUTED)
		_text_centered(canvas, "SKIP", sr.position.x + sr.size.x * 0.5, sr.position.y + 20.0, 11, C_TEXT)

	if post_gf_choice:
		_draw_panel(canvas, Rect2(20, 184, 600, 152), Color(0.05, 0.06, 0.11, 0.96), Color("#464d6b"), C_WARM_HI)
		_text(canvas, "THE FREIGHT LIFT TO THE QUARRY AIRSTRIP IS OPEN.", Vector2(36, 214), 14, C_TEXT)
		_text(canvas, "Behind a cracked stone seam in the chapel wall, a tiny service light begins blinking...", Vector2(36, 238), 11, Color("#a9d2f0"))

		var r1 := RECT_POST_GF_SECRET
		_draw_panel(canvas, r1, Color("#182538"), Color("#496e94"), Color("#9ecae8"))
		_text_centered(canvas, "INVESTIGATE BLINKING LIGHT", r1.position.x + r1.size.x * 0.5, r1.position.y + 24.0, 12, Color("#e5f6ff"))
		_text_centered(canvas, "Hidden Secret Encounter", r1.position.x + r1.size.x * 0.5, r1.position.y + 42.0, 10, Color("#9ecae8"))

		var r2 := RECT_POST_GF_ESCAPE
		_draw_panel(canvas, r2, Color("#38271d"), Color("#7d563c"), C_WARM_HI)
		_text_centered(canvas, "BOARD PLANE ESCAPE", r2.position.x + r2.size.x * 0.5, r2.position.y + 24.0, 12, C_WARM_HI)
		_text_centered(canvas, "Escape Ending with Farhan", r2.position.x + r2.size.x * 0.5, r2.position.y + 42.0, 10, C_MUTED)
		return

	if line_idx >= 0 and line_idx < lines.size():
		var entry: Dictionary = lines[line_idx]
		var speaker := str(entry.get("speaker", ""))
		var full_body := str(entry.get("text", ""))
		var shown_body := full_body.substr(0, mini(char_count, full_body.length()))
		var box := Rect2(20, 232, 600, 114)
		_draw_panel(canvas, box, Color(0.05, 0.06, 0.11, 0.96), Color("#3c435e"), accent if speaker != "CHOKO" else C_CYAN)

		var text_x := 36.0
		var max_w := 564.0
		var fallback_p := "choko" if kind == "story_prologue" else boss_id
		var port: Texture2D = sprites.get_portrait_for_speaker(speaker, fallback_p) if sprites != null else null
		if port != null:
			canvas.draw_texture_rect(port, Rect2(30, 241, 96, 96), false)
			text_x = 140.0
			max_w = 464.0

		var spk_col := C_CYAN_HI if speaker == "CHOKO" else (C_WARM_HI if speaker == "FARHAN" else accent)
		_text(canvas, speaker, Vector2(text_x, 258), 14, spk_col)
		_draw_wrapped(canvas, shown_body, Vector2(text_x, 282), max_w, 19.0, 13, C_TEXT)
		if char_count >= full_body.length() and int(elapsed * 3.0) % 2 == 0:
			_text(canvas, "TAP / SPACE ▶", Vector2(512, 336), 10, C_WARM_HI)

static func _draw_discovery_art(canvas: CanvasItem, elapsed: float) -> void:
	canvas.draw_rect(Rect2(0, 0, W, H), Color("#070910"))
	canvas.draw_rect(Rect2(0, 46, 176, 192), Color("#111622"))
	canvas.draw_rect(Rect2(464, 46, 176, 192), Color("#111622"))
	canvas.draw_rect(Rect2(176, 62, 288, 176), Color("#192130"))
	if sin(elapsed * 4.2) > 0.0:
		canvas.draw_circle(Vector2(226, 102), 24.0, Color(0.62, 0.85, 0.98, 0.26))
		canvas.draw_rect(Rect2(222, 98, 8, 8), Color("#e5f6ff"))
	for i in range(7):
		canvas.draw_rect(Rect2(246 + i * 26, 196 - (i % 2) * 10, 7, 5), Color(0.62, 0.78, 0.92, 0.48))
	var glow := 0.45 + 0.45 * sin(elapsed * 2.5)
	canvas.draw_rect(Rect2(306, 134, 7, 5), Color(0.88, 0.96, 1.0, glow))
	canvas.draw_rect(Rect2(326, 134, 7, 5), Color(0.88, 0.96, 1.0, glow))

static func _draw_plane_escape_art(canvas: CanvasItem, elapsed: float) -> void:
	canvas.draw_rect(Rect2(0, 0, W, 92), Color("#1f2c4d"))
	canvas.draw_rect(Rect2(0, 76, W, 62), Color("#594059"))
	canvas.draw_rect(Rect2(0, 128, W, 50), Color("#c97553"))
	canvas.draw_rect(Rect2(0, 168, W, 74), Color("#f2ba74"))
	canvas.draw_circle(Vector2(524, 148), 54.0, Color(1.0, 0.86, 0.60, 0.20))
	canvas.draw_circle(Vector2(524, 148), 32.0, Color("#ffe6b0"))
	for i in range(4):
		var cx := fposmod(float(i * 190) - elapsed * 8.0, 720.0) - 40.0
		var cy := 74.0 + float((i % 2) * 28)
		canvas.draw_rect(Rect2(cx, cy, 74, 12), Color(1.0, 0.84, 0.72, 0.22))
		canvas.draw_rect(Rect2(cx + 14, cy - 6, 44, 8), Color(1.0, 0.88, 0.76, 0.25))
	var ridge_far := PackedVector2Array([
		Vector2(0, 240), Vector2(0, 176), Vector2(110, 152), Vector2(210, 174),
		Vector2(330, 144), Vector2(460, 170), Vector2(580, 154), Vector2(640, 176), Vector2(640, 240)
	])
	canvas.draw_colored_polygon(ridge_far, Color("#2c2536"))
	var ridge_near := PackedVector2Array([
		Vector2(0, 240), Vector2(0, 198), Vector2(88, 176), Vector2(184, 196),
		Vector2(300, 168), Vector2(420, 194), Vector2(540, 178), Vector2(640, 200), Vector2(640, 240)
	])
	canvas.draw_colored_polygon(ridge_near, Color("#171621"))
	for i in range(8):
		canvas.draw_rect(Rect2(34 + i * 38, 214, 9, 4), Color("#ffd694"))
	var px := fposmod(elapsed * 54.0, 720.0) - 40.0
	var py := 134.0 - (px / 640.0) * 34.0 + sin(elapsed * 4.0) * 4.5
	canvas.draw_line(Vector2(px - 66, py + 2), Vector2(px - 28, py + 2), Color(1.0, 0.96, 0.88, 0.35), 2.0)
	canvas.draw_rect(Rect2(px - 28, py - 8, 48, 14), Color("#ece4d2"))
	canvas.draw_rect(Rect2(px - 26, py + 2, 44, 4), Color("#c4b79e"))
	canvas.draw_rect(Rect2(px - 36, py - 18, 12, 12), Color("#d67c46"))
	canvas.draw_rect(Rect2(px - 12, py - 15, 24, 7), Color("#77d8d0"))
	canvas.draw_rect(Rect2(px - 8, py + 2, 28, 6), Color("#b5623d"))
	var prop_h := 16.0 if int(elapsed * 32.0) % 2 == 0 else 8.0
	canvas.draw_line(Vector2(px + 22, py - prop_h), Vector2(px + 22, py + prop_h), Color("#ffffff"), 2.5)

# =============================================================================
# 6. LIVE COMBAT HUD (TRAILING WHITE BOSS HP BAR + LOW-HP HEARTBEAT PULSE)
# =============================================================================

static func draw_hud(canvas: CanvasItem, state: Dictionary) -> void:
	var boss: BossController = state["boss"]
	var boss_hp_trail: float = float(state.get("boss_hp_trail", boss.hp))
	var player_hearts: int = state["player_hearts"]
	var coal_ammo: int = state["coal_ammo"]
	var auto_aim: bool = state["auto_aim"]
	var perfect_dodge_count: int = state["perfect_dodge_count"]
	var counter_strike_timer: float = state["counter_strike_timer"]
	var mining: bool = state["mining"]
	var mine_progress: float = state["mine_progress"]
	var mine_time: float = state["mine_time"]
	var closest_vein: int = state["closest_vein"]
	var message_text: String = state["message_text"]
	var message_timer: float = state["message_timer"]
	var combo_label: String = state["combo_label"]
	var combo_label_timer: float = state["combo_label_timer"]
	var dodge_cooldown: float = state["dodge_cooldown"]
	var elapsed: float = state["elapsed"]

	# Low-Health (1 Heart) subtle red pulse along viewport edges!
	if player_hearts == 1:
		var hb := 0.10 + 0.10 * sin(elapsed * 6.5)
		var rcol := Color(0.92, 0.18, 0.16, hb)
		canvas.draw_rect(Rect2(0, 42, 10, H - 42), rcol)
		canvas.draw_rect(Rect2(W - 10, 42, 10, H - 42), rcol)
		canvas.draw_rect(Rect2(0, H - 8, W, 8), rcol)

	# Top bar
	canvas.draw_rect(Rect2(0, 0, W, 42), Color("#090b14", 0.94))
	canvas.draw_rect(Rect2(0, 41, W, 2), Color("#3f384a"))
	canvas.draw_rect(Rect2(10, 7, 36, 26), Color("#181c2b"))
	canvas.draw_rect(Rect2(10, 7, 36, 26), Color("#3a425c"), false, 1.0)
	canvas.draw_rect(Rect2(20, 12, 5, 16), C_TEXT)
	canvas.draw_rect(Rect2(30, 12, 5, 16), C_TEXT)

	_text(canvas, "CHOKO", Vector2(58, 27), 14, C_TEXT)
	for i in range(5):
		var hcol := C_RED if i < player_hearts else Color("#403747")
		if player_hearts == 1 and i == 0 and int(elapsed * 6.0) % 2 == 0:
			hcol = Color("#ff968a")
		_draw_heart(canvas, Vector2(146 + i * 20, 18), hcol)

	canvas.draw_rect(Rect2(252, 9, 2, 24), Color("#3a3445"))
	_draw_coal_icon(canvas, Vector2(272, 20), 1.9)
	_text(canvas, str(coal_ammo).pad_zeros(2), Vector2(288, 27), 14, C_WARM_HI)

	if counter_strike_timer > 0.0:
		canvas.draw_rect(Rect2(340, 8, 126, 24), Color("#133338"))
		canvas.draw_rect(Rect2(340, 8, 126, 24), C_CYAN_HI, false, 1.0)
		_text_centered(canvas, "COUNTER READY!", 403.0, 25.0, 11, C_CYAN_HI)
	elif perfect_dodge_count > 0:
		_text(canvas, "PERFECT DODGES: " + str(perfect_dodge_count), Vector2(346, 26), 11, C_CYAN_HI)

	canvas.draw_rect(Rect2(534, 7, 96, 26), Color("#182530") if auto_aim else Color("#181a24"))
	canvas.draw_rect(Rect2(534, 7, 96, 26), C_CYAN if auto_aim else Color("#444254"), false, 1.0)
	_text_centered(canvas, "AUTO: " + ("ON" if auto_aim else "OFF"), 582.0, 25.0, 11, C_CYAN_HI if auto_aim else C_MUTED)

	var bname := str(boss.cfg.get("name", "BOSS"))
	if boss.id == "sentinel":
		bname += "  (PRACTICE)"
	elif boss.id == "allan":
		bname += "  •  BRAZIERS " + str(boss.get_lit_brazier_count()) + "/3"
	elif boss.id == "grandfather" and not boss.crystals.is_empty():
		bname += "  •  CRYSTALS " + str(boss.crystals.size())
	_text(canvas, bname, Vector2(16, 58), 12, C_MUTED if boss.id == "sentinel" else boss.cfg.get("accent_hi", C_TEXT))
	var mode_tag := "EASY" if boss.difficulty == "easy" else "NIGHTMARE"
	var mode_col := Color("#5ce6a8") if boss.difficulty == "easy" else C_RED
	if boss.id != "sentinel":
		_text(canvas, mode_tag, Vector2(486, 58), 10, mode_col)
	_text(canvas, "PHASE " + str(boss.phase), Vector2(564, 58), 11, C_CYAN_HI if boss.phase < 3 else C_RED)

	# Framed Boss HP Bar + Souls-Like White Trailing Damage Lag Bar!
	canvas.draw_rect(Rect2(15, 62, 610, 11), Color("#10111a"))
	canvas.draw_rect(Rect2(16, 63, 608, 9), Color("#302c3a"))
	var max_h := maxf(1.0, boss.max_hp)
	var trail_ratio := clampf(boss_hp_trail / max_h, 0.0, 1.0)
	var hp_ratio := clampf(boss.hp / max_h, 0.0, 1.0)
	if trail_ratio > hp_ratio:
		canvas.draw_rect(Rect2(16, 63, 608.0 * trail_ratio, 9), Color("#fff0cf"))
	var bar_col: Color = boss.cfg.get("bar_color", Color("#b75d59")) if boss.flash <= 0.0 else C_CYAN_HI
	canvas.draw_rect(Rect2(16, 63, 608.0 * hp_ratio, 9), bar_col)
	canvas.draw_rect(Rect2(16, 63, 608.0 * hp_ratio, 2), Color(1.0, 1.0, 1.0, 0.24))
	canvas.draw_rect(Rect2(16.0 + 608.0 * 0.33, 61, 2, 13), C_TEXT)
	canvas.draw_rect(Rect2(16.0 + 608.0 * 0.66, 61, 2, 13), C_TEXT)

	# Centered Boss Posture Bar
	var p_ratio := clampf(boss.posture / maxf(1.0, boss.max_posture), 0.0, 1.0)
	canvas.draw_rect(Rect2(138, 75, 364, 5), Color("#1b1824"))
	if p_ratio > 0.0:
		var p_col := Color("#ff6b4a") if p_ratio >= 0.78 else Color("#f2c15c")
		var pw := 364.0 * p_ratio
		canvas.draw_rect(Rect2(320.0 - pw * 0.5, 75, pw, 5), p_col)

	if not boss.status_tag.is_empty() and boss.hp > 0.0:
		var font := ThemeDB.fallback_font
		var tw := font.get_string_size(boss.status_tag, HORIZONTAL_ALIGNMENT_LEFT, -1.0, 11).x
		var bx := 320.0 - tw * 0.5 - 10.0
		canvas.draw_rect(Rect2(bx, 83, tw + 20.0, 18), Color(0.03, 0.035, 0.07, 0.86))
		canvas.draw_rect(Rect2(bx, 83, tw + 20.0, 18), Color(boss.status_color.r, boss.status_color.g, boss.status_color.b, 0.45), false, 1.0)
		_text_centered(canvas, boss.status_tag, 320.0, 96.0, 11, boss.status_color)

	if mining:
		canvas.draw_rect(Rect2(220, 104, 200, 20), Color("#141722", 0.94))
		canvas.draw_rect(Rect2(224, 108, 192.0 * (mine_progress / mine_time), 8), C_WARM)
		_text_centered(canvas, "EXPOSED  •  KEEP WATCH", 320.0, 121.0, 10, C_RED)
	elif closest_vein != -1:
		_text_centered(canvas, "COAL VEIN IN REACH  •  TAP MINE (E)", 320.0, 118.0, 10, C_WARM_HI)

	if boss.boss_quote_timer > 0.0 and not boss.boss_quote_text.is_empty():
		var qa := clampf(boss.boss_quote_timer * 1.4, 0.0, 1.0)
		var ac: Color = boss.cfg.get("accent_hi", C_WARM_HI)
		var qbox := Rect2(84, 108, 472, 56)
		canvas.draw_rect(qbox, Color(0.04, 0.045, 0.09, 0.90 * qa))
		canvas.draw_rect(Rect2(qbox.position.x, qbox.position.y, qbox.size.x, 2), Color(ac.r, ac.g, ac.b, qa))
		var sp_bank: SpriteBank = state.get("sprites", null)
		var qtx := qbox.position.x + 14.0
		if sp_bank != null:
			var ptex: Texture2D = sp_bank.get_portrait_by_id(boss.id)
			if ptex != null:
				canvas.draw_texture_rect(ptex, Rect2(qbox.position.x + 6, qbox.position.y + 6, 44, 44), false, Color(1, 1, 1, qa))
				qtx = qbox.position.x + 58.0
		var header_lbl: String = boss.phase_banner_text if not boss.phase_banner_text.is_empty() else str(boss.cfg.get("name", "BOSS"))
		_text(canvas, header_lbl, Vector2(qtx, qbox.position.y + 19), 11, Color(ac.r, ac.g, ac.b, qa))
		_draw_wrapped(canvas, '"' + boss.boss_quote_text + '"', Vector2(qtx, qbox.position.y + 36), qbox.size.x - (qtx - qbox.position.x) - 10.0, 14.0, 11, Color(C_TEXT.r, C_TEXT.g, C_TEXT.b, qa))
	elif boss.phase_banner_timer > 0.0 and not boss.phase_banner_text.is_empty():
		var ba := clampf(boss.phase_banner_timer * 1.5, 0.0, 1.0)
		canvas.draw_rect(Rect2(100, 146, 440, 32), Color(0.04, 0.04, 0.09, 0.88 * ba))
		var ac: Color = boss.cfg.get("accent_hi", C_WARM_HI)
		canvas.draw_rect(Rect2(100, 146, 440, 2), Color(ac.r, ac.g, ac.b, ba))
		_text_centered(canvas, boss.phase_banner_text, 320.0, 168.0, 14, Color(ac.r, ac.g, ac.b, ba))
	elif message_timer > 0.0:
		var alpha := minf(1.0, message_timer * 1.8)
		var font := ThemeDB.fallback_font
		var tw := font.get_string_size(message_text, HORIZONTAL_ALIGNMENT_LEFT, -1.0, 11).x
		var bx := 320.0 - tw * 0.5 - 10.0
		canvas.draw_rect(Rect2(bx, 122, tw + 20.0, 20), Color(0.03, 0.035, 0.06, 0.80 * alpha))
		_text_centered(canvas, message_text, 320.0, 136.0, 11, Color(C_TEXT.r, C_TEXT.g, C_TEXT.b, alpha))

	if combo_label_timer > 0.0:
		var alpha2 := minf(1.0, combo_label_timer * 2.4)
		var lc := C_CYAN_HI if combo_label == "COUNTER STRIKE!" else C_WARM_HI
		_text(canvas, combo_label, Vector2(20, 102), 13, Color(lc.r, lc.g, lc.b, alpha2))

	if dodge_cooldown > 0.0:
		var max_cd := 0.72 if boss.difficulty == "easy" else 0.88
		var cd := clampf(dodge_cooldown / max_cd, 0.0, 1.0)
		canvas.draw_rect(Rect2(526, 318, 78, 5), Color("#333240"))
		canvas.draw_rect(Rect2(526, 318, 78.0 * (1.0 - cd), 5), C_CYAN)

	if elapsed < 9.0:
		_text_centered(canvas, "PERFECT DODGE → COUNTER STRIKE (1.6X)  •  BREAK BOSS POSTURE!", 320.0, 353.0, 10, Color(0.80, 0.90, 0.92, 0.72))

static func draw_touch_controls(canvas: CanvasItem, state: Dictionary) -> void:
	var joystick_touch: int = state["joystick_touch"]
	var joystick_origin: Vector2 = state["joystick_origin"]
	var joystick_vector: Vector2 = state["joystick_vector"]
	var coal_touch: int = state["coal_touch"]
	var coal_aim_vector: Vector2 = state["coal_aim_vector"]
	var pressed_buttons: Dictionary = state["pressed_buttons"]
	var coal_ammo: int = state["coal_ammo"]
	var dodge_cooldown: float = state["dodge_cooldown"]
	var closest_vein: int = state["closest_vein"]
	var mining: bool = state["mining"]
	var mine_progress: float = state["mine_progress"]
	var mine_time: float = state["mine_time"]
	var player_pos: Vector2 = state["player_pos"]
	var attack_direction: Vector2 = state["attack_direction"]
	var counter_ready: bool = float(state["counter_strike_timer"]) > 0.0
	var op: float = clampf(float(state.get("touch_opacity", 0.85)), 0.35, 1.0)
	var sc: float = clampf(float(state.get("touch_scale", 1.0)), 0.80, 1.20)

	var joy_center := joystick_origin if joystick_touch != -1 else JOY_IDLE
	var joy_alpha := (0.14 if joystick_touch == -1 else 0.32) * op
	canvas.draw_circle(joy_center, 42.0 * sc, Color(0.62, 0.70, 0.82, joy_alpha))
	canvas.draw_arc(joy_center, 42.0 * sc, 0.0, TAU, 32, Color(0.78, 0.83, 0.91, (joy_alpha + 0.16) * op), 2.0)
	canvas.draw_circle(joy_center, 26.0 * sc, Color(0.28, 0.31, 0.41, joy_alpha * 0.9))
	var knob := joy_center + joystick_vector * (26.0 * sc)
	canvas.draw_circle(knob, 14.0 * sc, Color(0.84, 0.89, 0.96, (0.36 if joystick_touch != -1 else 0.20) * op))
	canvas.draw_arc(knob, 14.0 * sc, 0.0, TAU, 24, Color(0.94, 0.96, 1.0, 0.42 * op), 1.6)

	_draw_action_button(canvas, pressed_buttons, BTN_PICK, 38.0 * sc, "CTR" if counter_ready else "HIT", C_CYAN_HI if counter_ready else C_WARM, true, "pick", op)
	_draw_action_button(canvas, pressed_buttons, BTN_COAL, 30.0 * sc, "COAL", Color("#b8becf"), coal_ammo > 0, "coal", op)
	_draw_action_button(canvas, pressed_buttons, BTN_DODGE, 28.0 * sc, "ROLL", C_CYAN, dodge_cooldown <= 0.0, "dodge", op)
	if closest_vein != -1 or mining:
		_draw_action_button(canvas, pressed_buttons, BTN_MINE, 28.0 * sc, "MINE", C_WARM_HI, true, "mine", op)
		if mining:
			canvas.draw_arc(BTN_MINE, 34.0 * sc, -PI / 2.0, -PI / 2.0 + TAU * (mine_progress / mine_time), 28, C_WARM_HI, 3.0)

	if coal_touch != -1 and coal_aim_vector.length() > 10.0:
		var aim_dir := coal_aim_vector.normalized()
		canvas.draw_line(BTN_COAL, BTN_COAL + aim_dir * 50.0, Color("#fff0bd"), 3.0)
		canvas.draw_circle(BTN_COAL + aim_dir * 50.0, 4.0, C_WARM_HI)
	if joystick_touch != -1 and joystick_vector.length() > 0.24:
		var p_hd := player_pos * 2.0
		var dir_end := p_hd + attack_direction * 36.0
		canvas.draw_line(p_hd + Vector2(0, -4), dir_end, Color(1.0, 0.84, 0.56, 0.50), 2.0)
		canvas.draw_circle(dir_end, 4.0, Color(1.0, 0.84, 0.56, 0.75))

static func _draw_action_button(canvas: CanvasItem, pressed_buttons: Dictionary, center: Vector2, radius: float, label: String, tint: Color, enabled: bool, kind: String, op: float) -> void:
	var active := false
	for value in pressed_buttons.values():
		if value == kind:
			active = true
	var alpha := (0.80 if enabled else 0.32) * op
	var fill := Color("#111420")
	fill.a = (0.76 if not active else 0.96) * op
	canvas.draw_circle(center + Vector2(0, 3), radius + 3.0, Color(0.0, 0.0, 0.0, 0.32 * op))
	canvas.draw_circle(center, radius, fill)
	canvas.draw_circle(center, radius - 4.0, Color(tint.r, tint.g, tint.b, (0.15 if enabled else 0.05) * op))
	canvas.draw_arc(center, radius, 0.0, TAU, 32, Color(tint.r, tint.g, tint.b, alpha if not active else op), 2.4 if kind != "pick" else 3.0)
	var icon_col := Color(tint.r, tint.g, tint.b, op) if enabled else Color(C_DIM.r, C_DIM.g, C_DIM.b, op)
	_draw_button_icon(canvas, center + Vector2(0, -6), kind, icon_col)
	var lbl_col := Color(C_TEXT.r, C_TEXT.g, C_TEXT.b, op) if enabled else Color(C_DIM.r, C_DIM.g, C_DIM.b, op)
	_text_centered(canvas, label, center.x, center.y + radius * 0.58, 11, lbl_col)

static func _draw_button_icon(canvas: CanvasItem, center: Vector2, kind: String, tint: Color) -> void:
	if kind == "pick" or kind == "mine":
		canvas.draw_line(center + Vector2(-9, 9), center + Vector2(9, -9), Color(0.62, 0.46, 0.32, tint.a), 3.0)
		canvas.draw_line(center + Vector2(2, -11), center + Vector2(13, -5), tint, 3.0)
		canvas.draw_line(center + Vector2(2, -11), center + Vector2(7, -16), tint, 3.0)
	elif kind == "coal":
		canvas.draw_colored_polygon(PackedVector2Array([
			center + Vector2(0, -12), center + Vector2(10, -4), center + Vector2(6, 10),
			center + Vector2(-7, 9), center + Vector2(-10, -3)
		]), tint)
		canvas.draw_rect(Rect2(center.x - 2, center.y - 5, 4, 5), Color(1.0, 0.94, 0.81, tint.a))
	elif kind == "dodge":
		canvas.draw_line(center + Vector2(-11, -7), center + Vector2(-2, 0), tint, 3.0)
		canvas.draw_line(center + Vector2(-2, 0), center + Vector2(-11, 7), tint, 3.0)
		canvas.draw_line(center + Vector2(2, -7), center + Vector2(11, 0), tint, 3.0)
		canvas.draw_line(center + Vector2(11, 0), center + Vector2(2, 7), tint, 3.0)

static func _draw_coal_icon(canvas: CanvasItem, center: Vector2, scale: float) -> void:
	canvas.draw_colored_polygon(PackedVector2Array([
		center + Vector2(0, -4) * scale, center + Vector2(4, -1) * scale,
		center + Vector2(2, 4) * scale, center + Vector2(-3, 3) * scale,
		center + Vector2(-4, -1) * scale
	]), C_COAL)
	canvas.draw_rect(Rect2(center.x - 2, center.y - 3, 4, 4), C_WARM)

static func _draw_heart(canvas: CanvasItem, center: Vector2, tint: Color) -> void:
	canvas.draw_rect(Rect2(center.x - 6, center.y - 4, 5, 5), tint)
	canvas.draw_rect(Rect2(center.x + 1, center.y - 4, 5, 5), tint)
	canvas.draw_rect(Rect2(center.x - 7, center.y, 14, 5), tint)
	canvas.draw_rect(Rect2(center.x - 5, center.y + 5, 10, 4), tint)
	canvas.draw_rect(Rect2(center.x - 2, center.y + 9, 4, 3), tint)
	canvas.draw_rect(Rect2(center.x - 5, center.y - 3, 2, 2), Color(1.0, 1.0, 1.0, 0.35))

# =============================================================================
# 7. PAUSE OVERLAY & LAPTOP BRAINROT RESPAWN MENU
# =============================================================================

static func draw_pause_overlay(canvas: CanvasItem, boss_name: String) -> void:
	canvas.draw_rect(Rect2(0, 0, W, H), Color(0.02, 0.025, 0.05, 0.84))
	_draw_panel(canvas, Rect2(168, 42, 304, 266), Color("#151926"), Color("#3e4661"), C_WARM)
	_text_centered(canvas, "PAUSED", 320.0, 82.0, 22, C_TEXT)
	_text_centered(canvas, boss_name, 320.0, 104.0, 11, C_MUTED)

	var btns := [
		[RECT_PAUSE_RESUME, "RESUME FIGHT", C_CYAN],
		[RECT_PAUSE_RESTART, "RESTART FIGHT", C_WARM],
		[RECT_PAUSE_SETTINGS, "SETTINGS", C_CYAN_HI],
		[RECT_PAUSE_MENU, "MAIN MENU", C_MUTED],
	]
	for b_v in btns:
		var b: Array = b_v
		var r: Rect2 = b[0]
		var lbl := str(b[1])
		var ac: Color = b[2]
		_draw_panel(canvas, r, Color("#272d40"), Color("#444e6b"), ac)
		_text_centered(canvas, lbl, r.position.x + r.size.x * 0.5, r.position.y + 23.0, 12, C_TEXT)

static func draw_respawn_menu(canvas: CanvasItem, boss_name: String, attempts: int, best_phase: int, caption_idx: int, elapsed: float) -> void:
	canvas.draw_rect(Rect2(0, 0, W, H), Color("#080912"))
	for i in range(28):
		var sx := float((i * 73 + 23) % 640)
		var sy := float((i * 41 + 11) % 360)
		canvas.draw_rect(Rect2(sx, sy, 2, 2), Color(0.50, 0.55, 0.72, 0.24))

	_draw_panel(canvas, Rect2(44, 20, 552, 322), Color("#151624"), Color("#3c3e59"), C_WARM)
	_text_centered(canvas, "YOU GOT BONKED", 320.0, 50.0, 18, C_TEXT)
	_text_centered(canvas, boss_name + "  •  ATTEMPT #" + str(attempts) + "  •  BEST PHASE " + str(best_phase), 320.0, 70.0, 11, C_WARM_HI)

	canvas.draw_circle(Vector2(320, 180), 96.0, Color(0.32, 0.65, 0.85, 0.08))
	canvas.draw_rect(Rect2(256, 124, 128, 86), Color("#343045"))
	canvas.draw_rect(Rect2(266, 130, 108, 72), Color("#487e7d"))
	canvas.draw_rect(Rect2(278, 94, 84, 72), Color("#dfb07e"))
	canvas.draw_rect(Rect2(274, 84, 92, 28), Color("#241e29"))
	canvas.draw_rect(Rect2(288, 118, 9, 7), Color("#1b1724"))
	canvas.draw_rect(Rect2(343, 118, 9, 7), Color("#1b1724"))
	canvas.draw_rect(Rect2(290, 120, 3, 3), C_CYAN_HI)
	canvas.draw_rect(Rect2(345, 120, 3, 3), C_CYAN_HI)
	canvas.draw_rect(Rect2(308, 138, 24, 4), Color("#8f514d"))
	canvas.draw_rect(Rect2(216, 146, 208, 98), Color("#4c5569"))
	canvas.draw_rect(Rect2(224, 154, 192, 82), Color("#090d1a"))
	canvas.draw_rect(Rect2(230, 160, 180, 70), Color("#231f45"))
	for k in range(10):
		var bh := 8.0 + absf(sin(elapsed * 7.0 + float(k) * 0.9)) * 16.0
		canvas.draw_rect(Rect2(244 + k * 15, 224 - bh, 8, bh), Color(0.45, 0.86, 0.92, 0.35))
	var captions := ["SIGMA MINING ARC", "BRO REALLY SAID 'WHAT'", "NPC MOMENT +999", "THE WIFI IS THE FINAL BOSS"]
	var caption: String = captions[caption_idx % captions.size()]
	_text_centered(canvas, caption, 320.0, 196.0, 12, C_CYAN_HI)
	canvas.draw_rect(Rect2(204, 244, 232, 8), Color("#868da1"))
	canvas.draw_rect(Rect2(190, 252, 260, 6), Color("#565c6e"))
	_text_centered(canvas, "...ONE MORE VIDEO...", 320.0, 280.0, 12, C_WARM_HI)

	var r_retry := RECT_RESPAWN_RETRY
	_draw_panel(canvas, r_retry, Color("#2a3d4f"), Color("#4f7b96"), C_CYAN)
	_text_centered(canvas, "RESPAWN", r_retry.position.x + r_retry.size.x * 0.5, r_retry.position.y + 24.0, 14, C_TEXT)

	var r_menu := RECT_RESPAWN_MENU
	_draw_panel(canvas, r_menu, Color("#262a3b"), Color("#4a506b"), C_WARM)
	_text_centered(canvas, "MENU", r_menu.position.x + r_menu.size.x * 0.5, r_menu.position.y + 24.0, 14, C_TEXT)

	_text_centered(canvas, "Tap RESPAWN or press SPACE / ENTER", 320.0, 353.0, 10, C_MUTED)
