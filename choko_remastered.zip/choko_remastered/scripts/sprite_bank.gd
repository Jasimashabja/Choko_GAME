extends RefCounted

## CHOKO — Phase 4.1: HD Pixel-Art Sprite Sheet, 96x96 Portrait & 640x360 Arena Bank.
## Loads nearest-neighbor PNG sheets, portraits, and underground arena backdrops once
## with safe fallbacks if any asset is absent.

var sheets: Dictionary = {}
var portraits: Dictionary = {}
var arenas: Dictionary = {}
var title_tex: Texture2D = null

func load_all() -> void:
	var ids := [
		"choko", "farhan", "allan", "john_paul",
		"aaron", "grandfather", "dead_cat", "sentinel"
	]
	for id_v in ids:
		var sid: String = str(id_v)
		var spath := "res://assets/sprites/" + sid + "_sheet.png"
		if ResourceLoader.exists(spath):
			var sres: Resource = load(spath)
			if sres is Texture2D:
				sheets[sid] = sres
		var ppath := "res://assets/sprites/portraits/portrait_" + sid + ".png"
		if ResourceLoader.exists(ppath):
			var pres: Resource = load(ppath)
			if pres is Texture2D:
				portraits[sid] = pres

	var arena_ids := [
		"farhan", "allan", "john_paul", "aaron",
		"grandfather", "dead_cat", "sentinel"
	]
	for aid_v in arena_ids:
		var aid: String = str(aid_v)
		var apath := "res://assets/arenas/arena_" + aid + ".png"
		if ResourceLoader.exists(apath):
			var ares: Resource = load(apath)
			if ares is Texture2D:
				arenas[aid] = ares
	var tpath := "res://assets/arenas/title_quarry.png"
	if ResourceLoader.exists(tpath):
		var tres: Resource = load(tpath)
		if tres is Texture2D:
			title_tex = tres

func has_sheet(sheet_id: String) -> bool:
	return sheets.has(sheet_id)

func get_title_tex() -> Texture2D:
	return title_tex

func get_arena_tex(boss_id: String) -> Texture2D:
	if arenas.has(boss_id):
		return arenas[boss_id]
	return arenas.get("sentinel", null)

func get_portrait_by_id(char_id: String) -> Texture2D:
	return portraits.get(char_id, null)

func draw_frame(canvas: CanvasItem, sheet_id: String, col: int, row: int, frame_w: int, frame_h: int, center: Vector2, flip_h: bool = false, modulate: Color = Color.WHITE, draw_scale: float = 1.0) -> bool:
	if not sheets.has(sheet_id):
		return false
	var tex: Texture2D = sheets[sheet_id]
	var dw := floorf(float(frame_w) * draw_scale)
	var dh := floorf(float(frame_h) * draw_scale)
	var dx := floorf(center.x - dw * 0.5)
	var dy := floorf(center.y - dh * 0.5)
	var src := Rect2(float(col * frame_w), float(row * frame_h), float(frame_w), float(frame_h))
	var dst := Rect2(dx, dy, dw, dh)
	if flip_h:
		dst = Rect2(dx + dw, dy, -dw, dh)
	canvas.draw_texture_rect_region(tex, dst, src, modulate)
	return true

func get_portrait_for_speaker(speaker: String, fallback_boss_id: String = "") -> Texture2D:
	var s := speaker.to_upper()
	if s == "CHOKO":
		return portraits.get("choko", null)
	if s == "FARHAN":
		return portraits.get("farhan", null)
	if s == "ALLAN":
		return portraits.get("allan", null)
	if s == "JOHN PAUL":
		return portraits.get("john_paul", null)
	if s == "AARON":
		return portraits.get("aaron", null)
	if s == "GRANDFATHER":
		return portraits.get("grandfather", null)
	if s == "THE DEAD CAT":
		return portraits.get("dead_cat", null)
	if s == "TRAINING NOTE":
		return portraits.get("sentinel", null)
	if not fallback_boss_id.is_empty() and portraits.has(fallback_boss_id):
		return portraits[fallback_boss_id]
	return null
