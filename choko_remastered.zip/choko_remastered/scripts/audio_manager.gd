extends Node

## CHOKO — Phase 4.0: Self-Contained Chiptune Music & Pooled SFX Manager.
## Loads .wav assets lazily with ResourceLoader.exists() guards so missing assets
## never crash, loops music reliably via AudioStreamPlayer.finished, and pools
## 8 SFX channels for crisp overlapping combat impacts on Android.

const SFX_POOL_SIZE := 8

var music_player: AudioStreamPlayer = null
var sfx_players: Array = []
var sfx_cursor: int = 0
var music_cache: Dictionary = {}
var sfx_cache: Dictionary = {}

var current_track: String = ""
var music_vol: float = 0.75
var sfx_vol: float = 0.85

func _ready() -> void:
	music_player = AudioStreamPlayer.new()
	music_player.name = "MusicPlayer"
	add_child(music_player)
	music_player.finished.connect(_on_music_finished)

	for i in range(SFX_POOL_SIZE):
		var sp := AudioStreamPlayer.new()
		sp.name = "SfxPlayer_" + str(i)
		add_child(sp)
		sfx_players.append(sp)
	apply_settings(music_vol, sfx_vol)

func apply_settings(new_music_vol: float, new_sfx_vol: float) -> void:
	music_vol = clampf(new_music_vol, 0.0, 1.0)
	sfx_vol = clampf(new_sfx_vol, 0.0, 1.0)
	if music_player != null:
		if music_vol <= 0.01:
			music_player.volume_db = -80.0
			if music_player.playing:
				music_player.stop()
		else:
			music_player.volume_db = linear_to_db(music_vol * 0.55)
			if not current_track.is_empty() and not music_player.playing and music_player.stream != null:
				music_player.play()
	for sp_v in sfx_players:
		var sp: AudioStreamPlayer = sp_v
		sp.volume_db = -80.0 if sfx_vol <= 0.01 else linear_to_db(sfx_vol * 0.78)

func play_music(track_id: String) -> void:
	if track_id == current_track and music_player != null and music_player.playing:
		return
	current_track = track_id
	if music_player == null:
		return
	if track_id.is_empty():
		music_player.stop()
		music_player.stream = null
		return
	var stream: AudioStream = _load_music(track_id)
	if stream == null:
		return
	music_player.stream = stream
	if music_vol > 0.01:
		music_player.volume_db = linear_to_db(music_vol * 0.55)
		music_player.play()

func stop_music() -> void:
	current_track = ""
	if music_player != null:
		music_player.stop()

func _on_music_finished() -> void:
	if music_player != null and not current_track.is_empty() and music_vol > 0.01 and music_player.stream != null:
		music_player.play()

func play_sfx(sfx_id: String, pitch_jitter: float = 0.04) -> void:
	if sfx_vol <= 0.01 or sfx_players.is_empty():
		return
	var stream: AudioStream = _load_sfx(sfx_id)
	if stream == null:
		return
	var sp: AudioStreamPlayer = sfx_players[sfx_cursor]
	sfx_cursor = (sfx_cursor + 1) % sfx_players.size()
	sp.stream = stream
	sp.volume_db = linear_to_db(sfx_vol * 0.78)
	sp.pitch_scale = 1.0 + randf_range(-pitch_jitter, pitch_jitter) if pitch_jitter > 0.0 else 1.0
	sp.play()

func _load_music(track_id: String) -> AudioStream:
	if music_cache.has(track_id):
		return music_cache[track_id]
	var path := "res://assets/audio/music/" + track_id + ".wav"
	if not ResourceLoader.exists(path):
		return null
	var res: Resource = load(path)
	if res is AudioStream:
		music_cache[track_id] = res
		return res
	return null

func _load_sfx(sfx_id: String) -> AudioStream:
	if sfx_cache.has(sfx_id):
		return sfx_cache[sfx_id]
	var path := "res://assets/audio/sfx/" + sfx_id + ".wav"
	if not ResourceLoader.exists(path):
		return null
	var res: Resource = load(path)
	if res is AudioStream:
		sfx_cache[sfx_id] = res
		return res
	return null
