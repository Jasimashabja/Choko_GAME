extends RefCounted

## CHOKO — Phase 4.5: Boss Data, Easy/Nightmare Balance & Overhauled Encounter Dialogue.
## Single source of truth for encounter order, HP, Posture, phases, underground arenas,
## polished boss intro/victory scripts, mid-fight phase quotes, and story transitions.

const CAMPAIGN_ORDER := [
	"farhan",
	"allan",
	"john_paul",
	"aaron",
	"grandfather",
]

const ALL_ORDER := [
	"farhan",
	"allan",
	"john_paul",
	"aaron",
	"grandfather",
	"dead_cat",
	"sentinel",
]

static func get_boss(id: String) -> Dictionary:
	match id:
		"farhan":
			return {
				"id": "farhan",
				"name": "FARHAN",
				"title": "EXPLOSIVES DEPOT WARDEN",
				"arena_name": "SUBTERRANEAN EXPLOSIVES DEPOT",
				"mechanic_hint": "HIT TICKING BOMBS TO BAT THEM BACK  •  WATCH TRIPWIRES",
				"is_campaign": true,
				"is_secret": false,
				"campaign_index": 1,
				"max_hp": 390.0,
				"max_posture": 125.0,
				"posture_drain": 8.0,
				"phase2_ratio": 0.66,
				"phase3_ratio": 0.33,
				"hitbox_radius": 14.0,
				"spawn_pos": Vector2(238.0, 102.0),
				"accent": Color("#f0a256"),
				"accent_hi": Color("#ffe0a3"),
				"bar_color": Color("#d67c46"),
				"phase_titles": ["", "PHASE II  •  TRIPWIRES ARMED", "PHASE III  •  SCORCHED DEPOT"],
				"phase_quotes": [
					"",
					"Stay with me, Choko—I won't let the surface tear us apart!",
					"If we can't stay together, this whole depot burns with us!"
				],
				"intro_lines": [
					{"speaker": "FARHAN", "text": "Stop right there, Choko. I cannot let you leave, my love—we will always be together down here in this dungeon!"},
					{"speaker": "CHOKO", "text": "Farhan, listen to me! Grandfather twisted your head—there's a plane waiting at the quarry airstrip!"},
					{"speaker": "FARHAN", "text": "No! The outside will only take you away from me! If I have to blow these blast shutters shut to keep you safe, I will!"},
					{"speaker": "CHOKO", "text": "I love you, Farhan... which is why I'm getting us both out of this mine!"},
				],
				"victory_lines": [
					{"speaker": "FARHAN", "text": "...You batted my own satchel charge right back at me. You really aren't backing down."},
					{"speaker": "CHOKO", "text": "Look at the detonator seal, Farhan. Grandfather lied—the freight lift isn't rigged. We can actually leave together."},
					{"speaker": "FARHAN", "text": "...I'm sorry, my love. Go ahead—I'll hold the blast shutters open and meet you at the plane."},
				],
				"veins": [
					Vector2(42.0, 74.0),
					Vector2(158.0, 138.0),
					Vector2(280.0, 74.0),
				],
			}
		"allan":
			return {
				"id": "allan",
				"name": "ALLAN",
				"title": "KEEPER OF THE WHITE COTTON",
				"arena_name": "LIGHTLESS ROOT CATHEDRAL",
				"mechanic_hint": "IGNITE BRAZIERS WITH COAL  •  CHOP SNUFFING WHITE VINES",
				"is_campaign": true,
				"is_secret": false,
				"campaign_index": 2,
				"max_hp": 430.0,
				"max_posture": 135.0,
				"posture_drain": 7.5,
				"phase2_ratio": 0.66,
				"phase3_ratio": 0.33,
				"hitbox_radius": 15.0,
				"spawn_pos": Vector2(236.0, 98.0),
				"accent": Color("#e8eef2"),
				"accent_hi": Color("#ffffff"),
				"bar_color": Color("#9ca6b8"),
				"phase_titles": ["", "PHASE II  •  CREEPING WHITE HARVEST", "PHASE III  •  GRANDFATHER'S DARKNESS"],
				"phase_quotes": [
					"",
					"Touch a single white cotton bloom and my roots will swallow you!",
					"Grandfather, pour your darkness into my garden—snuff every flame!"
				],
				"intro_lines": [
					{"speaker": "CHOKO", "text": "No lamps down here... just endless rows of glowing white cotton growing straight out of black coal."},
					{"speaker": "ALLAN", "text": "Step no closer, little miner. I will protect my cotton at all costs!"},
					{"speaker": "ALLAN", "text": "Grandfather—lend me your darkness! Drown every spark before it touches my cathedral!"},
					{"speaker": "CHOKO", "text": "Three dry oil braziers... If my coal lights them up, your darkness won't have anywhere to hide!"},
				],
				"victory_lines": [
					{"speaker": "ALLAN", "text": "Warmth... even beneath the seam. My white cotton loosens its roots..."},
					{"speaker": "CHOKO", "text": "The cathedral archway is clear. Hang on, Farhan—I'm pushing deeper."},
				],
				"veins": [
					Vector2(36.0, 128.0),
					Vector2(160.0, 140.0),
					Vector2(284.0, 128.0),
				],
				"braziers": [
					Vector2(82.0, 72.0),
					Vector2(160.0, 62.0),
					Vector2(238.0, 72.0),
				],
			}
		"john_paul":
			return {
				"id": "john_paul",
				"name": "JOHN PAUL",
				"title": "MASTER OF THE MIGHTY SHAJI KITTEN",
				"arena_name": "UNDERGROUND DRAINAGE & RAIL STATION",
				"mechanic_hint": "DEFLECT YARN ORBS WITH PICKAXE  •  BAIT POUNCES INTO STEAM",
				"is_campaign": true,
				"is_secret": false,
				"campaign_index": 3,
				"max_hp": 450.0,
				"max_posture": 135.0,
				"posture_drain": 9.0,
				"phase2_ratio": 0.66,
				"phase3_ratio": 0.33,
				"hitbox_radius": 14.0,
				"spawn_pos": Vector2(246.0, 100.0),
				"accent": Color("#8ce0cf"),
				"accent_hi": Color("#d6fff5"),
				"bar_color": Color("#4eb5a8"),
				"phase_titles": ["", "PHASE II  •  WRATH OF SHAJI KITTEN", "PHASE III  •  APEX WALL HUNTER"],
				"phase_quotes": [
					"",
					"The Mighty Shaji Kitten demands blood, steam, and yarn!",
					"Watch every wall, little mouse—no one escapes the Shaji claws!"
				],
				"intro_lines": [
					{"speaker": "JOHN PAUL", "text": "Hiss... You just kicked the grate open and interrupted my kitten business, Choko."},
					{"speaker": "CHOKO", "text": "Your 'kitten business'?! John Paul, you're blocking the drainage rail lift out of the quarry!"},
					{"speaker": "JOHN PAUL", "text": "Nobody messes with my underground cat enterprise. Now you will feel the wrath of the Mighty Shaji Kitten!"},
					{"speaker": "CHOKO", "text": "Boiling steam pipes, wall claws, and the Mighty Shaji Kitten... fine. Let's dance."},
				],
				"victory_lines": [
					{"speaker": "JOHN PAUL", "text": "Heh... sharp pickaxe, steady feet. Even the Mighty Shaji Kitten respects that deflection."},
					{"speaker": "JOHN PAUL", "text": "Take the rail hatch. Whatever waits past the crypt smells far older—and far angrier—than me."},
				],
				"veins": [
					Vector2(44.0, 80.0),
					Vector2(160.0, 138.0),
					Vector2(278.0, 134.0),
				],
				"steam_vents": [
					Vector2(92.0, 86.0),
					Vector2(160.0, 114.0),
					Vector2(228.0, 86.0),
				],
			}
		"aaron":
			return {
				"id": "aaron",
				"name": "AARON",
				"title": "WARDEN OF THE FOSSIL CRYPT",
				"arena_name": "FOSSIL CRYPT MINE TUNNEL",
				"mechanic_hint": "SHATTER FOR 1.55X PICKAXE  •  SMASH REASSEMBLING BONE SHARDS",
				"is_campaign": true,
				"is_secret": false,
				"campaign_index": 4,
				"max_hp": 480.0,
				"max_posture": 130.0,
				"posture_drain": 7.0,
				"phase2_ratio": 0.66,
				"phase3_ratio": 0.33,
				"hitbox_radius": 15.0,
				"spawn_pos": Vector2(236.0, 102.0),
				"accent": Color("#ded5be"),
				"accent_hi": Color("#fff8e6"),
				"bar_color": Color("#bfb398"),
				"phase_titles": ["", "PHASE II  •  RUINED DATE NIGHT", "PHASE III  •  CRYPT COLLAPSE"],
				"phase_quotes": [
					"",
					"Steve, cover your eyes! I'm burying this intruder in ribs!",
					"Nobody ruins my evening with Steve and walks out in one piece!"
				],
				"intro_lines": [
					{"speaker": "AARON", "text": "Clatter... rattle... You have got some nerve, boy. You just interrupted my love life with Steve!"},
					{"speaker": "CHOKO", "text": "Wait—who is Steve?! I didn't mean to crash anything, I just need to cross the fossil crypt!"},
					{"speaker": "AARON", "text": "We had a quiet candlelit dinner among the ribs, and you burst through the tunnel! My bones will crush you for this!"},
					{"speaker": "CHOKO", "text": "Sorry to ruin date night, Aaron—now hold still while I knock those ribs loose!"},
				],
				"victory_lines": [
					{"speaker": "AARON", "text": "Clatter... and quiet. Tell Steve... I'll be ten minutes late for dessert..."},
					{"speaker": "CHOKO", "text": "One last gate left. The buried chapel... Grandfather."},
				],
				"veins": [
					Vector2(40.0, 74.0),
					Vector2(158.0, 138.0),
					Vector2(282.0, 78.0),
				],
			}
		"grandfather":
			return {
				"id": "grandfather",
				"name": "GRANDFATHER",
				"title": "OVERSEER OF THE BURIED CHAPEL",
				"arena_name": "BURIED CHAPEL BENEATH THE QUARRY",
				"mechanic_hint": "SMASH COAL-HEART CRYSTALS  •  READ GLINTS & CYAN SAFE RINGS",
				"is_campaign": true,
				"is_secret": false,
				"campaign_index": 5,
				"max_hp": 620.0,
				"max_posture": 170.0,
				"posture_drain": 8.5,
				"phase2_ratio": 0.66,
				"phase3_ratio": 0.33,
				"hitbox_radius": 17.0,
				"spawn_pos": Vector2(238.0, 100.0),
				"accent": Color("#e86f5c"),
				"accent_hi": Color("#ffd08a"),
				"bar_color": Color("#c94c44"),
				"phase_titles": ["", "PHASE II  •  CORRUPTED ELDER", "PHASE III  •  COAL-HEART BELL"],
				"phase_quotes": [
					"",
					"My old bones stay warm while the quarry burns! Back to your shift!",
					"Feed the heaters, boy! Hear the coal-heart bell toll!"
				],
				"intro_lines": [
					{"speaker": "GRANDFATHER", "text": "Going somewhere, Choko? You will never leave this dungeon—you will mine coal for my heaters forever!"},
					{"speaker": "CHOKO", "text": "Your heaters?! You trapped Farhan, corrupted the whole mine, and worked us half to death just to keep your furnace warm!"},
					{"speaker": "GRANDFATHER", "text": "My joints may be old, boy, but the coal-heart obeys my cane—and my chapel bell! Get back to work!"},
				],
				"victory_lines": [
					{"speaker": "GRANDFATHER", "text": "...The heaters are going cold. Look at these old hands... the black seam is finally cracking."},
					{"speaker": "CHOKO", "text": "The freight lift to the airstrip is open. Farhan—we're finally free!"},
					{"speaker": "CHAPEL RUINS", "text": "Beyond the rubble, a tiny service light begins blinking inside a cracked wall..."},
				],
				"veins": [
					Vector2(38.0, 76.0),
					Vector2(160.0, 139.0),
					Vector2(282.0, 76.0),
				],
			}
		"dead_cat":
			return {
				"id": "dead_cat",
				"name": "THE DEAD CAT",
				"title": "VENGEFUL ECHO OF THE CATACOMB",
				"arena_name": "SEALED CATACOMB BENEATH THE CHAPEL",
				"mechanic_hint": "RING CATACOMB BELLS TO BANISH ECHOES  •  WATCH THE GOLD CHARM",
				"is_campaign": true,
				"is_secret": true,
				"campaign_index": 6,
				"max_hp": 560.0,
				"max_posture": 155.0,
				"posture_drain": 9.5,
				"phase2_ratio": 0.66,
				"phase3_ratio": 0.33,
				"hitbox_radius": 14.0,
				"spawn_pos": Vector2(236.0, 100.0),
				"accent": Color("#9ecae8"),
				"accent_hi": Color("#e5f6ff"),
				"bar_color": Color("#6d97ba"),
				"phase_titles": ["", "PHASE II  •  HOLLOW ECHOES", "PHASE III  •  FINAL REQUIEM"],
				"phase_quotes": [
					"",
					"Every echo in this dust remembers what you did to me...",
					"Let the final chime settle this debt once and for all!"
				],
				"intro_lines": [
					{"speaker": "CHOKO", "text": "...This catacomb wasn't on any map. Hey—are you guarding something down here?"},
					{"speaker": "THE DEAD CAT", "text": "*A cold, hollow chime rings through the dust—then a spectral whisper answers...*"},
					{"speaker": "THE DEAD CAT", "text": "I have waited beneath the chapel in the dark... I will take my revenge for the murder you committed upon me!"},
					{"speaker": "CHOKO", "text": "Wait—murder?! I don't even know who you are! ...Okay, guess I have to survive this first."},
				],
				"victory_lines": [
					{"speaker": "THE DEAD CAT", "text": "*One last sorrowful chime fades into the dust. The vengeful silhouette dissolves without a sound.*"},
					{"speaker": "CHOKO", "text": "A small tarnished bell charm... No name on it. Just an old mine tag."},
					{"speaker": "CHOKO", "text": "Whoever you were—whatever really happened down here—rest easy now."},
				],
				"veins": [
					Vector2(42.0, 78.0),
					Vector2(160.0, 139.0),
					Vector2(280.0, 78.0),
				],
				"catacomb_bells": [
					Vector2(70.0, 68.0),
					Vector2(250.0, 132.0),
				],
			}
		_:
			return {
				"id": "sentinel",
				"name": "QUARRY SENTINEL",
				"title": "NON-CAMPAIGN PRACTICE CONSTRUCT",
				"arena_name": "QUARRY TRAINING CHAMBER",
				"mechanic_hint": "PRACTICE PERFECT DODGE → COUNTER STRIKE (1.6X) & POSTURE BREAK",
				"is_campaign": false,
				"is_secret": false,
				"campaign_index": 0,
				"max_hp": 180.0,
				"max_posture": 80.0,
				"posture_drain": 4.0,
				"phase2_ratio": 0.667,
				"phase3_ratio": 0.333,
				"hitbox_radius": 14.0,
				"spawn_pos": Vector2(232.0, 104.0),
				"accent": Color("#77d8d0"),
				"accent_hi": Color("#c1fff0"),
				"bar_color": Color("#b75d59"),
				"phase_titles": ["", "PHASE II  •  TRIPLE VOLLEY", "PHASE III  •  FIVE-BOLT FAN"],
				"phase_quotes": ["", "", ""],
				"intro_lines": [
					{"speaker": "TRAINING NOTE", "text": "Practice construct only — not a campaign boss. Practice Perfect Dodge -> Counter-Strike and Posture Breaks."},
				],
				"victory_lines": [
					{"speaker": "TRAINING NOTE", "text": "Sentinel disarmed. Ready for the underground campaign."},
				],
				"veins": [
					Vector2(42.0, 77.0),
					Vector2(155.0, 137.0),
					Vector2(286.0, 76.0),
				],
			}

static func get_dead_cat_discovery_lines() -> Array:
	return [
		{"speaker": "CHAPEL RUINS", "text": "After Grandfather falls, the buried chapel goes quiet—and his heaters finally cool."},
		{"speaker": "CHAPEL RUINS", "text": "Behind a cracked stone seam, a tiny service light blinks steadily."},
		{"speaker": "MAINTENANCE PASSAGE", "text": "Choko squeezes into a narrow forgotten tunnel. Distant mine machinery stops completely."},
		{"speaker": "SEALED CATACOMB", "text": "Only a soft, eerie bell-like chime echoes across fresh paw tracks in the dust."},
	]

static func get_plane_escape_lines() -> Array:
	return [
		{"speaker": "QUARRY AIRSTRIP", "text": "Cold dawn air hits the freight lift. For the first time, there is sky overhead."},
		{"speaker": "FARHAN", "text": "Engine's warm and the runway lights are clear! Climb in, Choko!"},
		{"speaker": "CHOKO", "text": "No more dungeon, no more coal heaters. We're finally leaving—together."},
		{"speaker": "THE LAST SHIFT", "text": "The little prop plane lifts clear of the coal ridge and vanishes into the morning sky."},
	]

static func get_prologue_lines() -> Array:
	return [
		{"speaker": "THE SHIFT", "text": "Deep beneath the coal ridge, another endless shift grinds on to feed Grandfather's heaters."},
		{"speaker": "CHOKO", "text": "Wait... wedged under this coal seam—that's Farhan's old brass signal token!"},
		{"speaker": "CHOKO", "text": "There's a scratch map on the back. The old freight lift past the five sealed shafts still works!"},
		{"speaker": "CHOKO", "text": "Farhan's waiting down at the Explosives Depot first. Grab the pickaxe—tonight is our last shift."},
	]

static func get_shaft_transition(boss_id: String) -> Dictionary:
	match boss_id:
		"farhan":
			return {"kicker": "SHAFT I", "title": "SUBTERRANEAN EXPLOSIVES DEPOT", "sub": "Floodlights hum behind the heavy blast shutters..."}
		"allan":
			return {"kicker": "SHAFT II", "title": "LIGHTLESS ROOT CATHEDRAL", "sub": "The air turns cold. Glowing white cotton clings to bare coal..."}
		"john_paul":
			return {"kicker": "SHAFT III", "title": "DRAINAGE SHAFT & RAIL STATION", "sub": "Steam hisses through wet stone culverts—and claws scrape the walls..."}
		"aaron":
			return {"kicker": "SHAFT IV", "title": "THE FOSSIL CRYPT", "sub": "Candlelight flickers inside ancient carved bone arches..."}
		"grandfather":
			return {"kicker": "SHAFT V", "title": "THE BURIED CHAPEL", "sub": "Coal heaters roar beneath a deep tolling bronze bell..."}
		"dead_cat":
			return {"kicker": "SEALED CATACOMB", "title": "BEYOND THE CRACKED SEAM", "sub": "Machinery falls silent. Only a cold chime answers..."}
		_:
			return {"kicker": "TRAINING CHAMBER", "title": "QUARRY SENTINEL PRACTICE", "sub": "Sharpen your footing and Perfect Dodge timing..."}

static func next_campaign_boss(current_id: String) -> String:
	var idx := CAMPAIGN_ORDER.find(current_id)
	if idx >= 0 and idx + 1 < CAMPAIGN_ORDER.size():
		return CAMPAIGN_ORDER[idx + 1]
	return ""
