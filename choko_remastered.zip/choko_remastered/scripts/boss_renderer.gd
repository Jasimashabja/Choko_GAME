extends RefCounted

## CHOKO — Phase 3.1: Souls-Like Boss, Interactive Element, Glint & Choko Renderer.
## Renders all 7 lore-accurate procedural silhouettes, Souls-like delayed-attack
## glint flashes, Farhan tripwires/batted bombs/cinders, Allan blight/snuff vines,
## Aaron reassembly bone shards/stalactites, Grandfather Coal-Heart crystals/tethers,
## and Choko's Counter-Strike Ready cyan aura.

const BossController := preload("res://scripts/boss_controller.gd")
const SpriteBank := preload("res://scripts/sprite_bank.gd")

const C_TEXT := Color("#eee5cf")
const C_WARM := Color("#e5ad68")
const C_WARM_HI := Color("#ffd18a")
const C_RED := Color("#e66a61")
const C_CYAN := Color("#77d8d0")
const C_CYAN_HI := Color("#c1fff0")

static func draw_hazards_under(canvas: CanvasItem, boss: BossController, elapsed: float) -> void:
	# Lingering floor zones (Allan pale blight pools & Farhan scorching cinder zones)
	for bz in boss.blight_zones:
		var bp: Vector2 = bz["pos"]
		var rad := float(bz["radius"])
		var kind := str(bz["kind"])
		var pulse := 0.75 + 0.25 * sin(elapsed * 8.0 + bp.x)
		if kind == "cinder":
			canvas.draw_circle(bp, rad, Color(0.95, 0.36, 0.18, 0.26 * pulse))
			canvas.draw_arc(bp, rad, 0.0, TAU, 18, Color(1.0, 0.68, 0.30, 0.65), 1.2)
		else:
			canvas.draw_circle(bp, rad, Color(0.88, 0.94, 0.98, 0.24 * pulse))
			canvas.draw_arc(bp, rad, 0.0, TAU, 18, Color(1.0, 1.0, 1.0, 0.65), 1.1)

	# Farhan Blast Shutter Tripwire lasers
	for tw in boss.tripwires:
		var a: Vector2 = tw["a"]
		var b: Vector2 = tw["b"]
		var arm := float(tw["arm_t"])
		if arm > 0.0:
			canvas.draw_line(a, b, Color(1.0, 0.72, 0.32, 0.32), 1.0)
		else:
			var p := 0.55 + 0.45 * sin(elapsed * 24.0)
			canvas.draw_line(a, b, Color(1.0, 0.28, 0.22, 0.45), 3.0)
			canvas.draw_line(a, b, Color(1.0, 0.82, 0.52, p), 1.0)
			canvas.draw_circle(a, 2.5, C_RED)
			canvas.draw_circle(b, 2.5, C_RED)

	# Ground hazards (roots, stalactites, trip blasts, cane quakes, rib crush, paw nodes, 3-heart cataclysms)
	for h in boss.ground_hazards:
		var kind := str(h["kind"])
		var tele := float(h["telegraph"])
		var max_t := maxf(0.01, float(h.get("max_telegraph", 0.6)))
		var dmg := int(h.get("damage", 1))
		var pulse := 0.5 + 0.5 * sin(elapsed * 20.0)

		if kind == "cataclysm_bell":
			if tele > 0.0:
				var fill_r := 1.0 - (tele / max_t)
				canvas.draw_rect(Rect2(13, 52, 294, 96), Color(0.85, 0.15, 0.15, 0.08 + fill_r * 0.22))
				for sc in h.get("safe_circles", []):
					var sp: Vector2 = sc["pos"]
					var sr := float(sc["radius"])
					canvas.draw_circle(sp, sr, Color(0.25, 0.92, 0.88, 0.24 + pulse * 0.10))
					canvas.draw_arc(sp, sr, 0.0, TAU, 24, Color("#c1fff0"), 2.0)
					canvas.draw_arc(sp, sr * (1.0 - fill_r), 0.0, TAU, 20, Color("#77d8d0"), 1.0)
					canvas.draw_string(ThemeDB.fallback_font, sp + Vector2(-12, 3), "SAFE", HORIZONTAL_ALIGNMENT_LEFT, -1.0, 7, Color("#c1fff0"))
			else:
				canvas.draw_rect(Rect2(13, 52, 294, 96), Color(1.0, 0.30, 0.22, 0.48))
				for sc in h.get("safe_circles", []):
					canvas.draw_circle(Vector2(sc["pos"]), float(sc["radius"]), Color(0.18, 0.85, 0.82, 0.35))
			continue

		if kind == "cataclysm_requiem":
			var sr: Rect2 = h.get("safe_rect", Rect2())
			if tele > 0.0:
				var fill_r := 1.0 - (tele / max_t)
				canvas.draw_rect(Rect2(13, 52, 294, 96), Color(0.45, 0.16, 0.32, 0.10 + fill_r * 0.24))
				canvas.draw_rect(sr, Color(0.42, 0.88, 0.96, 0.24 + pulse * 0.10))
				canvas.draw_rect(Rect2(sr.position.x, sr.position.y, 2, sr.size.y), Color("#e5f6ff"))
				canvas.draw_rect(Rect2(sr.position.x + sr.size.x - 2, sr.position.y, 2, sr.size.y), Color("#e5f6ff"))
				canvas.draw_string(ThemeDB.fallback_font, sr.position + Vector2(5, 50), "SAFE", HORIZONTAL_ALIGNMENT_LEFT, -1.0, 7, Color("#e5f6ff"))
			else:
				canvas.draw_rect(Rect2(13, 52, 294, 96), Color(0.75, 0.88, 1.0, 0.45))
				canvas.draw_rect(sr, Color(0.16, 0.30, 0.42, 0.5))
			continue

		if h.has("rect") and Rect2(h["rect"]).size.length() > 1.0:
			var r: Rect2 = h["rect"]
			if tele > 0.0:
				var prog := 1.0 - (tele / max_t)
				canvas.draw_rect(r, Color(0.92, 0.28, 0.24, 0.10 + prog * 0.18))
				canvas.draw_rect(Rect2(r.position.x, r.position.y, r.size.x, 2), Color("#e66a61"))
				canvas.draw_rect(Rect2(r.position.x, r.position.y + r.size.y - 2, r.size.x, 2), Color("#e66a61"))
			else:
				canvas.draw_rect(r, Color(0.95, 0.90, 0.78, 0.65))
			continue

		var hp: Vector2 = h["pos"]
		var rad := float(h.get("radius", 14.0))
		var col: Color = h.get("color", C_RED)
		if tele > 0.0:
			var prog := 1.0 - (tele / max_t)
			var ring_col := C_RED if dmg >= 2 else col
			canvas.draw_circle(hp, rad, Color(ring_col.r, ring_col.g, ring_col.b, 0.10 + prog * 0.16))
			canvas.draw_arc(hp, rad, 0.0, TAU, 20, ring_col, 1.6 if dmg >= 2 else 1.1)
			canvas.draw_arc(hp, rad * prog, 0.0, TAU, 16, C_WARM_HI if dmg >= 2 else ring_col, 1.0)
			if kind == "paw_node":
				canvas.draw_circle(hp, 3.0, Color("#e5f6ff"))
				canvas.draw_circle(hp + Vector2(-4, -4), 1.5, Color("#e5f6ff"))
				canvas.draw_circle(hp + Vector2(0, -6), 1.5, Color("#e5f6ff"))
				canvas.draw_circle(hp + Vector2(4, -4), 1.5, Color("#e5f6ff"))
			elif kind == "stalactite":
				# Falling fossil shadow shrinking & bone descending from ceiling
				var drop_h := (1.0 - prog) * 34.0
				canvas.draw_colored_polygon(PackedVector2Array([
					hp + Vector2(-4, -drop_h - 10), hp + Vector2(4, -drop_h - 10), hp + Vector2(0, -drop_h)
				]), Color("#fff8e6"))
		else:
			if kind == "root_spike":
				canvas.draw_circle(hp, rad, Color(0.94, 0.97, 1.0, 0.24))
				for k in range(5):
					var ang := float(k) * (TAU / 5.0)
					canvas.draw_line(hp, hp + Vector2.RIGHT.rotated(ang) * rad, Color("#ffffff"), 2.0)
				canvas.draw_colored_polygon(PackedVector2Array([
					hp + Vector2(-5, 3), hp + Vector2(0, -14), hp + Vector2(5, 3)
				]), Color("#ffffff"))
			else:
				canvas.draw_circle(hp, rad, Color(col.r, col.g, col.b, 0.42))
				canvas.draw_arc(hp, rad, 0.0, TAU, 20, C_TEXT, 2.0)

	# Grandfather Coal-Heart Anchor Crystals + pulsing dark-amber tether beams!
	for c in boss.crystals:
		var cp: Vector2 = c["pos"]
		var fl := float(c.get("flash", 0.0))
		var pulse := 0.65 + 0.35 * sin(elapsed * 10.0 + cp.x)
		canvas.draw_line(cp + Vector2(0, -6), boss.pos + Vector2(0, -8), Color(0.96, 0.44, 0.28, 0.38 * pulse), 3.0)
		canvas.draw_line(cp + Vector2(0, -6), boss.pos + Vector2(0, -8), Color(1.0, 0.84, 0.52, 0.78 * pulse), 1.0)
		canvas.draw_circle(cp, 12.0, Color(0.95, 0.45, 0.28, 0.16 * pulse))
		var col := C_TEXT if fl > 0.0 else Color("#e86f5c")
		canvas.draw_colored_polygon(PackedVector2Array([
			cp + Vector2(0, -14), cp + Vector2(7, -4), cp + Vector2(4, 4),
			cp + Vector2(-4, 4), cp + Vector2(-7, -4)
		]), col)
		canvas.draw_rect(Rect2(cp.x - 2, cp.y - 8, 4, 6), Color("#ffd08a"))

	# Runaway mine cart track warnings
	for c in boss.mine_carts:
		var cy := float(c["y"])
		if float(c["telegraph"]) > 0.0:
			var pulse := 0.5 + 0.5 * sin(elapsed * 22.0)
			canvas.draw_rect(Rect2(10, cy - 10, 300, 20), Color(0.95, 0.25, 0.22, 0.14 + pulse * 0.14))
			canvas.draw_line(Vector2(10, cy - 6), Vector2(310, cy - 6), Color("#ffd08a"), 1.0)
			canvas.draw_line(Vector2(10, cy + 6), Vector2(310, cy + 6), Color("#ffd08a"), 1.0)
			canvas.draw_string(ThemeDB.fallback_font, Vector2(122, cy + 3), "!! 2-HEART CART !!", HORIZONTAL_ALIGNMENT_LEFT, -1.0, 7, Color("#ffd08a"))
		else:
			var cp: Vector2 = c["pos"]
			canvas.draw_rect(Rect2(cp.x - 14, cp.y - 9, 28, 16), Color("#4c4652"))
			canvas.draw_rect(Rect2(cp.x - 12, cp.y - 7, 24, 9), Color("#262229"))
			canvas.draw_rect(Rect2(cp.x - 9, cp.y - 10, 18, 4), Color("#e86f5c"))
			canvas.draw_circle(cp + Vector2(-8, 7), 3.0, Color("#15141c"))
			canvas.draw_circle(cp + Vector2(8, 7), 3.0, Color("#15141c"))

	# Rising stone pillars (Grandfather)
	for pl in boss.pillars:
		var pp: Vector2 = pl["pos"]
		var r := float(pl["radius"])
		if float(pl["telegraph"]) > 0.0:
			canvas.draw_circle(pp, r, Color(0.92, 0.45, 0.36, 0.18))
			canvas.draw_arc(pp, r, 0.0, TAU, 16, Color("#e86f5c"), 1.4)
		else:
			canvas.draw_rect(Rect2(pp.x - 9, pp.y - 18, 18, 22), Color("#594f5c"))
			canvas.draw_rect(Rect2(pp.x - 7, pp.y - 20, 14, 5), Color("#857787"))
			canvas.draw_rect(Rect2(pp.x - 9, pp.y + 3, 18, 3), Color("#2e2630"))

	# Rotating mine-shaft beams (Grandfather P3)
	for sb in boss.shaft_beams:
		var ctr: Vector2 = sb["center"]
		var ang := float(sb["angle"])
		var length := float(sb["length"])
		var a := ctr - Vector2.RIGHT.rotated(ang) * length
		var b := ctr + Vector2.RIGHT.rotated(ang) * length
		if float(sb["telegraph"]) > 0.0:
			canvas.draw_line(a, b, Color(1.0, 0.42, 0.32, 0.45), 2.0)
		else:
			canvas.draw_line(a, b, Color(1.0, 0.45, 0.28, 0.35), 9.0)
			canvas.draw_line(a, b, Color("#ffd08a"), 3.0)
			canvas.draw_circle(ctr, 5.0, Color("#ffd08a"))

	# Closing rib barriers (Aaron)
	for w in boss.rib_walls:
		var wx := float(w["x"])
		var gap_y := float(w["gap_y"])
		var half_g := float(w["gap_h"]) * 0.5
		if float(w["telegraph"]) > 0.0:
			canvas.draw_rect(Rect2(wx - 3, 52, 6, maxf(0.0, (gap_y - half_g) - 52.0)), Color(0.95, 0.90, 0.78, 0.30))
			canvas.draw_rect(Rect2(wx - 3, gap_y + half_g, 6, maxf(0.0, 148.0 - (gap_y + half_g))), Color(0.95, 0.90, 0.78, 0.30))
		else:
			var top_h := maxf(0.0, (gap_y - half_g) - 52.0)
			var bot_y := gap_y + half_g
			var bot_h := maxf(0.0, 148.0 - bot_y)
			canvas.draw_rect(Rect2(wx - 4, 52, 8, top_h), Color("#ded5be"))
			canvas.draw_rect(Rect2(wx - 4, bot_y, 8, bot_h), Color("#ded5be"))
			for ry in range(54, int(gap_y - half_g), 6):
				canvas.draw_line(Vector2(wx - 4, ry), Vector2(wx + 4, ry), Color("#63594f"), 1.0)
			for ry in range(int(bot_y) + 2, 148, 6):
				canvas.draw_line(Vector2(wx - 4, ry), Vector2(wx + 4, ry), Color("#63594f"), 1.0)

	# Delayed Cut / Slash Lines (John Paul X-Slash, Aaron Bone Lance, Dead Cat Phantom Blink!)
	for sl in boss.slash_lines:
		var sa: Vector2 = sl["a"]
		var sb: Vector2 = sl["b"]
		var tele := float(sl["telegraph"])
		var max_t := maxf(0.01, float(sl.get("max_telegraph", 0.4)))
		var col: Color = sl.get("color", Color("#e5f6ff"))
		if tele > 0.0:
			var prog := 1.0 - (tele / max_t)
			canvas.draw_line(sa, sb, Color(col.r, col.g, col.b, 0.28 + prog * 0.55), 1.0 + prog * 2.0)
			canvas.draw_circle(sa, 3.0, col)
			canvas.draw_circle(sb, 3.0, col)
		else:
			canvas.draw_line(sa, sb, Color(col.r, col.g, col.b, 0.55), 11.0)
			canvas.draw_line(sa, sb, Color("#ffffff"), 3.5)

	# Chime Pulse Rings (Dead Cat & Grandfather Bell Toll)
	for pr in boss.pulse_rings:
		var ctr: Vector2 = pr["center"]
		var r := float(pr["radius"])
		if r <= 2.0:
			continue
		var gap_a := float(pr["gap_angle"])
		var half_gap := float(pr["gap_width"]) * 0.5
		canvas.draw_arc(ctr, r, gap_a + half_gap, gap_a + TAU - half_gap, 36, Color(0.62, 0.80, 0.94, 0.35), 5.0)
		canvas.draw_arc(ctr, r, gap_a + half_gap, gap_a + TAU - half_gap, 36, Color("#e5f6ff"), 1.8)

	# Farhan timed bombs (including cyan-glowing Batted Bombs!)
	for b in boss.bombs:
		var tp: Vector2 = b["target_pos"]
		var rad := float(b["radius"])
		var dmg := int(b["damage"])
		var batted := bool(b.get("batted", false))
		if bool(b["exploded"]):
			var bf := clampf(float(b["blast_flash"]) / 0.24, 0.0, 1.0)
			var bcol := Color(0.45, 0.95, 0.90, bf * 0.6) if batted else Color(1.0, 0.62, 0.26, bf * 0.55)
			canvas.draw_circle(tp, rad, bcol)
			canvas.draw_arc(tp, rad, 0.0, TAU, 24, Color(1.0, 0.95, 0.80, bf), 2.2)
			continue
		var bp: Vector2 = b["pos"]
		if batted:
			canvas.draw_circle(bp, 7.0, Color(0.48, 0.95, 0.90, 0.35))
			canvas.draw_circle(bp, 4.5, C_CYAN_HI)
			continue
		var fuse := float(b["fuse"])
		var max_f := maxf(0.01, float(b["max_fuse"]))
		var fuse_prog := 1.0 - clampf(fuse / max_f, 0.0, 1.0)
		var ring_c := C_RED if dmg >= 2 else C_WARM
		canvas.draw_circle(tp, rad, Color(ring_c.r, ring_c.g, ring_c.b, 0.08 + fuse_prog * 0.14))
		canvas.draw_arc(tp, rad, 0.0, TAU, 22, ring_c, 1.5 if dmg >= 2 else 1.0)
		canvas.draw_arc(tp, rad * fuse_prog, 0.0, TAU, 18, Color("#ffe0a3"), 1.0)
		var ft := float(b["flight_t"])
		var fdur := maxf(0.01, float(b["flight_dur"]))
		var arc_h := sin(clampf(ft / fdur, 0.0, 1.0) * PI) * 18.0
		var bdraw := bp + Vector2(0, -arc_h)
		var sz := 5.0 if dmg >= 2 else 3.5
		canvas.draw_circle(bdraw, sz, Color("#24242f"))
		canvas.draw_arc(bdraw, sz, 0.0, TAU, 12, ring_c, 1.2)
		var spark_col := Color("#ffffff") if int(elapsed * 24.0) % 2 == 0 else Color("#ffd18a")
		canvas.draw_rect(Rect2(bdraw.x - 1, bdraw.y - sz - 3, 2, 3), spark_col)

static func draw_minions_and_decoys(canvas: CanvasItem, boss: BossController, elapsed: float) -> void:
	# Allan's crawling snuffing white vines
	for sv in boss.snuff_vines:
		var sp: Vector2 = sv["pos"]
		var idx := int(sv["target_idx"])
		if idx >= 0 and idx < boss.braziers.size():
			canvas.draw_line(sp, Vector2(boss.braziers[idx]["pos"]), Color(0.95, 0.98, 1.0, 0.22), 1.0)
		var wig := sin(elapsed * 16.0 + sp.x) * 2.0
		canvas.draw_circle(sp, 6.0, Color(0.92, 0.96, 1.0, 0.22))
		canvas.draw_line(sp + Vector2(-5, wig), sp + Vector2(5, -wig), Color("#ffffff"), 2.2)
		canvas.draw_circle(sp, 3.0, Color("#ffffff"))

	# Aaron's sliding reassembly bone shards
	for bs in boss.bone_shards:
		var bp: Vector2 = bs["pos"]
		canvas.draw_line(bp, boss.pos, Color(0.94, 0.90, 0.78, 0.24), 1.0)
		canvas.draw_circle(bp, 5.0, Color(1.0, 0.92, 0.65, 0.24))
		canvas.draw_rect(Rect2(bp.x - 3, bp.y - 2, 6, 4), Color("#fff8e6"))

	# Aaron's bone minions
	for m in boss.minions:
		var mp: Vector2 = m["pos"]
		var bob := sin(elapsed * 10.0 + mp.x) * 1.0
		var col := Color("#ffffff") if float(m.get("flash", 0.0)) > 0.0 else Color("#ded5be")
		canvas.draw_rect(Rect2(mp.x - 5, mp.y + 4, 10, 2), Color(0, 0, 0, 0.3))
		canvas.draw_rect(Rect2(mp.x - 4, mp.y - 6 + bob, 8, 7), col)
		canvas.draw_rect(Rect2(mp.x - 3, mp.y - 4 + bob, 2, 2), Color("#1a171c"))
		canvas.draw_rect(Rect2(mp.x + 1, mp.y - 4 + bob, 2, 2), Color("#1a171c"))
		canvas.draw_rect(Rect2(mp.x - 3, mp.y + 1 + bob, 6, 4), Color("#bfb59c"))

	# Dead Cat's echo decoys (no warm gold bell charm — sharp players spot the real one!)
	for d in boss.decoys:
		var dp: Vector2 = d["pos"]
		if float(d["telegraph"]) > 0.0:
			var tgt: Vector2 = d["target"]
			canvas.draw_line(dp, tgt, Color(0.62, 0.80, 0.94, 0.35), 1.0)
		_draw_cat_silhouette(canvas, dp, 0.50, elapsed, false)

static func draw_boss(canvas: CanvasItem, boss: BossController, sprites: SpriteBank, elapsed: float) -> void:
	var p: Vector2 = boss.pos
	for row in range(3):
		var rw := 18.0 * (1.0 - absf(float(row - 1)) * 0.22)
		canvas.draw_rect(Rect2(p.x - rw, p.y + 5 + row * 2, rw * 2.0, 2), Color(0.0, 0.0, 0.0, 0.34 * boss.visible_alpha))

	if boss.is_vulnerable() and boss.hp > 0.0:
		var vp := 0.55 + 0.45 * sin(elapsed * 12.0)
		canvas.draw_arc(p + Vector2(0, -2), boss.get_hitbox_radius() + 5.0, 0.0, TAU, 24, Color(1.0, 0.82, 0.48, vp), 1.6)

	if boss.state == "telegraph" and boss.hp > 0.0:
		_draw_boss_telegraph(canvas, boss, elapsed)

	var drew_sprite := false
	if sprites != null and sprites.has_sheet(boss.id):
		drew_sprite = _draw_boss_sprite(canvas, boss, sprites, elapsed)

	if not drew_sprite:
		match str(boss.id):
			"farhan":
				_draw_farhan(canvas, boss, elapsed)
			"allan":
				_draw_allan(canvas, boss, elapsed)
			"john_paul":
				_draw_john_paul(canvas, boss, elapsed)
			"aaron":
				_draw_aaron(canvas, boss, elapsed)
			"grandfather":
				_draw_grandfather(canvas, boss, elapsed)
			"dead_cat":
				_draw_dead_cat(canvas, boss, elapsed)
			_:
				_draw_sentinel(canvas, boss, elapsed)

	# Souls-like Glint Star right before delayed strikes release (read this to Perfect Dodge!)
	if boss.glint_active and boss.hp > 0.0:
		var gp := p + Vector2(0, -16)
		var gcol := Color("#ffffff") if boss.attack_damage < 2 else Color("#ffd18a")
		canvas.draw_circle(gp, 6.0, Color(gcol.r, gcol.g, gcol.b, 0.45))
		canvas.draw_line(gp + Vector2(-11, 0), gp + Vector2(11, 0), Color("#ffffff"), 1.6)
		canvas.draw_line(gp + Vector2(0, -11), gp + Vector2(0, 11), Color("#ffffff"), 1.6)
		canvas.draw_line(gp + Vector2(-6, -6), gp + Vector2(6, 6), gcol, 1.0)
		canvas.draw_line(gp + Vector2(6, -6), gp + Vector2(-6, 6), gcol, 1.0)

	if boss.attack_flash > 0.0:
		var ac: Color = boss.cfg.get("accent_hi", C_CYAN_HI)
		canvas.draw_circle(p, 15.0, Color(ac.r, ac.g, ac.b, 0.24))

	if boss.state == "phase_shift":
		var prog := 1.0 - clampf(boss.state_timer / maxf(0.01, boss.state_duration), 0.0, 1.0)
		var ac: Color = boss.cfg.get("accent_hi", C_WARM_HI)
		canvas.draw_arc(p, 10.0 + prog * 36.0, 0.0, TAU, 28, Color(ac.r, ac.g, ac.b, 1.0 - prog), 2.2)

static func _draw_boss_sprite(canvas: CanvasItem, boss: BossController, sprites: SpriteBank, elapsed: float) -> bool:
	# Drawn inside 2x world transform: 0.5 draw_scale maps 64x64/72x72/96x96 sprites 1:1 to 640x360!
	var recoil := Vector2(randf_range(-1.8, 1.8), randf_range(-1.2, 1.2)) if boss.hit_flash > 0.0 else Vector2.ZERO
	var p: Vector2 = boss.pos + recoil
	var flip_h := boss.facing.x > 0.15
	var mod := Color(1.0, 1.0, 1.0, boss.visible_alpha)
	if boss.flash > 0.0:
		mod = Color(1.8, 1.8, 1.8, boss.visible_alpha)
	var bob := sin(elapsed * 4.5) * 1.2 if boss.hp > 0.0 else 0.0

	match str(boss.id):
		"farhan":
			var col := 3 if (boss.hp <= 0.0 or boss.state == "staggered") else (2 if boss.state == "telegraph" else (1 if (boss.state == "reposition" or boss.state == "active") else 0))
			return sprites.draw_frame(canvas, "farhan", col, 0, 64, 64, p + Vector2(0, -9 + bob), flip_h, mod, 0.5)
		"allan":
			if boss.hp <= 0.0:
				for i in range(7):
					canvas.draw_circle(p + Vector2(float(i - 3) * 5.0, sin(float(i)) * 4.0), 2.0, Color("#ffffff"))
				return true
			var col := 3 if boss.state == "staggered" else (2 if (boss.state == "telegraph" or boss.state == "active") else (1 if boss.shadow_veiled else 0))
			if boss.state == "active" and boss.attack_id == "thorn_sweep":
				if boss.attack_step == 2:
					canvas.draw_arc(p, 70.0, 0.0, TAU, 32, Color("#ffffff"), 4.5)
				else:
					var ang: float = boss.attack_dir.angle()
					canvas.draw_arc(p, 68.0, ang - 1.15, ang + 1.15, 22, Color("#ffffff"), 4.0)
			return sprites.draw_frame(canvas, "allan", col, 0, 72, 72, p + Vector2(0, -10 + sin(elapsed * 2.6) * 1.6), flip_h, mod, 0.5)
		"john_paul":
			var col := 3 if (boss.hp <= 0.0 or boss.state == "staggered" or boss.state == "recovery") else (2 if boss.state == "active" else (1 if (boss.wall_side != 0 or boss.state == "telegraph") else 0))
			return sprites.draw_frame(canvas, "john_paul", col, 0, 64, 64, p + Vector2(0, -9 + bob), flip_h, mod, 0.5)
		"aaron":
			var col := 3 if (boss.hp <= 0.0 or boss.disassembled) else (2 if boss.state == "active" else (1 if boss.state == "telegraph" else 0))
			var rattle := sin(elapsed * 26.0) * 1.3 if (boss.disassembled and boss.hp > 0.0) else 0.0
			return sprites.draw_frame(canvas, "aaron", col, 0, 64, 64, p + Vector2(rattle, -9 + bob), flip_h, mod, 0.5)
		"grandfather":
			# Visibly elderly across ALL 3 phases (P1=col 0, P2=col 1, P3/Bell=col 2, Staggered/Weary=col 3)
			var col := 3 if (boss.hp <= 0.0 or boss.state == "staggered") else (2 if (boss.phase >= 3 or boss.attack_id == "bell_toll_cataclysm") else (1 if boss.phase >= 2 else 0))
			if boss.phase >= 2 and boss.hp > 0.0:
				var aura_c := Color(0.92, 0.34, 0.25, 0.20) if boss.phase >= 3 else Color(0.28, 0.14, 0.26, 0.34)
				canvas.draw_circle(p + Vector2(0, -10 + bob), 24.0, aura_c)
			var sc := 0.50 if boss.phase == 1 else (0.55 if boss.phase == 2 else 0.58)
			return sprites.draw_frame(canvas, "grandfather", col, 0, 96, 96, p + Vector2(0, -14 + bob), flip_h, mod, sc)
		"dead_cat":
			var col := 3 if boss.hp <= 0.0 else (2 if (boss.state == "active" or boss.attack_id == "chime_pulse" or boss.attack_id == "double_chime") else (1 if int(elapsed * 5.0) % 2 == 0 else 0))
			return sprites.draw_frame(canvas, "dead_cat", col, 0, 64, 64, p + Vector2(0, -9 + sin(elapsed * 3.4) * 1.4), flip_h, mod, 0.5)
		_:
			var col := 2 if boss.hp <= 0.0 else (1 if boss.state == "telegraph" else 0)
			canvas.draw_circle(p, 28.0, Color(0.25, 0.83, 0.81, 0.12 + 0.04 * sin(elapsed * 4.0)))
			return sprites.draw_frame(canvas, "sentinel", col, 0, 72, 72, p + Vector2(0, -9 + sin(elapsed * 2.2) * 1.0), false, mod, 0.5)

static func _draw_boss_telegraph(canvas: CanvasItem, boss: BossController, elapsed: float) -> void:
	var p: Vector2 = boss.pos
	var pulse := 0.5 + 0.5 * sin(elapsed * 24.0)
	var dmg: int = boss.attack_damage
	var tcol := Color("#ff4d4d") if dmg >= 3 else (C_RED if dmg == 2 else C_WARM)

	if boss.id == "sentinel":
		var origin := p + Vector2(0, -2)
		canvas.draw_line(origin, boss.attack_target, Color(1.0, 0.30, 0.26, 0.14 + pulse * 0.22), 1.0)
		canvas.draw_circle(boss.attack_target, 8.0 + pulse * 2.5, Color(1.0, 0.32, 0.25, 0.08 + pulse * 0.12))
		canvas.draw_arc(boss.attack_target, 8.0 + pulse * 2.5, 0.0, TAU, 24, Color("#f17869"), 1.2)
		canvas.draw_arc(boss.attack_target, 13.0, elapsed * 2.4, elapsed * 2.4 + PI * 1.5, 18, Color(1.0, 0.55, 0.42, 0.55), 1.0)
		return

	var excl := "!!!" if dmg >= 3 else ("!!" if dmg == 2 else "!")
	canvas.draw_string(ThemeDB.fallback_font, p + Vector2(-4.0 * float(excl.length()) * 0.5, -26), excl, HORIZONTAL_ALIGNMENT_LEFT, -1.0, 7 if dmg >= 2 else 6, tcol)

	if boss.attack_id == "wall_pounce" or boss.attack_id == "predator_pounce" or boss.attack_id == "feint_swipe" or boss.attack_id == "echo_split":
		var end_p: Vector2 = p + boss.attack_dir * (190.0 if boss.id == "john_paul" else 90.0)
		canvas.draw_line(p, end_p, Color(tcol.r, tcol.g, tcol.b, 0.30 + pulse * 0.35), 2.5 if dmg >= 2 else 1.5)
		canvas.draw_arc(p, 16.0 + pulse * 3.0, 0.0, TAU, 20, tcol, 1.5)
	elif boss.attack_id == "thorn_sweep":
		if boss.attack_step == 2:
			canvas.draw_arc(p, 70.0, 0.0, TAU, 32, Color(1.0, 0.38, 0.34, 0.72), 2.4)
		else:
			var ang: float = boss.attack_dir.angle()
			canvas.draw_arc(p, 70.0, ang - 1.15, ang + 1.15, 22, Color(1.0, 0.38, 0.34, 0.68), 2.2)
			canvas.draw_line(p, p + Vector2.RIGHT.rotated(ang - 1.15) * 70.0, Color(1.0, 0.38, 0.34, 0.55), 1.2)
			canvas.draw_line(p, p + Vector2.RIGHT.rotated(ang + 1.15) * 70.0, Color(1.0, 0.38, 0.34, 0.55), 1.2)
	elif dmg >= 2:
		canvas.draw_arc(p, 20.0 + pulse * 4.0, 0.0, TAU, 24, tcol, 1.8)
		canvas.draw_arc(p, 14.0, 0.0, TAU, 20, C_WARM_HI, 1.0)
	else:
		canvas.draw_arc(p, 15.0 + pulse * 2.5, 0.0, TAU, 18, Color(tcol.r, tcol.g, tcol.b, 0.65), 1.2)

static func _draw_farhan(canvas: CanvasItem, boss: BossController, elapsed: float) -> void:
	var p: Vector2 = boss.pos
	if boss.hp <= 0.0:
		canvas.draw_rect(Rect2(p.x - 7, p.y - 3, 14, 9), Color("#b5623d"))
		canvas.draw_rect(Rect2(p.x - 4, p.y - 10, 8, 7), Color("#e8be96"))
		canvas.draw_rect(Rect2(p.x - 5, p.y - 12, 10, 3), Color("#26212c"))
		return
	var bob: float = sin(elapsed * 8.0) * 1.1 if (boss.state == "reposition" or boss.state == "active") else sin(elapsed * 3.0) * 0.5
	var jacket := C_TEXT if boss.flash > 0.0 else Color("#b86139")
	var skin := C_TEXT if boss.flash > 0.0 else Color("#e6bc93")
	canvas.draw_rect(Rect2(p.x - 6, p.y + 3, 4, 5), Color("#2c2936"))
	canvas.draw_rect(Rect2(p.x + 2, p.y + 3, 4, 5), Color("#2c2936"))
	canvas.draw_rect(Rect2(p.x - 8, p.y - 8 + bob, 16, 13), jacket)
	canvas.draw_rect(Rect2(p.x - 7, p.y - 1 + bob, 14, 3), Color("#4a3b34"))
	canvas.draw_rect(Rect2(p.x - 5, p.y - 2 + bob, 3, 4), Color("#e5ad68"))
	canvas.draw_rect(Rect2(p.x + 2, p.y - 2 + bob, 3, 4), Color("#e5ad68"))
	canvas.draw_line(p + Vector2(5, -7 + bob), p + Vector2(12, -3 + sin(elapsed * 9.0) * 2.0), Color("#f2c179"), 2.0)
	canvas.draw_rect(Rect2(p.x - 5, p.y - 17 + bob, 10, 9), skin)
	canvas.draw_rect(Rect2(p.x - 6, p.y - 20 + bob, 12, 4), Color("#241f29"))
	canvas.draw_rect(Rect2(p.x - 4, p.y - 18 + bob, 3, 2), Color("#77d8d0"))
	canvas.draw_rect(Rect2(p.x + 1, p.y - 18 + bob, 3, 2), Color("#77d8d0"))
	canvas.draw_rect(Rect2(p.x - 3, p.y - 13 + bob, 2, 2), Color("#1e1b24"))
	canvas.draw_rect(Rect2(p.x + 1, p.y - 13 + bob, 2, 2), Color("#1e1b24"))
	if boss.state == "telegraph":
		var bhand := p + boss.facing * 10.0 + Vector2(0, -10 + bob)
		canvas.draw_circle(bhand, 4.0 if boss.attack_damage == 2 else 3.0, Color("#20202b"))
		canvas.draw_rect(Rect2(bhand.x - 1, bhand.y - 6, 2, 3), Color("#ffe0a3"))

static func _draw_allan(canvas: CanvasItem, boss: BossController, elapsed: float) -> void:
	var p: Vector2 = boss.pos
	if boss.hp <= 0.0:
		for i in range(7):
			canvas.draw_circle(p + Vector2(float(i - 3) * 5.0, sin(float(i)) * 4.0), 2.0, Color("#ffffff"))
		return
	var bob := sin(elapsed * 2.5) * 1.4
	var body_c := C_TEXT if boss.flash > 0.0 else Color("#07080f")
	var rim_c := Color("#8a95a8") if boss.shadow_veiled else Color("#ffffff")
	canvas.draw_circle(p + Vector2(0, -4 + bob), 18.0, Color(0.02, 0.02, 0.05, 0.55))
	canvas.draw_colored_polygon(PackedVector2Array([
		p + Vector2(-12, 8 + bob), p + Vector2(-9, -15 + bob), p + Vector2(0, -22 + bob),
		p + Vector2(9, -15 + bob), p + Vector2(12, 8 + bob)
	]), body_c)
	canvas.draw_line(p + Vector2(-11, 7 + bob), p + Vector2(-8, -14 + bob), rim_c, 1.0)
	canvas.draw_line(p + Vector2(11, 7 + bob), p + Vector2(8, -14 + bob), rim_c, 1.0)
	for side_v in [-1.0, 1.0]:
		var side: float = float(side_v)
		var sway := sin(elapsed * 3.5 + side) * 3.0
		var tip := p + Vector2(side * 16.0, -14.0 + bob + sway)
		canvas.draw_line(p + Vector2(side * 7.0, -6.0 + bob), tip, Color("#edf4f7"), 1.6)
		canvas.draw_circle(tip, 3.0, Color("#ffffff"))
		canvas.draw_circle(tip, 1.2, Color("#98b2c4"))
	canvas.draw_rect(Rect2(p.x - 4, p.y - 13 + bob, 2, 2), Color("#ffffff"))
	canvas.draw_rect(Rect2(p.x + 2, p.y - 13 + bob, 2, 2), Color("#ffffff"))
	if boss.state == "active" and boss.attack_id == "thorn_sweep":
		var ang: float = boss.attack_dir.angle()
		canvas.draw_arc(p, 62.0, ang - 1.1, ang + 1.1, 20, Color("#ffffff"), 4.0)

static func _draw_john_paul(canvas: CanvasItem, boss: BossController, elapsed: float) -> void:
	var p: Vector2 = boss.pos
	if boss.hp <= 0.0:
		canvas.draw_rect(Rect2(p.x - 8, p.y - 2, 16, 7), Color("#364f57"))
		canvas.draw_rect(Rect2(p.x - 5, p.y - 9, 10, 7), Color("#d8b99c"))
		return
	var bob := sin(elapsed * 9.0) * 1.0
	var coat := C_TEXT if boss.flash > 0.0 else Color("#355259")
	var skin := C_TEXT if boss.flash > 0.0 else Color("#debca0")
	var tail_sway := sin(elapsed * 7.0) * 5.0
	canvas.draw_line(p + Vector2(4, 2), p + Vector2(13, -3 + tail_sway * 0.5), Color("#263038"), 2.2)
	canvas.draw_line(p + Vector2(13, -3 + tail_sway * 0.5), p + Vector2(17, -10 + tail_sway), Color("#8ce0cf"), 1.8)
	canvas.draw_rect(Rect2(p.x - 7, p.y - 7 + bob, 14, 12), coat)
	canvas.draw_rect(Rect2(p.x - 6, p.y + 3, 4, 5), Color("#232d33"))
	canvas.draw_rect(Rect2(p.x + 2, p.y + 3, 4, 5), Color("#232d33"))
	canvas.draw_rect(Rect2(p.x - 5, p.y - 16 + bob, 10, 9), skin)
	canvas.draw_rect(Rect2(p.x - 6, p.y - 18 + bob, 12, 3), Color("#242b33"))
	canvas.draw_colored_polygon(PackedVector2Array([
		p + Vector2(-6, -16 + bob), p + Vector2(-8, -23 + bob), p + Vector2(-2, -18 + bob)
	]), Color("#242b33"))
	canvas.draw_colored_polygon(PackedVector2Array([
		p + Vector2(6, -16 + bob), p + Vector2(8, -23 + bob), p + Vector2(2, -18 + bob)
	]), Color("#242b33"))
	canvas.draw_rect(Rect2(p.x - 6, p.y - 20 + bob, 2, 2), Color("#c98d84"))
	canvas.draw_rect(Rect2(p.x + 4, p.y - 20 + bob, 2, 2), Color("#c98d84"))
	canvas.draw_rect(Rect2(p.x - 4, p.y - 12 + bob, 3, 2), Color("#d6fff5"))
	canvas.draw_rect(Rect2(p.x + 1, p.y - 12 + bob, 3, 2), Color("#d6fff5"))
	var claw_dir: Vector2 = boss.facing
	var claw_p := p + claw_dir * 10.0 + Vector2(0, -3 + bob)
	canvas.draw_line(claw_p, claw_p + claw_dir * 6.0, Color("#d6fff5"), 1.5)
	canvas.draw_line(claw_p + Vector2(0, 2), claw_p + claw_dir * 6.0 + Vector2(0, 2), Color("#8ce0cf"), 1.5)

static func _draw_aaron(canvas: CanvasItem, boss: BossController, elapsed: float) -> void:
	var p: Vector2 = boss.pos
	var bone := C_TEXT if boss.flash > 0.0 else Color("#ede4ce")
	var bone_d := Color("#b8ad95")
	if boss.hp <= 0.0 or boss.disassembled:
		var rattle := sin(elapsed * 26.0) * (1.2 if boss.hp > 0.0 else 0.0)
		canvas.draw_rect(Rect2(p.x - 14, p.y - 2, 10, 3), bone_d)
		canvas.draw_rect(Rect2(p.x + 4, p.y + 1, 11, 3), bone_d)
		canvas.draw_rect(Rect2(p.x - 8, p.y + 3, 14, 3), bone)
		canvas.draw_rect(Rect2(p.x - 5 + rattle, p.y - 10, 10, 9), bone)
		canvas.draw_rect(Rect2(p.x - 3 + rattle, p.y - 7, 2, 3), Color("#19171c"))
		canvas.draw_rect(Rect2(p.x + 1 + rattle, p.y - 7, 2, 3), Color("#19171c"))
		return
	var bob := sin(elapsed * 4.5) * 1.0
	canvas.draw_rect(Rect2(p.x - 5, p.y + 2, 2, 7), bone_d)
	canvas.draw_rect(Rect2(p.x + 3, p.y + 2, 2, 7), bone_d)
	canvas.draw_rect(Rect2(p.x - 6, p.y - 1 + bob, 12, 3), bone)
	canvas.draw_rect(Rect2(p.x - 1, p.y - 11 + bob, 2, 11), bone_d)
	for r in range(3):
		canvas.draw_rect(Rect2(p.x - 8, p.y - 10 + r * 3 + bob, 16, 2), bone)
	canvas.draw_rect(Rect2(p.x - 10, p.y - 10 + bob, 3, 13), Color("#473d47"))
	canvas.draw_rect(Rect2(p.x + 7, p.y - 10 + bob, 3, 13), Color("#473d47"))
	canvas.draw_rect(Rect2(p.x - 6, p.y - 21 + bob, 12, 10), bone)
	canvas.draw_rect(Rect2(p.x - 4, p.y - 17 + bob, 3, 3), Color("#1a171c"))
	canvas.draw_rect(Rect2(p.x + 1, p.y - 17 + bob, 3, 3), Color("#1a171c"))
	canvas.draw_rect(Rect2(p.x - 3, p.y - 16 + bob, 1, 1), Color("#ffd18a") if boss.phase >= 2 else Color("#77d8d0"))
	canvas.draw_rect(Rect2(p.x + 2, p.y - 16 + bob, 1, 1), Color("#ffd18a") if boss.phase >= 2 else Color("#77d8d0"))
	canvas.draw_rect(Rect2(p.x - 4, p.y - 12 + bob, 8, 2), bone_d)

static func _draw_grandfather(canvas: CanvasItem, boss: BossController, elapsed: float) -> void:
	# CANON: Grandfather remains unmistakably ELDERLY across ALL 3 phases!
	var p: Vector2 = boss.pos
	var p2: bool = boss.phase >= 2
	var p3: bool = boss.phase >= 3
	var s := 1.0 if not p2 else (1.28 if not p3 else 1.38)
	if boss.hp <= 0.0:
		canvas.draw_rect(Rect2(p.x - 10, p.y - 5, 20, 11), Color("#3b333d"))
		canvas.draw_rect(Rect2(p.x - 6, p.y - 14, 12, 9), Color("#dfc0a4"))
		canvas.draw_rect(Rect2(p.x - 7, p.y - 16, 14, 3), Color("#ececec"))
		canvas.draw_rect(Rect2(p.x - 5, p.y - 8, 10, 6), Color("#e6e6e6"))
		return
	var bob := sin(elapsed * 3.0) * 1.0
	if p2:
		var aura_c := Color(0.92, 0.34, 0.25, 0.22) if p3 else Color(0.28, 0.14, 0.26, 0.38)
		canvas.draw_circle(p + Vector2(0, -8 * s + bob), 22.0 * s, aura_c)
	var coat := C_TEXT if boss.flash > 0.0 else (Color("#261922") if p2 else Color("#3c333f"))
	var skin := C_TEXT if boss.flash > 0.0 else (Color("#ccb09c") if p2 else Color("#e0bfa0"))
	var white_hair := Color("#f2f2f5")
	canvas.draw_rect(Rect2(p.x - 11 * s, p.y - 12 * s + bob, 22 * s, 18 * s), coat)
	if p2:
		canvas.draw_line(p + Vector2(-6 * s, -8 * s + bob), p + Vector2(0, 0 + bob), Color("#e86f5c"), 1.5)
		canvas.draw_line(p + Vector2(6 * s, -6 * s + bob), p + Vector2(1, 2 + bob), Color("#ffd08a"), 1.5)
	var hx := p.x - 2.0 * s
	var hy := p.y - 19.0 * s + bob
	canvas.draw_rect(Rect2(hx - 6 * s, hy - 5 * s, 12 * s, 10 * s), skin)
	canvas.draw_rect(Rect2(hx - 7 * s, hy - 6 * s, 4 * s, 6 * s), white_hair)
	canvas.draw_rect(Rect2(hx + 3 * s, hy - 6 * s, 4 * s, 6 * s), white_hair)
	canvas.draw_rect(Rect2(hx - 5 * s, hy - 7 * s, 10 * s, 2 * s), Color("#d8d8de"))
	canvas.draw_rect(Rect2(hx - 5 * s, hy - 2 * s, 4 * s, 3 * s), Color("#d9ad66"))
	canvas.draw_rect(Rect2(hx + 1 * s, hy - 2 * s, 4 * s, 3 * s), Color("#d9ad66"))
	canvas.draw_rect(Rect2(hx - 4 * s, hy - 1 * s, 2 * s, 1.5 * s), Color("#ff5e57") if p2 else Color("#242029"))
	canvas.draw_rect(Rect2(hx + 2 * s, hy - 1 * s, 2 * s, 1.5 * s), Color("#ff5e57") if p2 else Color("#242029"))
	canvas.draw_colored_polygon(PackedVector2Array([
		Vector2(hx - 6 * s, hy + 2 * s),
		Vector2(hx + 6 * s, hy + 2 * s),
		Vector2(hx + 4 * s, hy + 11 * s),
		Vector2(hx, hy + 14 * s),
		Vector2(hx - 4 * s, hy + 11 * s)
	]), white_hair)
	var cane_lift := -8.0 if boss.state == "telegraph" else 0.0
	var cx := p.x + 12.0 * s
	canvas.draw_line(Vector2(cx, p.y + 6 + cane_lift), Vector2(cx + 2, p.y - 16 * s + cane_lift), Color("#8c7c72"), 2.5)
	canvas.draw_line(Vector2(cx + 2, p.y - 16 * s + cane_lift), Vector2(cx - 4, p.y - 18 * s + cane_lift), Color("#d9ad66"), 2.5)
	if p3:
		canvas.draw_circle(Vector2(cx - 2, p.y - 17 * s + cane_lift), 3.0, Color("#ffd08a"))

static func _draw_dead_cat(canvas: CanvasItem, boss: BossController, elapsed: float) -> void:
	var p: Vector2 = boss.pos
	if boss.hp <= 0.0:
		canvas.draw_circle(p, 3.0, Color("#d4b97c"))
		canvas.draw_rect(Rect2(p.x - 1, p.y + 1, 2, 2), Color("#6d97ba"))
		return
	var a: float = boss.visible_alpha
	if boss.flash > 0.0:
		canvas.draw_circle(p + Vector2(0, -4), 14.0, Color(0.90, 0.96, 1.0, 0.65))
	_draw_cat_silhouette(canvas, p, a, elapsed, true)

static func _draw_cat_silhouette(canvas: CanvasItem, p: Vector2, alpha: float, elapsed: float, is_real: bool) -> void:
	var bob := sin(elapsed * 3.4) * 1.4
	var body_c := Color(0.08, 0.11, 0.17, 0.88 * alpha)
	var rim_c := Color(0.62, 0.80, 0.94, 0.78 * alpha)
	var eye_c := Color(0.90, 0.97, 1.0, alpha)
	canvas.draw_circle(p + Vector2(0, -4 + bob), 15.0, Color(0.55, 0.76, 0.92, 0.12 * alpha))
	var sway := sin(elapsed * 4.0) * 3.0
	canvas.draw_line(p + Vector2(6, 2 + bob), p + Vector2(14, -4 + bob + sway), rim_c, 2.0)
	canvas.draw_rect(Rect2(p.x - 8, p.y - 6 + bob, 16, 10), body_c)
	canvas.draw_rect(Rect2(p.x - 6, p.y - 14 + bob, 12, 9), body_c)
	canvas.draw_colored_polygon(PackedVector2Array([
		p + Vector2(-6, -13 + bob), p + Vector2(-8, -20 + bob), p + Vector2(-2, -14 + bob)
	]), body_c)
	canvas.draw_colored_polygon(PackedVector2Array([
		p + Vector2(6, -13 + bob), p + Vector2(8, -20 + bob), p + Vector2(2, -14 + bob)
	]), body_c)
	canvas.draw_line(p + Vector2(-8, -20 + bob), p + Vector2(-2, -14 + bob), rim_c, 1.0)
	canvas.draw_line(p + Vector2(8, -20 + bob), p + Vector2(2, -14 + bob), rim_c, 1.0)
	canvas.draw_rect(Rect2(p.x - 4, p.y - 11 + bob, 2, 2), eye_c)
	canvas.draw_rect(Rect2(p.x + 2, p.y - 11 + bob, 2, 2), eye_c)
	if is_real:
		# Subtle tarnished gold charm distinguishes real silhouette from echo decoys!
		canvas.draw_circle(p + Vector2(0, -4 + bob), 2.1, Color(1.0, 0.88, 0.56, 0.95 * alpha))

static func _draw_sentinel(canvas: CanvasItem, boss: BossController, elapsed: float) -> void:
	var p: Vector2 = boss.pos
	var bob := sin(elapsed * 2.2) * 1.0
	var glow_alpha := 0.12 + 0.05 * sin(elapsed * 4.0)
	canvas.draw_circle(p, 29.0, Color(0.25, 0.83, 0.81, glow_alpha))
	if boss.hp > 0.0:
		var stone := Color("#777381") if boss.flash <= 0.0 else C_CYAN_HI
		var dark_stone := Color("#373744") if boss.flash <= 0.0 else Color("#9ce9de")
		canvas.draw_rect(Rect2(p.x - 15, p.y - 12 + bob, 30, 25), dark_stone)
		canvas.draw_rect(Rect2(p.x - 12, p.y - 15 + bob, 24, 24), stone)
		canvas.draw_rect(Rect2(p.x - 19, p.y - 7 + bob, 8, 17), Color("#4c4b59"))
		canvas.draw_rect(Rect2(p.x + 11, p.y - 7 + bob, 8, 17), Color("#4c4b59"))
		canvas.draw_rect(Rect2(p.x - 10, p.y - 18 + bob, 20, 8), Color("#8a818b"))
		canvas.draw_rect(Rect2(p.x - 6, p.y - 12 + bob, 3, 2), C_CYAN_HI)
		canvas.draw_rect(Rect2(p.x + 3, p.y - 12 + bob, 3, 2), C_CYAN_HI)
		canvas.draw_rect(Rect2(p.x - 5, p.y - 4 + bob, 10, 10), Color("#263d45"))
		canvas.draw_rect(Rect2(p.x - 3, p.y - 2 + bob, 6, 6), C_CYAN)
		canvas.draw_rect(Rect2(p.x - 1, p.y, 2, 3), C_CYAN_HI)
	else:
		canvas.draw_rect(Rect2(p.x - 17, p.y - 4, 34, 9), Color("#45404b"))
		canvas.draw_rect(Rect2(p.x - 9, p.y - 9, 18, 4), Color("#30303b"))

static func draw_projectiles(canvas: CanvasItem, coal_projectiles: Array, hostile_projectiles: Array, elapsed: float) -> void:
	for shot in coal_projectiles:
		var p: Vector2 = shot["pos"]
		var v: Vector2 = shot["vel"]
		var dir := v.normalized() if v.length() > 1.0 else Vector2.RIGHT
		var spin := float(shot.get("spin", 0.0)) + elapsed * 10.0
		var bob := sin(spin) * 1.0
		# Ember velocity streak
		canvas.draw_line(p - dir * 10.0, p - dir * 2.0, Color(1.0, 0.56, 0.22, 0.45), 3.0)
		canvas.draw_line(p - dir * 7.0, p, Color(1.0, 0.86, 0.52, 0.72), 1.4)
		canvas.draw_circle(p, 7.5, Color(1.0, 0.48, 0.18, 0.14))
		canvas.draw_rect(Rect2(p.x - 3, p.y - 3 + bob, 6, 6), Color("#171821"))
		canvas.draw_rect(Rect2(p.x - 2, p.y - 2 + bob, 4, 4), Color("#595661"))
		canvas.draw_rect(Rect2(p.x - 1, p.y - 1 + bob, 2, 2), C_WARM_HI)

	for shot in hostile_projectiles:
		var p: Vector2 = shot["pos"]
		var v: Vector2 = shot["vel"]
		var dir := v.normalized() if v.length() > 1.0 else Vector2.LEFT
		var kind := str(shot.get("kind", "sentinel"))
		var tint: Color = shot.get("color", C_CYAN)
		if kind == "yarn_orb":
			var deflected := bool(shot.get("deflected", false))
			canvas.draw_line(p - dir * 14.0, p, Color(tint.r, tint.g, tint.b, 0.35), 3.2)
			canvas.draw_circle(p, 10.0 if deflected else 8.8, Color(tint.r, tint.g, tint.b, 0.26 if deflected else 0.18))
			canvas.draw_circle(p, 5.5, tint)
			canvas.draw_arc(p, 5.5, elapsed * 6.0, elapsed * 6.0 + PI, 12, Color("#ffffff"), 1.5)
		elif kind == "bone":
			var ang := float(shot.get("spin", 0.0)) + elapsed * 13.0
			var d := Vector2.RIGHT.rotated(ang) * 4.6
			canvas.draw_line(p - dir * 8.0, p, Color(0.95, 0.90, 0.78, 0.26), 2.0)
			canvas.draw_line(p - d, p + d, Color("#fff8e6"), 2.6)
			canvas.draw_circle(p - d, 1.9, Color("#ded5be"))
			canvas.draw_circle(p + d, 1.9, Color("#ded5be"))
		elif kind == "white_petal":
			canvas.draw_line(p - dir * 8.0, p, Color(0.92, 0.96, 1.0, 0.25), 2.0)
			canvas.draw_circle(p, 7.0, Color(1.0, 1.0, 1.0, 0.18))
			canvas.draw_colored_polygon(PackedVector2Array([
				p + Vector2(0, -3.5), p + Vector2(3, 0), p + Vector2(0, 3.5), p + Vector2(-3, 0)
			]), Color("#ffffff"))
		else:
			canvas.draw_line(p - dir * 10.0, p, Color(tint.r, tint.g, tint.b, 0.32), 2.6)
			canvas.draw_circle(p, 7.5, Color(tint.r, tint.g, tint.b, 0.16))
			canvas.draw_rect(Rect2(p.x - 3, p.y - 3, 6, 6), Color("#252a36"))
			canvas.draw_rect(Rect2(p.x - 2, p.y - 2, 4, 4), tint)
			canvas.draw_rect(Rect2(p.x - 1, p.y - 1, 2, 2), C_TEXT)

static func draw_impact_rings(canvas: CanvasItem, impact_rings: Array) -> void:
	for ring in impact_rings:
		var rp: Vector2 = ring["pos"]
		var rad := float(ring["radius"])
		var a := float(ring["alpha"])
		var col: Color = ring["color"]
		canvas.draw_arc(rp, rad, 0.0, TAU, 24, Color(col.r, col.g, col.b, a * 0.85), 2.0)
		canvas.draw_arc(rp, rad * 0.72, 0.0, TAU, 18, Color(1.0, 1.0, 1.0, a * 0.55), 1.0)

static func draw_player(canvas: CanvasItem, sprites: SpriteBank, p: Vector2, attack_direction: Vector2, move_input: Vector2, dodge_direction: Vector2, dodge_timer: float, perfect_dodge_timer: float, counter_strike_timer: float, player_invuln: float, player_flash: float, attack_timer: float, attack_combo: int, mining: bool, elapsed: float) -> void:
	var blink := player_invuln > 0.0 and dodge_timer <= 0.0 and int(elapsed * 19.0) % 2 == 0
	if blink:
		return
	var walking := move_input.length() > 0.1 and dodge_timer <= 0.0
	var bob := sin(elapsed * 12.0) * 0.7 if walking else sin(elapsed * 2.8) * 0.25
	var body := Color("#4f8b88") if player_flash <= 0.0 else C_TEXT
	var skin := Color("#e9c29a") if player_flash <= 0.0 else C_TEXT
	var facing := attack_direction
	var side := Vector2(-facing.y, facing.x)
	var back := -facing

	canvas.draw_rect(Rect2(p.x - 8, p.y + 5, 16, 3), Color(0.0, 0.0, 0.0, 0.36))
	if dodge_timer > 0.0:
		var ghost_row := 0 if facing == Vector2.DOWN else (1 if facing == Vector2.UP else (2 if facing == Vector2.LEFT else 3))
		for i in range(3):
			var tail := p - dodge_direction * (7.0 + float(i) * 6.5)
			var g_alpha := 0.36 - float(i) * 0.10
			if sprites != null and sprites.has_sheet("choko"):
				sprites.draw_frame(canvas, "choko", 3, ghost_row, 48, 48, tail + Vector2(0, -5), false, Color(0.55, 0.96, 0.94, g_alpha), 0.5)
			else:
				canvas.draw_rect(Rect2(tail.x - 5, tail.y - 3 + i, 10, 3), Color(0.42, 0.88, 0.82, g_alpha))

	# Souls-like Counter-Strike Ready aura after Perfect Dodge!
	if counter_strike_timer > 0.0:
		var cp := 0.55 + 0.45 * sin(elapsed * 22.0)
		canvas.draw_arc(p + Vector2(0, -2), 12.0, 0.0, TAU, 20, Color(0.47, 0.92, 0.88, 0.65 * cp), 1.4)

	var used_choko_sheet := false
	if sprites != null and sprites.has_sheet("choko"):
		var row := 0
		if facing == Vector2.DOWN:
			row = 0
		elif facing == Vector2.UP:
			row = 1
		elif facing == Vector2.LEFT:
			row = 2
		else:
			row = 3
		var col := 0
		if attack_timer > 0.0 or mining:
			col = 3
		elif walking:
			col = 1 if int(elapsed * 9.0) % 2 == 0 else 2
		var cmod := Color(1.8, 1.8, 1.8, 1.0) if player_flash > 0.0 else Color.WHITE
		used_choko_sheet = sprites.draw_frame(canvas, "choko", col, row, 48, 48, p + Vector2(0, -5 + bob), false, cmod, 0.5)

	if not used_choko_sheet:
		var step := sin(elapsed * 14.0) * 1.4 if walking else 0.0
		var boot_a := p + back * 4.0 + side * (3.0 + step)
		var boot_b := p + back * 4.0 - side * (3.0 + step)
		canvas.draw_rect(Rect2(boot_a.x - 2.5, boot_a.y - 2.0 + bob, 5, 5), Color("#343342"))
		canvas.draw_rect(Rect2(boot_b.x - 2.5, boot_b.y - 2.0 - bob, 5, 5), Color("#343342"))

		canvas.draw_line(p + back * 2.0 + side * 3.0, p + back * 8.0 + side * 5.0 + Vector2(0, bob), Color("#d77a58"), 2.0)
		canvas.draw_rect(Rect2(p.x - 7 + back.x * 2.0, p.y - 4 + back.y * 2.0, 5, 6), Color("#a16b4f"))

		canvas.draw_rect(Rect2(p.x - 6, p.y - 5 + bob, 12, 12), body)
		canvas.draw_rect(Rect2(p.x - 5, p.y + 3 + bob, 10, 3), Color("#345d62"))
		canvas.draw_rect(Rect2(p.x - 4, p.y - 3 + bob, 8, 2), Color("#a8c0ad"))
		var head := p + facing * 5.0 + Vector2(0, bob)
		canvas.draw_rect(Rect2(head.x - 4, head.y - 4, 8, 7), skin)
		canvas.draw_rect(Rect2(head.x - 5, head.y - 5, 10, 3), Color("#292631"))
		canvas.draw_rect(Rect2(head.x - 4, head.y - 7, 8, 2), Color("#3c3034"))
		if facing == Vector2.DOWN:
			canvas.draw_rect(Rect2(head.x - 2, head.y + 1, 1, 1), Color("#24232d"))
			canvas.draw_rect(Rect2(head.x + 2, head.y + 1, 1, 1), Color("#24232d"))
		elif facing == Vector2.UP:
			canvas.draw_rect(Rect2(head.x - 4, head.y - 5, 8, 3), Color("#292631"))
		elif facing == Vector2.LEFT:
			canvas.draw_rect(Rect2(head.x - 4, head.y - 1, 2, 2), Color("#24232d"))
		else:
			canvas.draw_rect(Rect2(head.x + 2, head.y - 1, 2, 2), Color("#24232d"))
		canvas.draw_rect(Rect2(p.x - 3, p.y - 1 + bob, 6, 2), C_WARM)
		canvas.draw_rect(Rect2(p.x - 1, p.y - 1 + bob, 2, 2), C_WARM_HI)


	var hand := p + side * 7.0 + back * 1.0
	var pick_end := p + facing * 16.0 + side * 5.0
	if attack_timer > 0.0:
		var dur := 0.23 if attack_combo == 3 else 0.18
		var swing_phase := clampf(1.0 - attack_timer / dur, 0.0, 1.0)
		var fade := clampf(1.0 - swing_phase * 0.85, 0.15, 1.0)
		var flip_s := -1.0 if attack_combo == 2 else 1.0
		var sweep_side := side * flip_s * (8.5 - swing_phase * 17.0)
		var arc_start := p + facing * 10.0 + sweep_side
		var arc_end := p + facing * 24.0 - sweep_side * 0.35
		canvas.draw_line(hand, arc_start, Color("#9a704d"), 2.2)
		canvas.draw_line(arc_start, arc_end, C_CYAN_HI if counter_strike_timer > 0.0 else Color("#e2e5ed"), 3.2)
		canvas.draw_line(arc_start, arc_end, C_TEXT, 1.2)
		# Multi-layered glowing crescent slash trail!
		var attack_angle := facing.angle()
		var span := 0.95 if (attack_combo == 3 or counter_strike_timer > 0.0) else 0.75
		var rad := 15.0 + float(attack_combo) * 2.2
		var outer_c := Color(0.38, 0.96, 0.94, 0.42 * fade) if counter_strike_timer > 0.0 else (Color(1.0, 0.56, 0.26, 0.46 * fade) if attack_combo == 3 else Color(1.0, 0.78, 0.45, 0.34 * fade))
		var inner_c := Color(0.92, 1.0, 1.0, 0.92 * fade) if counter_strike_timer > 0.0 else Color(1.0, 0.95, 0.80, 0.85 * fade)
		canvas.draw_arc(p + facing * 9.0, rad, attack_angle - span, attack_angle + span, 20, outer_c, 6.0 if attack_combo == 3 else 4.2)
		canvas.draw_arc(p + facing * 10.0, rad + 1.5, attack_angle - span * 0.88, attack_angle + span * 0.88, 18, inner_c, 2.0)
	elif mining:
		canvas.draw_line(hand, p + Vector2(0, -9), Color("#956b4d"), 2.0)
		canvas.draw_line(p + Vector2(-3, -10), p + Vector2(4, -13), Color("#d5d7df"), 2.0)
		canvas.draw_circle(p + Vector2(3, -14), 2.0, C_WARM_HI)
	else:
		canvas.draw_line(hand, pick_end, Color("#876044"), 2.0)
		canvas.draw_line(pick_end + Vector2(-4, -2), pick_end + Vector2(4, 2), C_CYAN_HI if counter_strike_timer > 0.0 else Color("#c6cbd4"), 2.0)

	if perfect_dodge_timer > 0.0:
		var ring_alpha := clampf(perfect_dodge_timer / 0.13, 0.0, 1.0)
		canvas.draw_arc(p + Vector2(0, -3), 14.0, -PI / 2.0, -PI / 2.0 + TAU * ring_alpha, 24, Color(C_CYAN_HI.r, C_CYAN_HI.g, C_CYAN_HI.b, 0.95), 1.6)

	var chevron := p + facing * 14.0
	canvas.draw_circle(chevron, 1.5, C_CYAN_HI if counter_strike_timer > 0.0 else Color(1.0, 0.82, 0.53, 0.60))
