extends RefCounted

## CHOKO — Phase 4.2: High-Craft 640x360 Underground Arenas + Rich Live Background Elements.
## Renders hand-crafted 640x360 arena backdrops with swaying chains, swinging volumetric
## mine lanterns, culvert waterfalls & ripples, swaying white glowing plants, rising embers,
## ossuary sconces, stained-glass shafts, spectral wisps, and foreground depth framing.

const BossController := preload("res://scripts/boss_controller.gd")
const SpriteBank := preload("res://scripts/sprite_bank.gd")

const W := 320.0
const H := 180.0
const C_WARM := Color("#e5ad68")
const C_WARM_HI := Color("#ffd18a")
const C_RED := Color("#e66a61")

static func draw_arena_backdrop_hd(canvas: CanvasItem, boss: BossController, sprites: SpriteBank) -> void:
	var tex: Texture2D = sprites.get_arena_tex(boss.id) if sprites != null else null
	if tex != null:
		canvas.draw_texture_rect(tex, Rect2(0, 0, 640, 360), false)
	else:
		canvas.draw_rect(Rect2(0, 0, 640, 360), Color("#151724"))

static func draw_arena_dynamic(canvas: CanvasItem, boss: BossController, elapsed: float) -> void:
	# Drawn inside 2x world transform (320x180 logical gameplay space)
	match str(boss.id):
		"farhan":
			# Swinging industrial floodlight beams & hanging hoist chains
			for lx in [38.0, 160.0, 282.0]:
				var sway := sin(elapsed * 1.4 + lx * 0.05) * 3.0
				_draw_chain(canvas, Vector2(lx, 22.0), Vector2(lx + sway * 0.5, 39.0), Color("#635c6b"))
				var cone := PackedVector2Array([
					Vector2(lx - 4 + sway * 0.5, 38), Vector2(lx + 4 + sway * 0.5, 38),
					Vector2(lx + 24 + sway * 1.8, 96), Vector2(lx - 24 + sway * 1.8, 96)
				])
				canvas.draw_colored_polygon(cone, Color(1.0, 0.78, 0.45, 0.06))
			# Pulsing depot warning strobes
			var alarm: bool = boss.arena_alarm > 0.0
			var bcol := C_RED if alarm else Color("#e5ad68")
			var pulse := 0.55 + 0.45 * sin(elapsed * (16.0 if alarm else 4.5))
			canvas.draw_circle(Vector2(18, 44), 6.0, Color(bcol.r, bcol.g, bcol.b, 0.25 * pulse))
			canvas.draw_circle(Vector2(18, 44), 2.5, Color(bcol.r, bcol.g, bcol.b, 0.92 * pulse))
			canvas.draw_circle(Vector2(302, 44), 6.0, Color(bcol.r, bcol.g, bcol.b, 0.25 * pulse))
			canvas.draw_circle(Vector2(302, 44), 2.5, Color(bcol.r, bcol.g, bcol.b, 0.92 * pulse))
			# Rising depot welding sparks & warm ember motes
			if boss.phase >= 2:
				for bx in [82.0, 160.0, 238.0]:
					canvas.draw_rect(Rect2(bx - 3, 35, 6, 3), Color(1.0, 0.35, 0.28, 0.65 * pulse))
			_draw_rising_embers(canvas, elapsed, Color(1.0, 0.74, 0.36, 0.48), 16)
			_draw_dust_motes(canvas, elapsed, Color(0.95, 0.82, 0.62, 0.24), 16)

		"allan":
			# Swaying glowing white cathedral flora hanging from upper arches & rising along chasm
			for fx in [32.0, 96.0, 160.0, 224.0, 288.0]:
				var sw := sin(elapsed * 2.1 + fx * 0.08) * 3.2
				canvas.draw_line(Vector2(fx - 3, 22), Vector2(fx - 4 + sw, 47), Color("#dceaf2"), 1.1)
				canvas.draw_circle(Vector2(fx - 4 + sw, 48), 2.6, Color(1.0, 1.0, 1.0, 0.85))
				canvas.draw_circle(Vector2(fx - 4 + sw, 48), 6.0, Color(0.82, 0.92, 1.0, 0.14))
			for bx in [24.0, 74.0, 134.0, 198.0, 256.0, 296.0]:
				var sw := sin(elapsed * 1.9 + bx * 0.1) * 2.4
				canvas.draw_line(Vector2(bx, 166), Vector2(bx + sw, 154), Color("#c9dce8"), 1.1)
				canvas.draw_circle(Vector2(bx + sw, 153), 2.2, Color("#ffffff"))
			# 3 coal-ignitable oil braziers with flickering flames
			for b in boss.braziers:
				var bp: Vector2 = b["pos"]
				var lit := bool(b.get("lit", false))
				canvas.draw_rect(Rect2(bp.x - 6, bp.y - 2, 12, 6), Color("#3c3e4d"))
				canvas.draw_rect(Rect2(bp.x - 4, bp.y - 5, 8, 4), Color("#585b6d"))
				if lit:
					var fl := sin(elapsed * 14.0 + bp.x) * 1.5
					canvas.draw_circle(bp + Vector2(0, -6), 14.0, Color(1.0, 0.62, 0.22, 0.26))
					canvas.draw_colored_polygon(PackedVector2Array([
						bp + Vector2(-3.5, -4), bp + Vector2(0, -13 + fl), bp + Vector2(3.5, -4)
					]), Color("#ff9c3b"))
					canvas.draw_rect(Rect2(bp.x - 1, bp.y - 8, 2, 4), Color("#fff0b8"))
				else:
					var pulse := 0.45 + 0.45 * sin(elapsed * 4.2 + bp.x)
					canvas.draw_arc(bp + Vector2(0, -2), 9.5, 0.0, TAU, 18, Color(1.0, 0.82, 0.45, pulse * 0.80), 1.1)
					canvas.draw_rect(Rect2(bp.x - 2, bp.y - 5, 4, 2), Color("#1b1d26"))
			# Drifting bioluminescent white spores
			for ci in range(8):
				var cx := fposmod(float(ci * 47) + elapsed * 6.5, 312.0) + 4.0
				var cy := 58.0 + float((ci * 29) % 84) + sin(elapsed * 2.2 + float(ci)) * 4.0
				canvas.draw_circle(Vector2(cx, cy), 2.2, Color(1.0, 1.0, 1.0, 0.55))
				canvas.draw_circle(Vector2(cx + 1.5, cy - 1.0), 1.4, Color(0.92, 0.96, 1.0, 0.45))
			_draw_dust_motes(canvas, elapsed, Color(0.94, 0.98, 1.0, 0.42), 24)

		"john_paul":
			# Animated culvert water drips + expanding puddle ripples!
			for cx in [52.0, 160.0, 268.0]:
				var cycle := fposmod(elapsed * 1.45 + cx * 0.02, 1.0)
				if cycle < 0.65:
					var drop_y := 26.0 + (cycle / 0.65) * 24.0
					canvas.draw_rect(Rect2(cx - 4, drop_y, 1.5, 3.5), Color(0.62, 0.92, 0.88, 0.72))
				else:
					var rr := ((cycle - 0.65) / 0.35) * 9.0
					var ra := 1.0 - ((cycle - 0.65) / 0.35)
					canvas.draw_arc(Vector2(cx - 3, 51.0), rr, 0.0, TAU, 14, Color(0.68, 0.94, 0.90, ra * 0.55), 1.0)
			# Hanging station lanterns with gentle draft sway
			for lx in [104.0, 216.0]:
				var sw := sin(elapsed * 1.8 + lx) * 1.8
				_draw_chain(canvas, Vector2(lx, 22), Vector2(lx + sw, 41), Color("#4c6670"))
				_draw_lamp(canvas, Vector2(lx + sw, 45), 17.0, 0.22, elapsed)
			# 3 Pressurized Drainage Steam Vents
			for sv in boss.steam_vents:
				var vp: Vector2 = sv["pos"]
				var st := str(sv["state"])
				canvas.draw_rect(Rect2(vp.x - 8, vp.y - 6, 16, 12), Color("#151f26"))
				canvas.draw_rect(Rect2(vp.x - 7, vp.y - 5, 14, 10), Color("#344752"))
				for sl in range(3):
					canvas.draw_line(Vector2(vp.x - 5, vp.y - 3 + sl * 3), Vector2(vp.x + 5, vp.y - 3 + sl * 3), Color("#111920"), 1.0)
				if st == "hiss":
					var p := 0.5 + 0.5 * sin(elapsed * 20.0)
					canvas.draw_arc(vp, 12.0, 0.0, TAU, 18, Color(1.0, 0.78, 0.45, 0.60 + p * 0.35), 1.3)
					canvas.draw_circle(vp + Vector2(0, -4 - p * 4.0), 3.0, Color(0.85, 0.96, 0.98, 0.48))
				elif st == "erupt":
					var sway := sin(elapsed * 24.0 + vp.x) * 2.0
					canvas.draw_circle(vp, 13.0, Color(0.75, 0.97, 0.98, 0.40))
					canvas.draw_rect(Rect2(vp.x - 7 + sway * 0.5, vp.y - 26, 14, 28), Color(0.85, 0.98, 1.0, 0.54))
					canvas.draw_rect(Rect2(vp.x - 4 - sway * 0.4, vp.y - 32, 8, 30), Color(1.0, 1.0, 1.0, 0.68))
			if boss.wall_side == 1:
				canvas.draw_rect(Rect2(10, 52, 4, 98), Color(0.55, 0.88, 0.81, 0.55))
			elif boss.wall_side == 2:
				canvas.draw_rect(Rect2(306, 52, 4, 98), Color(0.55, 0.88, 0.81, 0.55))
			elif boss.wall_side == 3:
				canvas.draw_rect(Rect2(20, 48, 280, 4), Color(0.55, 0.88, 0.81, 0.55))
			if boss.phase >= 2 and boss.hp > 0.0:
				var sp := 0.5 + 0.5 * sin(elapsed * 8.0)
				canvas.draw_arc(boss.pos + Vector2(0, -6), 20.0 + sp * 3.0, 0.0, TAU, 24, Color(0.98, 0.85, 0.48, 0.24 * sp), 1.4)
			_draw_dust_motes(canvas, elapsed, Color(0.65, 0.92, 0.90, 0.28), 22)

		"aaron":
			# Glowing alcove skull eyes + flickering crypt braziers + hanging bone chimes
			var eye_p := 0.55 + 0.45 * sin(elapsed * 3.2)
			for sx in [76.0, 160.0, 244.0]:
				canvas.draw_rect(Rect2(sx - 2.5, 32.5, 1.5, 1.5), Color(0.55, 0.88, 0.84, 0.72 * eye_p))
				canvas.draw_rect(Rect2(sx + 1.0, 32.5, 1.5, 1.5), Color(0.55, 0.88, 0.84, 0.72 * eye_p))
			# Candlelit crypt slab (Aaron & Steve date-night detail!)
			canvas.draw_rect(Rect2(138, 43, 44, 6), Color("#473e42"))
			for cpos in [Vector2(148, 42), Vector2(172, 42)]:
				var fl := sin(elapsed * 16.0 + cpos.x) * 0.8
				canvas.draw_rect(Rect2(cpos.x - 1, cpos.y - 4, 2, 5), Color("#f5ebd6"))
				canvas.draw_circle(cpos + Vector2(0, -6 + fl), 5.0, Color(1.0, 0.62, 0.28, 0.20))
				canvas.draw_rect(Rect2(cpos.x - 1, cpos.y - 7 + fl, 2, 3), Color("#ffd98a"))
			_draw_lamp(canvas, Vector2(28, 55), 18.0, 0.24, elapsed)
			_draw_lamp(canvas, Vector2(292, 55), 18.0, 0.24, elapsed)
			_draw_rising_embers(canvas, elapsed, Color(0.95, 0.84, 0.62, 0.34), 14)
			_draw_dust_motes(canvas, elapsed, Color(0.88, 0.84, 0.72, 0.28), 20)

		"grandfather":
			# Pulsing stained-glass volumetric light beam + swinging bronze bell + swaying chains
			var ray_p := 0.85 + 0.15 * sin(elapsed * 2.5)
			var beam := PackedVector2Array([Vector2(148, 43), Vector2(172, 43), Vector2(202, 128), Vector2(118, 128)])
			var beam_c := Color(0.98, 0.38, 0.28, 0.10 * ray_p) if boss.phase >= 3 else Color(0.95, 0.56, 0.38, 0.08 * ray_p)
			canvas.draw_colored_polygon(beam, beam_c)
			var bell_swing := sin(elapsed * (9.5 if boss.attack_id == "bell_toll_cataclysm" else 1.6)) * (4.5 if boss.attack_id == "bell_toll_cataclysm" else 1.2)
			_draw_chain(canvas, Vector2(160, 20), Vector2(160 + bell_swing, 34), Color("#8a7459"))
			canvas.draw_colored_polygon(PackedVector2Array([
				Vector2(156 + bell_swing, 34), Vector2(164 + bell_swing, 34),
				Vector2(167 + bell_swing, 42), Vector2(153 + bell_swing, 42)
			]), Color("#e0b263"))
			if boss.attack_id == "crypt_doors":
				canvas.draw_rect(Rect2(5, 79, 6, 38), Color(0.98, 0.45, 0.34, 0.78))
				canvas.draw_rect(Rect2(309, 79, 6, 38), Color(0.98, 0.45, 0.34, 0.78))
			if boss.phase >= 3 or boss.chapel_fractured:
				var pulse := 0.55 + 0.45 * sin(elapsed * 6.0)
				var fcol := Color(0.98, 0.44, 0.28, pulse)
				canvas.draw_line(Vector2(42, 62), Vector2(118, 98), fcol, 2.0)
				canvas.draw_line(Vector2(118, 98), Vector2(160, 134), fcol, 2.0)
				canvas.draw_line(Vector2(278, 66), Vector2(204, 104), fcol, 2.0)
				canvas.draw_line(Vector2(204, 104), Vector2(160, 134), fcol, 2.0)
				_draw_rising_embers(canvas, elapsed, Color(1.0, 0.52, 0.30, 0.55), 22)
			# Cast-iron coal heater grates glowing hot along chapel wall!
			var heat_a := 0.35 + (0.25 if boss.phase >= 2 else 0.0) + (0.25 if boss.phase >= 3 else 0.0)
			for hx in [96.0, 224.0]:
				canvas.draw_rect(Rect2(hx - 10, 38, 20, 8), Color("#261c22"))
				canvas.draw_rect(Rect2(hx - 8, 40, 16, 4), Color(1.0, 0.44, 0.18, heat_a))
				canvas.draw_circle(Vector2(hx, 42), 14.0, Color(1.0, 0.40, 0.16, heat_a * 0.25))
			_draw_lamp(canvas, Vector2(58, 52), 17.0, 0.24, elapsed)
			_draw_lamp(canvas, Vector2(262, 52), 17.0, 0.24, elapsed)
			_draw_dust_motes(canvas, elapsed, Color(1.0, 0.68, 0.50, 0.30) if boss.phase >= 3 else Color(0.85, 0.72, 0.72, 0.24), 22)

		"dead_cat":
			# Blinking cold service light + drifting spectral wisps + hanging catacomb chains
			for cx in [96.0, 224.0]:
				var sw := sin(elapsed * 1.1 + cx) * 2.0
				_draw_chain(canvas, Vector2(cx, 22), Vector2(cx + sw, 46), Color("#36475c"))
			if sin(elapsed * 3.8) > 0.1:
				canvas.draw_circle(Vector2(18, 50), 7.5, Color(0.62, 0.84, 0.96, 0.34))
				canvas.draw_rect(Rect2(17, 49, 2, 2), Color("#e5f6ff"))
			# Floating cold cyan wisps drifting slowly through the catacomb
			for wi in range(6):
				var wx := 40.0 + float(wi) * 48.0 + sin(elapsed * 0.9 + float(wi) * 1.7) * 14.0
				var wy := 70.0 + float((wi * 23) % 66) + cos(elapsed * 1.2 + float(wi)) * 7.0
				canvas.draw_circle(Vector2(wx, wy), 4.5, Color(0.62, 0.84, 0.98, 0.12))
				canvas.draw_circle(Vector2(wx, wy), 1.4, Color(0.88, 0.96, 1.0, 0.55))
			for bell in boss.catacomb_bells:
				var bp: Vector2 = bell["pos"]
				var cd := float(bell["cooldown"])
				var ranim := float(bell["ring_anim"])
				var ready := cd <= 0.0
				var swing := sin(elapsed * 26.0) * 3.0 * ranim
				canvas.draw_rect(Rect2(bp.x - 6, bp.y + 2, 12, 3), Color("#263040"))
				canvas.draw_line(bp + Vector2(-5, 3), bp + Vector2(-5, -10), Color("#4c5d73"), 1.5)
				canvas.draw_line(bp + Vector2(5, 3), bp + Vector2(5, -10), Color("#4c5d73"), 1.5)
				canvas.draw_line(bp + Vector2(-6, -10), bp + Vector2(6, -10), Color("#657a94"), 2.0)
				var bcol := Color("#ffd18a") if ready else Color("#5e6473")
				canvas.draw_colored_polygon(PackedVector2Array([
					bp + Vector2(-3 + swing, -8), bp + Vector2(3 + swing, -8),
					bp + Vector2(5 + swing, -1), bp + Vector2(-5 + swing, -1)
				]), bcol)
				if ready:
					var p := 0.45 + 0.45 * sin(elapsed * 4.5 + bp.x)
					canvas.draw_arc(bp + Vector2(0, -4), 9.5, 0.0, TAU, 16, Color(1.0, 0.82, 0.54, p * 0.80), 1.1)
			for bw in boss.bell_waves:
				var ctr: Vector2 = bw["center"]
				var rad := float(bw["radius"])
				var a := float(bw["alpha"])
				canvas.draw_arc(ctr, rad, 0.0, TAU, 32, Color(1.0, 0.85, 0.55, a * 0.84), 2.2)
			_draw_dust_motes(canvas, elapsed, Color(0.75, 0.88, 1.0, 0.30), 26)

		_:
			var alarm_col := C_RED if boss.arena_alarm > 0.0 else C_WARM
			canvas.draw_circle(Vector2(122, 46), 3.0, Color(alarm_col.r, alarm_col.g, alarm_col.b, 0.82))
			canvas.draw_circle(Vector2(198, 46), 3.0, Color(alarm_col.r, alarm_col.g, alarm_col.b, 0.82))
			for lx in [45.0, 275.0]:
				var sw := sin(elapsed * 1.7 + lx) * 1.6
				_draw_chain(canvas, Vector2(lx, 24), Vector2(lx + sw, 53), Color("#685c66"))
				_draw_lamp(canvas, Vector2(lx + sw, 57), 19.0, 0.24, elapsed)
			_draw_rising_embers(canvas, elapsed, Color(1.0, 0.68, 0.34, 0.32), 10)
			_draw_dust_motes(canvas, elapsed, Color(0.78, 0.71, 0.72, 0.28), 22)

static func draw_veins(canvas: CanvasItem, veins: Array, player_pos: Vector2, elapsed: float) -> void:
	for i in range(veins.size()):
		var vein: Dictionary = veins[i]
		var p: Vector2 = vein["pos"]
		if bool(vein["active"]):
			var pulse := 0.58 + 0.42 * sin(elapsed * 3.7 + float(i) * 1.7)
			canvas.draw_circle(p + Vector2(0, -2), 14.0, Color(1.0, 0.47, 0.19, 0.11 * pulse))
			canvas.draw_colored_polygon(PackedVector2Array([
				p + Vector2(-10, 1), p + Vector2(-6, -6), p + Vector2(-1, -4),
				p + Vector2(3, -9), p + Vector2(9, -2), p + Vector2(8, 4), p + Vector2(-7, 5)
			]), Color("#3d3743"))
			canvas.draw_rect(Rect2(p.x - 6, p.y - 3, 4, 3), Color("#6d5961"))
			canvas.draw_rect(Rect2(p.x + 1, p.y - 6, 4, 4), Color("#5d4e5b"))
			canvas.draw_rect(Rect2(p.x - 2, p.y - 3, 3, 3), Color(1.0, 0.49, 0.19, pulse))
			canvas.draw_rect(Rect2(p.x + 3, p.y - 1, 2, 2), Color(1.0, 0.76, 0.39, pulse))
			canvas.draw_rect(Rect2(p.x - 7, p.y + 3, 13, 2), Color("#272631"))
			if player_pos.distance_to(p) < 27.0:
				canvas.draw_circle(p + Vector2(0, -13), 2.4, Color(1.0, 0.86, 0.56, 0.92))
		else:
			canvas.draw_colored_polygon(PackedVector2Array([
				p + Vector2(-8, 2), p + Vector2(-4, -3), p + Vector2(4, -4), p + Vector2(8, 2)
			]), Color("#292833"))

static func draw_allan_darkness_overlay(canvas: CanvasItem, boss: BossController, elapsed: float) -> void:
	if str(boss.id) != "allan":
		return
	var lit: int = boss.get_lit_brazier_count()
	var darkness := 0.42 if lit == 0 else (0.24 if lit == 1 else (0.06 if lit == 2 else 0.0))
	if darkness > 0.0:
		canvas.draw_rect(Rect2(0, 22, W, H - 22), Color(0.02, 0.02, 0.05, darkness))
	for b in boss.braziers:
		var bp: Vector2 = b["pos"]
		if bool(b.get("lit", false)):
			var flicker := 0.92 + 0.08 * sin(elapsed * 9.0 + bp.x)
			canvas.draw_circle(bp + Vector2(0, -4), 44.0 * flicker, Color(1.0, 0.68, 0.30, 0.14))
			canvas.draw_circle(bp + Vector2(0, -4), 22.0 * flicker, Color(1.0, 0.82, 0.48, 0.18))

static func _draw_chain(canvas: CanvasItem, a: Vector2, b: Vector2, tint: Color) -> void:
	canvas.draw_line(a, b, tint, 1.1)
	var steps := 5
	for k in range(1, steps):
		var pt := a.lerp(b, float(k) / float(steps))
		canvas.draw_rect(Rect2(pt.x - 1.0, pt.y - 1.0, 2.0, 2.0), tint)

static func _draw_lamp(canvas: CanvasItem, center: Vector2, radius: float, strength: float, elapsed: float) -> void:
	var pulse := 0.88 + 0.12 * sin(elapsed * 3.2 + center.x)
	canvas.draw_circle(center, radius, Color(1.0, 0.48, 0.19, strength * 0.24 * pulse))
	canvas.draw_circle(center, radius * 0.56, Color(1.0, 0.57, 0.24, strength * 0.42 * pulse))
	canvas.draw_rect(Rect2(center.x - 3, center.y - 4, 6, 9), Color("#403642"))
	canvas.draw_rect(Rect2(center.x - 2, center.y - 3, 4, 6), Color("#b77746"))
	canvas.draw_rect(Rect2(center.x - 1, center.y - 2, 2, 4), C_WARM_HI)
	canvas.draw_rect(Rect2(center.x - 5, center.y - 5, 10, 1), Color("#70606a"))

static func _draw_rising_embers(canvas: CanvasItem, elapsed: float, tint: Color, count: int) -> void:
	for i in range(count):
		var ex := fposmod(float(i * 43 + 17) + sin(elapsed * 1.4 + float(i)) * 8.0, 312.0) + 4.0
		var ey := 152.0 - fposmod(elapsed * (9.0 + float(i % 5) * 2.5) + float(i * 19), 106.0)
		var a := tint.a * clampf((ey - 44.0) / 35.0, 0.0, 1.0)
		canvas.draw_rect(Rect2(ex, ey, 1.2, 1.2), Color(tint.r, tint.g, tint.b, a))

static func _draw_dust_motes(canvas: CanvasItem, elapsed: float, tint: Color, count: int) -> void:
	for i in range(count):
		var mx := fposmod(float(i * 37) + elapsed * (1.5 + float(i % 4)), 316.0)
		var my := 48.0 + float((i * 19) % 100) + sin(elapsed * 0.7 + float(i)) * 1.5
		canvas.draw_rect(Rect2(mx, my, 1, 1), tint)
