extends Node2D

## CHOKO — Phase 4.3: Instant-Start STORY, Souls-Like Combat Juice & High-Craft Visual Polish.
## Clicking STORY starts the underground escape immediately with zero spoilers.
## Adds 0.14s attack/dodge input buffering, Souls-like trailing boss HP bar,
## expanding impact rings, typewriter dialogue with soft voice blips, smooth fades,
## and atmospheric underground shaft transitions between chapters.

const BossData := preload("res://scripts/boss_data.gd")
const BossController := preload("res://scripts/boss_controller.gd")
const ArenaRenderer := preload("res://scripts/arena_renderer.gd")
const BossRenderer := preload("res://scripts/boss_renderer.gd")
const UiRenderer := preload("res://scripts/ui_and_cutscenes.gd")
const AudioManager := preload("res://scripts/audio_manager.gd")
const SpriteBank := preload("res://scripts/sprite_bank.gd")

const WORLD_W := 320.0
const WORLD_H := 180.0
const VIEW_W := 640.0
const VIEW_H := 360.0
const PLAYER_SPEED := 70.0
const DODGE_SPEED := 148.0
const MAX_COAL := 12
const MINE_TIME := 1.0
const WORLD_MIN := Vector2(13.0, 53.0)
const WORLD_MAX := Vector2(307.0, 148.0)
const SAVE_PATH := "user://choko_save.json"

const C_BG := Color("#080a12")
const C_TEXT := Color("#f2ead5")
const C_MUTED := Color("#aba4b8")
const C_WARM_HI := Color("#ffd999")
const C_RED := Color("#eb6d63")
const C_CYAN := Color("#77d8d0")
const C_CYAN_HI := Color("#c7fff4")
const C_COAL := Color("#3b3c49")

# Navigation: "title", "bosses", "transition", "cutscene", "combat"
var screen_mode: String = "title"
var title_selected_idx: int = 0 # 0=STORY, 1=BOSSES, 2=SETTINGS
var bosses_selected_idx: int = 0
var settings_open: bool = false
var settings_selected_row: int = 0
var play_context: String = "story" # "story" chains next shaft; "bosses" returns to bosses screen
var cutscene_kind: String = ""
var cutscene_lines: Array = []
var cutscene_idx: int = 0
var cutscene_chars: float = 0.0
var cutscene_blip_accum: float = 0.0
var post_gf_choice: bool = false
var current_boss_id: String = "farhan"
var victory_summary_text: String = ""

# Atmospheric shaft transition & smooth screen fades
var transition_timer: float = 0.0
var transition_duration: float = 1.45
var transition_target_boss: String = "farhan"
var transition_show_intro: bool = true
var screen_fade: float = 1.0

var save_data: Dictionary = {
	"cleared": [],
	"attempts": {},
	"best_phase": {},
	"mastery": {},
	"dead_cat_discovered": false,
	"prologue_seen": false,
	"settings": {
		"difficulty": "nightmare",
		"music_vol": 0.75,
		"sfx_vol": 0.85,
		"touch_opacity": 0.85,
		"touch_scale": 1.0,
		"shake_scale": 1.0,
		"flash_scale": 1.0,
		"haptics": true,
		"debug_hitboxes": false,
	}
}

var boss: BossController = null
var boss_hp_trail: float = 180.0
var audio: AudioManager = null
var sprites: SpriteBank = null

# Player combat state
var player_pos := Vector2(72.0, 113.0)
var player_vel := Vector2.ZERO
var player_facing := Vector2.RIGHT
var attack_direction := Vector2.RIGHT
var move_input := Vector2.ZERO
var player_hearts := 5
var coal_ammo := 6
var player_invuln := 0.0
var player_flash := 0.0
var dodge_timer := 0.0
var dodge_cooldown := 0.0
var perfect_dodge_timer := 0.0
var perfect_dodge_count := 0
var counter_strike_timer := 0.0
var dodge_direction := Vector2.RIGHT
var attack_timer := 0.0
var attack_cooldown := 0.0
var attack_combo := 0
var last_attack_time := -10.0
var attack_hit := false
var attack_buffer_timer := 0.0 # 0.14s Souls-like input buffer!
var dodge_buffer_timer := 0.0  # 0.14s Souls-like input buffer!
var mining := false
var mine_progress := 0.0
var mine_tick_accum := 0.0
var mine_vein := -1
var footstep_dust_accum := 0.0
var auto_aim := true
var paused := false
var death_reset_timer := 0.0
var death_menu_active := false
var brainrot_caption_index := 0
var brainrot_caption_timer := 0.0
var victory_delay_timer := 0.0
var fight_elapsed := 0.0
var fight_hits_taken := 0

var coal_projectiles: Array = []
var particles: Array = []
var impact_rings: Array = []
var floating_texts: Array = []
var veins: Array = []
var elapsed := 0.0
var hitstop := 0.0
var screen_shake := 0.0
var shake_offset := Vector2.ZERO
var combo_label_timer := 0.0
var combo_label := ""
var message_text := ""
var message_timer := 0.0
var damage_flash := 0.0

var joystick_touch := -1
var joystick_origin := Vector2(86.0, 278.0)
var joystick_vector := Vector2.ZERO
var coal_touch := -1
var coal_touch_origin := Vector2.ZERO
var coal_aim_vector := Vector2.ZERO
var pressed_buttons: Dictionary = {}

func _ready() -> void:
	boss = BossController.new()
	sprites = SpriteBank.new()
	sprites.load_all()
	audio = AudioManager.new()
	audio.name = "AudioManager"
	add_child(audio)
	_load_save()
	_apply_audio_settings()
	boss.setup("farhan", _get_difficulty())
	boss_hp_trail = boss.max_hp
	_reset_veins()
	audio.play_music("hub_mine")
	screen_fade = 0.85
	queue_redraw()

# =============================================================================
# SAVE DATA, SETTINGS & MASTERY TRACKING
# =============================================================================

func _get_settings() -> Dictionary:
	var s: Dictionary = save_data.get("settings", {})
	if not s.has("difficulty"): s["difficulty"] = "nightmare"
	if not s.has("music_vol"): s["music_vol"] = 0.75
	if not s.has("sfx_vol"): s["sfx_vol"] = 0.85
	if not s.has("touch_opacity"): s["touch_opacity"] = 0.85
	if not s.has("touch_scale"): s["touch_scale"] = 1.0
	if not s.has("shake_scale"): s["shake_scale"] = 1.0
	if not s.has("flash_scale"): s["flash_scale"] = 1.0
	if not s.has("haptics"): s["haptics"] = true
	if not s.has("debug_hitboxes"): s["debug_hitboxes"] = false
	save_data["settings"] = s
	return s

func _get_difficulty() -> String:
	return str(_get_settings().get("difficulty", "nightmare"))

func _is_easy() -> bool:
	return _get_difficulty() == "easy"

func _toggle_difficulty() -> void:
	var s := _get_settings()
	s["difficulty"] = "easy" if str(s.get("difficulty", "nightmare")) != "easy" else "nightmare"
	save_data["settings"] = s
	_save_progress()
	audio.play_sfx("ui_confirm", 0.03)

func _apply_audio_settings() -> void:
	var s := _get_settings()
	if audio != null:
		audio.apply_settings(float(s["music_vol"]), float(s["sfx_vol"]))

func _load_save() -> void:
	if not FileAccess.file_exists(SAVE_PATH):
		return
	var f := FileAccess.open(SAVE_PATH, FileAccess.READ)
	if f == null:
		return
	var parsed: Variant = JSON.parse_string(f.get_as_text())
	f.close()
	if parsed is Dictionary:
		save_data["cleared"] = parsed.get("cleared", [])
		save_data["attempts"] = parsed.get("attempts", {})
		save_data["best_phase"] = parsed.get("best_phase", {})
		save_data["mastery"] = parsed.get("mastery", {})
		save_data["dead_cat_discovered"] = bool(parsed.get("dead_cat_discovered", false))
		save_data["prologue_seen"] = bool(parsed.get("prologue_seen", false))
		if parsed.get("settings") is Dictionary:
			var loaded_s: Dictionary = parsed.get("settings")
			var cur_s := _get_settings()
			for k in loaded_s.keys():
				cur_s[k] = loaded_s[k]
			save_data["settings"] = cur_s

func _save_progress() -> void:
	var f := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if f == null:
		return
	f.store_string(JSON.stringify(save_data))
	f.close()

func _cycle_setting_row(row_idx: int) -> void:
	var s := _get_settings()
	if row_idx == 0:
		s["difficulty"] = "easy" if str(s.get("difficulty", "nightmare")) != "easy" else "nightmare"
	elif row_idx == 1:
		s["music_vol"] = _next_step([0.0, 0.25, 0.5, 0.75, 1.0], float(s["music_vol"]))
	elif row_idx == 2:
		s["sfx_vol"] = _next_step([0.0, 0.25, 0.5, 0.75, 1.0], float(s["sfx_vol"]))
	elif row_idx == 3:
		s["touch_opacity"] = _next_step([0.40, 0.60, 0.85, 1.0], float(s["touch_opacity"]))
	elif row_idx == 4:
		s["touch_scale"] = _next_step([0.85, 1.0, 1.15], float(s["touch_scale"]))
	elif row_idx == 5:
		s["shake_scale"] = _next_step([0.0, 0.5, 1.0], float(s["shake_scale"]))
	elif row_idx == 6:
		s["flash_scale"] = _next_step([0.0, 0.5, 1.0], float(s["flash_scale"]))
	elif row_idx == 7:
		s["haptics"] = not bool(s["haptics"])
	elif row_idx == 8:
		s["debug_hitboxes"] = not bool(s["debug_hitboxes"])
	save_data["settings"] = s
	_apply_audio_settings()
	_save_progress()
	audio.play_sfx("ui_select", 0.02)

func _next_step(steps: Array, cur: float) -> float:
	var best_i := 0
	var best_diff := 999.0
	for i in range(steps.size()):
		var d := absf(float(steps[i]) - cur)
		if d < best_diff:
			best_diff = d
			best_i = i
	return float(steps[(best_i + 1) % steps.size()])

func _record_attempt(bid: String) -> void:
	var attempts: Dictionary = save_data.get("attempts", {})
	attempts[bid] = int(attempts.get(bid, 0)) + 1
	save_data["attempts"] = attempts
	var bp: Dictionary = save_data.get("best_phase", {})
	bp[bid] = maxi(int(bp.get(bid, 1)), boss.best_phase_reached)
	save_data["best_phase"] = bp
	_save_progress()

func _record_victory(bid: String) -> void:
	var cleared: Array = save_data.get("cleared", [])
	if not cleared.has(bid):
		cleared.append(bid)
	save_data["cleared"] = cleared
	var bp: Dictionary = save_data.get("best_phase", {})
	bp[bid] = 3
	save_data["best_phase"] = bp

	var mastery: Dictionary = save_data.get("mastery", {})
	var bm: Dictionary = mastery.get(bid, {})
	var prev_time := float(bm.get("best_time", 0.0))
	if prev_time <= 0.0 or fight_elapsed < prev_time:
		bm["best_time"] = fight_elapsed
	var is_no_hit := (fight_hits_taken == 0)
	if is_no_hit:
		bm["no_hit"] = true
	bm["best_pd"] = maxi(int(bm.get("best_pd", 0)), perfect_dodge_count)
	mastery[bid] = bm
	save_data["mastery"] = mastery

	victory_summary_text = ("EASY  •  TIME " if _is_easy() else "NIGHTMARE  •  TIME ") + str(int(roundf(fight_elapsed))) + "s  •  " + ("★ NO-HIT CROWN!" if is_no_hit else (str(fight_hits_taken) + " HITS")) + "  •  PD " + str(perfect_dodge_count)
	_save_progress()

# =============================================================================
# INSTANT-START STORY, SHAFT TRANSITIONS & ENCOUNTER FLOW
# =============================================================================

func _play_boss_music(bid: String) -> void:
	if audio == null:
		return
	if bid == "sentinel":
		audio.play_music("hub_mine")
	else:
		audio.play_music(bid)

func _return_to_title() -> void:
	paused = false
	settings_open = false
	death_menu_active = false
	screen_mode = "title"
	screen_fade = 0.65
	if audio != null:
		audio.play_music("hub_mine")

func _open_bosses_screen() -> void:
	paused = false
	settings_open = false
	death_menu_active = false
	screen_mode = "bosses"
	screen_fade = 0.45
	if audio != null:
		audio.play_music("hub_mine")

func _start_story_immediately() -> void:
	# Instant-start STORY with ZERO spoilers: jumps straight into the campaign!
	play_context = "story"
	paused = false
	settings_open = false
	death_menu_active = false
	var cleared: Array = save_data.get("cleared", [])
	var next_id := ""
	for cid in BossData.CAMPAIGN_ORDER:
		if not cleared.has(cid):
			next_id = cid
			break
	if next_id == "farhan" or (next_id.is_empty() and cleared.has("dead_cat")):
		# Fresh campaign or replaying after full clear -> launch directly into Prologue ("THE SHIFT")!
		_start_story_prologue()
		return
	if next_id.is_empty() and cleared.has("grandfather") and not cleared.has("dead_cat"):
		# Main 5 cleared, secret Dead Cat awaits!
		_start_dead_cat_discovery()
		return
	# Resume directly at the next uncleared underground shaft!
	_begin_shaft_transition(next_id, true)

func _start_story_prologue() -> void:
	play_context = "story"
	save_data["prologue_seen"] = true
	_save_progress()
	audio.play_music("hub_mine")
	screen_mode = "cutscene"
	cutscene_kind = "story_prologue"
	cutscene_lines = BossData.get_prologue_lines()
	cutscene_idx = 0
	cutscene_chars = 0.0
	post_gf_choice = false
	screen_fade = 0.75

func _begin_shaft_transition(bid: String, show_intro: bool) -> void:
	transition_target_boss = bid
	transition_show_intro = show_intro
	transition_duration = 1.45
	transition_timer = transition_duration
	screen_mode = "transition"
	audio.play_sfx("shaft_transition", 0.02)

func _start_encounter(bid: String, show_intro: bool) -> void:
	current_boss_id = bid
	boss.setup(bid, _get_difficulty())
	boss_hp_trail = boss.max_hp
	_reset_combat_state()
	_play_boss_music(bid)
	screen_fade = 0.55
	if show_intro:
		var lines: Array = boss.cfg.get("intro_lines", [])
		if not lines.is_empty():
			screen_mode = "cutscene"
			cutscene_kind = "boss_intro"
			cutscene_lines = []
			for l in lines:
				cutscene_lines.append(l)
			cutscene_idx = 0
			cutscene_chars = 0.0
			post_gf_choice = false
			return
	screen_mode = "combat"
	_show_message(str(boss.cfg.get("name", "BOSS")) + "  •  " + str(boss.cfg.get("mechanic_hint", "")))

func _start_dead_cat_discovery() -> void:
	current_boss_id = "dead_cat"
	save_data["dead_cat_discovered"] = true
	_save_progress()
	boss.setup("dead_cat", _get_difficulty())
	boss_hp_trail = boss.max_hp
	_reset_combat_state()
	audio.play_music("dead_cat")
	audio.play_sfx("dead_cat_chime", 0.0)
	screen_mode = "cutscene"
	cutscene_kind = "dead_cat_discovery"
	cutscene_lines = BossData.get_dead_cat_discovery_lines()
	cutscene_idx = 0
	cutscene_chars = 0.0
	post_gf_choice = false
	screen_fade = 0.85

func _start_plane_escape() -> void:
	audio.play_music("escape_plane")
	screen_mode = "cutscene"
	cutscene_kind = "plane_escape"
	cutscene_lines = BossData.get_plane_escape_lines()
	cutscene_idx = 0
	cutscene_chars = 0.0
	post_gf_choice = false
	screen_fade = 0.85

func _advance_cutscene() -> void:
	if post_gf_choice:
		return
	# Tap once while typewriter is typing to finish the line immediately; tap again to advance!
	if cutscene_idx >= 0 and cutscene_idx < cutscene_lines.size():
		var full_len := str(cutscene_lines[cutscene_idx].get("text", "")).length()
		if int(cutscene_chars) < full_len:
			cutscene_chars = float(full_len)
			return
	audio.play_sfx("ui_select", 0.02)
	cutscene_idx += 1
	cutscene_chars = 0.0
	if cutscene_idx < cutscene_lines.size():
		return
	_finish_cutscene()

func _finish_cutscene() -> void:
	if cutscene_kind == "story_prologue":
		_begin_shaft_transition("farhan", true)
	elif cutscene_kind == "boss_intro":
		screen_mode = "combat"
		screen_fade = 0.35
		_show_message(str(boss.cfg.get("name", "BOSS")) + "  •  " + str(boss.cfg.get("mechanic_hint", "FIGHT!")))
	elif cutscene_kind == "dead_cat_discovery":
		_begin_shaft_transition("dead_cat", true)
	elif cutscene_kind == "boss_victory":
		if current_boss_id == "grandfather":
			post_gf_choice = true
		elif current_boss_id == "dead_cat":
			_start_plane_escape()
		elif current_boss_id == "sentinel":
			_open_bosses_screen()
		elif play_context == "story":
			var nxt := BossData.next_campaign_boss(current_boss_id)
			if not nxt.is_empty():
				_begin_shaft_transition(nxt, true)
			else:
				_return_to_title()
		else:
			_open_bosses_screen()
	elif cutscene_kind == "plane_escape":
		_return_to_title()

func _reset_veins() -> void:
	veins.clear()
	var positions: Array = boss.cfg.get("veins", [Vector2(42, 77), Vector2(155, 137), Vector2(286, 76)])
	for vp in positions:
		veins.append({"pos": vp, "active": true, "respawn": 0.0})

func _reset_combat_state() -> void:
	player_pos = Vector2(72.0, 113.0)
	player_vel = Vector2.ZERO
	player_facing = Vector2.RIGHT
	attack_direction = Vector2.RIGHT
	move_input = Vector2.ZERO
	player_hearts = 5
	coal_ammo = 8 if _is_easy() else 6
	perfect_dodge_timer = 0.0
	perfect_dodge_count = 0
	counter_strike_timer = 0.0
	dodge_timer = 0.0
	dodge_cooldown = 0.0
	player_invuln = 0.8
	player_flash = 0.0
	attack_timer = 0.0
	attack_cooldown = 0.0
	attack_combo = 0
	attack_hit = false
	attack_buffer_timer = 0.0
	dodge_buffer_timer = 0.0
	mining = false
	mine_progress = 0.0
	mine_tick_accum = 0.0
	mine_vein = -1
	footstep_dust_accum = 0.0
	paused = false
	settings_open = false
	death_reset_timer = 0.0
	death_menu_active = false
	victory_delay_timer = 0.0
	fight_elapsed = 0.0
	fight_hits_taken = 0
	victory_summary_text = ""
	brainrot_caption_index = 0
	brainrot_caption_timer = 0.0
	coal_projectiles.clear()
	particles.clear()
	impact_rings.clear()
	floating_texts.clear()
	joystick_touch = -1
	joystick_vector = Vector2.ZERO
	coal_touch = -1
	coal_aim_vector = Vector2.ZERO
	pressed_buttons.clear()
	_reset_veins()

func _restart_current_fight() -> void:
	audio.play_sfx("ui_confirm", 0.0)
	_start_encounter(current_boss_id, false)

# =============================================================================
# MAIN LOOP
# =============================================================================

func _process(delta: float) -> void:
	elapsed += delta
	screen_fade = maxf(0.0, screen_fade - delta * 2.2)
	message_timer = maxf(0.0, message_timer - delta)
	combo_label_timer = maxf(0.0, combo_label_timer - delta)
	damage_flash = maxf(0.0, damage_flash - delta)

	if screen_mode == "transition":
		transition_timer -= delta
		if transition_timer <= 0.0:
			_start_encounter(transition_target_boss, transition_show_intro)
		queue_redraw()
		return

	if screen_mode == "cutscene":
		if not post_gf_choice and cutscene_idx >= 0 and cutscene_idx < cutscene_lines.size():
			var full_len := str(cutscene_lines[cutscene_idx].get("text", "")).length()
			if int(cutscene_chars) < full_len:
				cutscene_chars = minf(float(full_len), cutscene_chars + delta * 54.0)
				cutscene_blip_accum += delta
				if cutscene_blip_accum >= 0.065:
					cutscene_blip_accum = 0.0
					audio.play_sfx("text_blip", 0.08)
		queue_redraw()
		return

	if screen_mode != "combat" or settings_open:
		queue_redraw()
		return

	if death_reset_timer > 0.0:
		death_reset_timer -= delta
		if death_reset_timer <= 0.0:
			death_reset_timer = 0.0
			death_menu_active = true
			brainrot_caption_index = 0
			brainrot_caption_timer = 0.0
		queue_redraw()
		return

	if death_menu_active:
		brainrot_caption_timer += delta
		if brainrot_caption_timer >= 2.4:
			brainrot_caption_timer = 0.0
			brainrot_caption_index = (brainrot_caption_index + 1) % 4
		queue_redraw()
		return

	if victory_delay_timer > 0.0:
		victory_delay_timer -= delta
		boss_hp_trail = move_toward(boss_hp_trail, 0.0, delta * 140.0)
		_update_particles(delta)
		_update_impact_rings(delta)
		_update_floating_texts(delta)
		if victory_delay_timer <= 0.0:
			var vlines: Array = boss.cfg.get("victory_lines", [])
			cutscene_lines = []
			for l in vlines:
				cutscene_lines.append(l)
			cutscene_idx = 0
			cutscene_chars = 0.0
			cutscene_kind = "boss_victory"
			post_gf_choice = false
			screen_mode = "cutscene"
		queue_redraw()
		return

	if paused:
		queue_redraw()
		return

	if hitstop > 0.0:
		hitstop = maxf(0.0, hitstop - delta)
		queue_redraw()
		return

	fight_elapsed += delta
	_update_timers(delta)
	_read_keyboard()
	_consume_input_buffers()
	_update_player(delta)
	_update_mining(delta)
	_update_veins(delta)
	_update_attacks()
	_update_coal_projectiles(delta)
	boss.update(delta, player_pos, mining, player_vel)
	_process_boss_events()
	_update_particles(delta)
	_update_impact_rings(delta)
	_update_floating_texts(delta)

	# Smooth Souls-like trailing boss HP lag bar
	if boss_hp_trail > boss.hp:
		boss_hp_trail = maxf(boss.hp, boss_hp_trail - delta * maxf(58.0, (boss_hp_trail - boss.hp) * 3.2))
	else:
		boss_hp_trail = boss.hp

	var shake_mult := float(_get_settings()["shake_scale"])
	if screen_shake > 0.0 and shake_mult > 0.01:
		screen_shake = maxf(0.0, screen_shake - delta * 24.0)
		var eff := screen_shake * shake_mult
		shake_offset = Vector2(randf_range(-eff, eff), randf_range(-eff, eff))
	else:
		screen_shake = 0.0
		shake_offset = Vector2.ZERO
	queue_redraw()

func _update_timers(delta: float) -> void:
	player_invuln = maxf(0.0, player_invuln - delta)
	player_flash = maxf(0.0, player_flash - delta)
	dodge_timer = maxf(0.0, dodge_timer - delta)
	perfect_dodge_timer = maxf(0.0, perfect_dodge_timer - delta)
	counter_strike_timer = maxf(0.0, counter_strike_timer - delta)
	dodge_cooldown = maxf(0.0, dodge_cooldown - delta)
	attack_timer = maxf(0.0, attack_timer - delta)
	attack_cooldown = maxf(0.0, attack_cooldown - delta)
	attack_buffer_timer = maxf(0.0, attack_buffer_timer - delta)
	dodge_buffer_timer = maxf(0.0, dodge_buffer_timer - delta)

func _consume_input_buffers() -> void:
	if dodge_buffer_timer > 0.0 and not mining and dodge_cooldown <= 0.0 and death_reset_timer <= 0.0:
		dodge_buffer_timer = 0.0
		_execute_dodge()
	elif attack_buffer_timer > 0.0 and not mining and attack_cooldown <= 0.0 and dodge_timer <= 0.0 and death_reset_timer <= 0.0:
		attack_buffer_timer = 0.0
		_execute_pickaxe_attack()

func _read_keyboard() -> void:
	var keyboard := Vector2.ZERO
	if Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT):
		keyboard.x -= 1.0
	if Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT):
		keyboard.x += 1.0
	if Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP):
		keyboard.y -= 1.0
	if Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN):
		keyboard.y += 1.0
	if keyboard.length() > 0.0:
		move_input = keyboard.normalized()
		_update_facing_from_stick(move_input)
	elif joystick_touch == -1:
		move_input = Vector2.ZERO

func _update_player(delta: float) -> void:
	var prev_pos := player_pos
	if mining:
		move_input = Vector2.ZERO
		player_vel = Vector2.ZERO
		return
	if dodge_timer > 0.0:
		player_pos += dodge_direction * DODGE_SPEED * delta
	elif move_input.length() > 0.05:
		# Grounded 4-direction floor-plane movement only; Choko never jumps or flies.
		player_pos += move_input.limit_length(1.0) * PLAYER_SPEED * delta
		footstep_dust_accum += delta
		if footstep_dust_accum >= 0.19:
			footstep_dust_accum = 0.0
			_spawn_particles(player_pos + Vector2(0, 5), Color("#7d788a"), 2)
	player_pos.x = clampf(player_pos.x, WORLD_MIN.x, WORLD_MAX.x)
	player_pos.y = clampf(player_pos.y, WORLD_MIN.y, WORLD_MAX.y)
	player_vel = (player_pos - prev_pos) / maxf(0.001, delta)

func _update_facing_from_stick(direction: Vector2) -> void:
	if direction.length() < 0.18:
		return
	if absf(direction.x) > absf(direction.y):
		attack_direction = Vector2.RIGHT if direction.x > 0.0 else Vector2.LEFT
	else:
		attack_direction = Vector2.DOWN if direction.y > 0.0 else Vector2.UP
	player_facing = attack_direction

func _update_mining(delta: float) -> void:
	if not mining:
		return
	if mine_vein < 0 or mine_vein >= veins.size():
		_cancel_mining("THE VEIN IS OUT OF REACH")
		return
	mine_progress += delta
	mine_tick_accum += delta
	if mine_tick_accum >= 0.28:
		mine_tick_accum = 0.0
		audio.play_sfx("mine_tick", 0.08)
		_spawn_particles(Vector2(veins[mine_vein]["pos"]) + Vector2(0, -3), C_WARM_HI, 3)
	if mine_progress >= MINE_TIME:
		var vein: Dictionary = veins[mine_vein]
		vein["active"] = false
		vein["respawn"] = 6.5 if _is_easy() else 10.5
		veins[mine_vein] = vein
		var vein_pos: Vector2 = vein["pos"]
		var old_ammo := coal_ammo
		coal_ammo = mini(MAX_COAL, coal_ammo + 3)
		audio.play_sfx("mine_complete", 0.02)
		_spawn_particles(vein_pos + Vector2(0, -4), C_WARM_HI, 17)
		_spawn_impact_ring(vein_pos + Vector2(0, -4), C_WARM_HI, 22.0)
		_add_float_text(vein_pos + Vector2(0, -13), "+" + str(coal_ammo - old_ammo) + " COAL", C_WARM_HI)
		_show_message("VEIN MINED  •  +" + str(coal_ammo - old_ammo) + " COAL")
		mining = false
		mine_progress = 0.0
		mine_vein = -1
		screen_shake = 1.7

func _update_veins(delta: float) -> void:
	for i in range(veins.size()):
		var vein: Dictionary = veins[i]
		if not bool(vein["active"]):
			vein["respawn"] = maxf(0.0, float(vein["respawn"]) - delta)
			if float(vein["respawn"]) <= 0.0:
				vein["active"] = true
		veins[i] = vein

func _update_attacks() -> void:
	if attack_timer <= 0.0 or attack_hit:
		return
	var is_counter := counter_strike_timer > 0.0
	var base_damage: float = float([13.0, 17.0, 26.0][clampi(attack_combo - 1, 0, 2)])
	var damage: float = base_damage * (1.60 if is_counter else 1.0)
	var posture_dmg: float = 38.0 if is_counter else float([8.0, 12.0, 24.0][clampi(attack_combo - 1, 0, 2)])
	var swing_center := player_pos + attack_direction * 22.0

	if boss.try_hit_interactive(swing_center, 19.0, damage, true):
		attack_hit = true
		audio.play_sfx("counter_strike", 0.05)
		_spawn_impact_ring(swing_center, C_CYAN_HI, 24.0)
		hitstop = 0.045
		screen_shake = 2.0
		_haptic(14)
		return

	var to_boss: Vector2 = boss.pos - player_pos
	var forward_distance := to_boss.dot(attack_direction)
	var side_distance := absf(to_boss.x * attack_direction.y - to_boss.y * attack_direction.x)
	var reach := 30.0 + boss.get_hitbox_radius()
	var width := 10.0 + boss.get_hitbox_radius()
	if forward_distance >= -4.0 and forward_distance <= reach and side_distance <= width and boss.is_hittable():
		attack_hit = true
		if is_counter:
			counter_strike_timer = 0.0
			audio.play_sfx("counter_strike", 0.02)
		else:
			var sfx_n := "pickaxe_finisher" if attack_combo == 3 else ("pickaxe_2" if attack_combo == 2 else "pickaxe_1")
			audio.play_sfx(sfx_n, 0.05)
		var res: Dictionary = boss.take_damage(damage, true, posture_dmg)
		if bool(res.get("hit", false)):
			var dealt := int(res.get("damage", damage))
			var tag: String = "COUNTER!" if is_counter else str(res.get("tag", ""))
			var pcol := C_CYAN_HI if is_counter else C_WARM_HI
			_spawn_particles(boss.pos + Vector2(0, -8), pcol, 20 if is_counter else (10 + attack_combo * 3))
			_spawn_impact_ring(boss.pos + Vector2(0, -6), pcol, 32.0 if is_counter else (26.0 if attack_combo == 3 else 18.0))
			var txt := str(dealt) if tag.is_empty() else (str(dealt) + " " + tag)
			_add_float_text(boss.pos + Vector2(randf_range(-5, 5), -24), txt, pcol if tag != "VEILED" else C_MUTED)
			hitstop = 0.075 if is_counter else (0.065 if attack_combo == 3 else 0.04)
			screen_shake = 3.6 if is_counter else (2.9 if attack_combo == 3 else 1.6)
			combo_label = "COUNTER STRIKE!" if is_counter else ["QUICK CUT", "CROSS STRIKE", "HEAVY FINISH"][clampi(attack_combo - 1, 0, 2)]
			combo_label_timer = 0.72
			_haptic(24 if is_counter else (18 if attack_combo == 3 else 10))

func _update_coal_projectiles(delta: float) -> void:
	for i in range(coal_projectiles.size() - 1, -1, -1):
		var shot: Dictionary = coal_projectiles[i]
		var shot_pos: Vector2 = shot["pos"] + Vector2(shot["vel"]) * delta
		shot["pos"] = shot_pos
		shot["life"] = float(shot["life"]) - delta

		if boss.try_ignite_brazier_at(shot_pos):
			_spawn_impact_ring(shot_pos, C_WARM_HI, 26.0)
			coal_projectiles.remove_at(i)
			continue

		if boss.try_hit_interactive(shot_pos, 10.0, 19.0, false):
			audio.play_sfx("coal_impact", 0.06)
			_spawn_impact_ring(shot_pos, C_WARM_HI, 18.0)
			coal_projectiles.remove_at(i)
			continue

		if shot_pos.distance_to(boss.pos + Vector2(0, -5)) < boss.get_hitbox_radius() + 2.0 and boss.is_hittable():
			var res: Dictionary = boss.take_damage(19.0, false, 10.0)
			if bool(res.get("hit", false)):
				audio.play_sfx("coal_impact", 0.06)
				var dealt := int(res.get("damage", 19))
				var tag := str(res.get("tag", ""))
				_spawn_particles(shot_pos, C_WARM_HI, 12)
				_spawn_impact_ring(shot_pos, C_WARM_HI, 18.0)
				var txt := str(dealt) if tag.is_empty() else (str(dealt) + " " + tag)
				_add_float_text(shot_pos + Vector2(0, -8), txt, C_WARM_HI if tag != "VEILED" else C_MUTED)
				hitstop = 0.045
			coal_projectiles.remove_at(i)
		elif float(shot["life"]) <= 0.0 or shot_pos.x < -5.0 or shot_pos.x > WORLD_W + 5.0 or shot_pos.y < 20.0 or shot_pos.y > WORLD_H:
			coal_projectiles.remove_at(i)
		else:
			coal_projectiles[i] = shot

func _process_boss_events() -> void:
	var evs: Array = boss.consume_events()
	for ev in evs:
		var t := str(ev.get("type", ""))
		if t == "hurt_player":
			_handle_hostile_hit(int(ev.get("amount", 1)), ev.get("pos", player_pos))
		elif t == "sfx":
			var sname := str(ev.get("name", ""))
			audio.play_sfx(sname, 0.03)
			if sname == "posture_break":
				_spawn_impact_ring(boss.pos, C_WARM_HI, 46.0)
		elif t == "particles":
			_spawn_particles(ev["pos"], ev["color"], int(ev["count"]))
		elif t == "float_text":
			_add_float_text(ev["pos"], str(ev["text"]), ev["color"])
		elif t == "message":
			_show_message(str(ev["text"]))
		elif t == "shake":
			screen_shake = maxf(screen_shake, float(ev["amount"]))
		elif t == "hitstop":
			hitstop = maxf(hitstop, float(ev.get("duration", 0.06)))
		elif t == "haptic":
			_haptic(int(ev["ms"]))
		elif t == "grant_coal":
			var old_c := coal_ammo
			coal_ammo = mini(MAX_COAL, coal_ammo + int(ev.get("amount", 1)))
			if coal_ammo > old_c:
				_add_float_text(player_pos + Vector2(0, -18), "+" + str(coal_ammo - old_c) + " COAL", C_WARM_HI)
		elif t == "boss_defeated":
			_record_victory(current_boss_id)
			_spawn_impact_ring(boss.pos, C_CYAN_HI, 58.0)
			victory_delay_timer = 1.45
			_show_message(str(boss.cfg.get("name", "BOSS")) + " DEFEATED!")

func _handle_hostile_hit(amount: int, hit_pos: Vector2) -> void:
	if death_reset_timer > 0.0 or victory_delay_timer > 0.0:
		return
	if dodge_timer > 0.0:
		if perfect_dodge_timer > 0.0:
			perfect_dodge_timer = 0.0
			perfect_dodge_count += 1
			counter_strike_timer = 1.25
			var old_coal := coal_ammo
			coal_ammo = mini(MAX_COAL, coal_ammo + 1)
			boss.add_posture(22.0)
			audio.play_sfx("perfect_dodge", 0.02)
			_spawn_particles(hit_pos, C_CYAN_HI, 18)
			_spawn_impact_ring(player_pos + Vector2(0, -4), C_CYAN_HI, 32.0)
			_add_float_text(player_pos + Vector2(0, -21), "PERFECT DODGE!", C_CYAN_HI)
			_add_float_text(player_pos + Vector2(0, -31), "COUNTER READY" + (" +1 COAL" if coal_ammo > old_coal else ""), C_WARM_HI)
			hitstop = 0.08
			screen_shake = 1.6
			_haptic(24)
			_show_message("PERFECT DODGE  •  COUNTER STRIKE READY!")
		else:
			_spawn_particles(hit_pos, C_CYAN, 6)
		return
	if player_invuln > 0.0:
		return
	_hurt_player(amount)

func _hurt_player(amount: int) -> void:
	if player_invuln > 0.0 or dodge_timer > 0.0 or death_reset_timer > 0.0:
		return
	fight_hits_taken += 1
	player_hearts = maxi(0, player_hearts - amount)
	player_invuln = (1.35 if amount >= 2 else 1.28) if _is_easy() else (1.00 if amount >= 2 else 0.88)
	player_flash = 0.30
	damage_flash = 0.28 if amount >= 2 else 0.20
	counter_strike_timer = 0.0
	mining = false
	mine_progress = 0.0
	mine_vein = -1
	screen_shake = 5.6 if amount >= 2 else 4.2
	hitstop = 0.095 if amount >= 2 else 0.075
	audio.play_sfx("heavy_hurt" if amount >= 2 else "player_hurt", 0.04)
	_spawn_particles(player_pos + Vector2(0, -5), C_RED, 16 + amount * 6)
	_spawn_impact_ring(player_pos + Vector2(0, -5), C_RED, 26.0)
	_add_float_text(player_pos + Vector2(0, -20), "-" + str(amount) + " HEART" + ("S" if amount > 1 else ""), C_RED)
	_haptic(48 if amount >= 2 else 36)
	if player_hearts <= 0:
		_record_attempt(current_boss_id)
		death_reset_timer = 1.25
		_show_message("CHOKO DOWN  •  LOADING BREAK ROOM")
	else:
		_show_message("HIT TAKEN (-" + str(amount) + ")  •  " + str(player_hearts) + " HEARTS LEFT")

func _spawn_impact_ring(at: Vector2, tint: Color, max_r: float) -> void:
	if impact_rings.size() >= 14:
		return
	impact_rings.append({"pos": at, "radius": 4.0, "max_radius": max_r, "alpha": 1.0, "color": tint})

func _update_impact_rings(delta: float) -> void:
	for i in range(impact_rings.size() - 1, -1, -1):
		var ring: Dictionary = impact_rings[i]
		var nr := float(ring["radius"]) + delta * float(ring["max_radius"]) * 4.2
		ring["radius"] = nr
		ring["alpha"] = maxf(0.0, 1.0 - nr / maxf(1.0, float(ring["max_radius"])))
		if nr >= float(ring["max_radius"]):
			impact_rings.remove_at(i)
		else:
			impact_rings[i] = ring

func _spawn_particles(at: Vector2, tint: Color, count: int) -> void:
	var budget := maxi(0, 140 - particles.size())
	var n := mini(count, budget)
	for i in range(n):
		var angle := randf() * TAU
		var speed := randf_range(13.0, 55.0)
		particles.append({
			"pos": at,
			"vel": Vector2.RIGHT.rotated(angle) * speed,
			"life": randf_range(0.20, 0.52),
			"color": tint,
			"size": 1.0 if i % 3 != 0 else 2.0
		})

func _update_particles(delta: float) -> void:
	for i in range(particles.size() - 1, -1, -1):
		var p: Dictionary = particles[i]
		p["pos"] = Vector2(p["pos"]) + Vector2(p["vel"]) * delta
		p["vel"] = Vector2(p["vel"]) * 0.91 + Vector2(0, 25) * delta
		p["life"] = float(p["life"]) - delta
		if float(p["life"]) <= 0.0:
			particles.remove_at(i)
		else:
			particles[i] = p

func _add_float_text(at: Vector2, value: String, tint: Color) -> void:
	floating_texts.append({"pos": at, "text": value, "color": tint, "life": 0.82})

func _update_floating_texts(delta: float) -> void:
	for i in range(floating_texts.size() - 1, -1, -1):
		var item: Dictionary = floating_texts[i]
		item["pos"] = Vector2(item["pos"]) + Vector2(0, -17.0 * delta)
		item["life"] = float(item["life"]) - delta
		floating_texts[i] = item
		if float(item["life"]) <= 0.0:
			floating_texts.remove_at(i)

func _closest_vein() -> int:
	var best_index := -1
	var best_distance := 999.0
	for i in range(veins.size()):
		var vein: Dictionary = veins[i]
		if not bool(vein["active"]):
			continue
		var distance := player_pos.distance_to(Vector2(vein["pos"]))
		if distance < best_distance:
			best_distance = distance
			best_index = i
	return best_index if best_distance <= 24.0 else -1

func _start_mining() -> void:
	if paused or mining or _closest_vein() == -1 or dodge_timer > 0.0 or attack_timer > 0.0:
		if _closest_vein() == -1 and not mining:
			_show_message("MOVE BESIDE A GLOWING COAL SEAM  •  THEN MINE")
		return
	mining = true
	mine_progress = 0.0
	mine_tick_accum = 0.0
	mine_vein = _closest_vein()
	move_input = Vector2.ZERO
	audio.play_sfx("mine_tick", 0.05)
	_show_message("MINING  •  EXPOSED!")

func _cancel_mining(reason: String) -> void:
	mining = false
	mine_progress = 0.0
	mine_vein = -1
	_show_message(reason)

func _pickaxe_attack() -> void:
	if paused or mining or death_reset_timer > 0.0:
		return
	if attack_cooldown > 0.0 or dodge_timer > 0.0:
		attack_buffer_timer = 0.14
		return
	_execute_pickaxe_attack()

func _execute_pickaxe_attack() -> void:
	if elapsed - last_attack_time <= 0.78:
		attack_combo = (attack_combo % 3) + 1
	else:
		attack_combo = 1
	last_attack_time = elapsed
	attack_cooldown = 0.23
	attack_timer = 0.23 if attack_combo == 3 else 0.18
	attack_hit = false
	player_facing = attack_direction
	audio.play_sfx("pickaxe_1", 0.08)
	_haptic(7)

func _dodge() -> void:
	if paused or mining or death_reset_timer > 0.0:
		return
	if dodge_cooldown > 0.0:
		dodge_buffer_timer = 0.14
		return
	_execute_dodge()

func _execute_dodge() -> void:
	dodge_direction = move_input.normalized() if move_input.length() > 0.15 else player_facing
	if dodge_direction.length() < 0.1:
		dodge_direction = Vector2.LEFT
	dodge_timer = 0.31
	perfect_dodge_timer = 0.18 if _is_easy() else 0.13
	dodge_cooldown = 0.72 if _is_easy() else 0.88
	player_invuln = maxf(player_invuln, 0.31)
	audio.play_sfx("dodge_whoosh", 0.06)
	_spawn_particles(player_pos + Vector2(0, 3), C_CYAN, 8)
	_haptic(12)

func _get_auto_aim_target() -> Vector2:
	if boss.id == "allan" and boss.shadow_veiled:
		var bi: int = boss.get_nearest_unlit_brazier(player_pos)
		if bi != -1:
			return Vector2(boss.braziers[bi]["pos"])
	if boss.id == "grandfather" and not boss.crystals.is_empty():
		var ci: int = boss.get_nearest_crystal(player_pos)
		if ci != -1:
			return Vector2(boss.crystals[ci]["pos"])
	return boss.pos

func _throw_coal(direction: Vector2) -> void:
	if paused or mining or death_reset_timer > 0.0:
		return
	if coal_ammo <= 0:
		_show_message("NO COAL  •  MINE A GLOWING SEAM")
		return
	if direction.length() < 0.1:
		direction = (_get_auto_aim_target() - player_pos).normalized() if auto_aim else attack_direction
	if direction.length() < 0.1:
		direction = Vector2.RIGHT
	direction = direction.normalized()
	coal_ammo -= 1
	audio.play_sfx("coal_throw", 0.06)
	coal_projectiles.append({
		"pos": player_pos + Vector2(0, -10),
		"vel": direction * 116.0,
		"life": 1.8,
		"spin": randf() * TAU
	})
	_spawn_particles(player_pos + Vector2(0, -9), C_COAL, 5)
	_show_message("COAL CAST  •  " + str(coal_ammo) + " CHUNKS LEFT")
	_haptic(8)

func _show_message(value: String) -> void:
	message_text = value
	message_timer = 1.8

func _haptic(duration_ms: int) -> void:
	if not bool(_get_settings()["haptics"]):
		return
	if DisplayServer.is_touchscreen_available():
		Input.vibrate_handheld(duration_ms)

# =============================================================================
# INPUT: MULTI-TOUCH + KEYBOARD + DESKTOP MENU CLICKS
# =============================================================================

func _input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		if event.pressed:
			_touch_pressed(event.index, event.position)
		else:
			_touch_released(event.index, event.position)
	elif event is InputEventScreenDrag:
		_touch_dragged(event.index, event.position)
	elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
		if not DisplayServer.is_touchscreen_available() and (screen_mode != "combat" or paused or settings_open or death_menu_active):
			_touch_pressed(99, event.position)
	elif event is InputEventKey and event.pressed and not event.echo:
		_handle_key(event.keycode)

func _handle_key(code: int) -> void:
	if code == KEY_F3:
		var s := _get_settings()
		s["debug_hitboxes"] = not bool(s["debug_hitboxes"])
		save_data["settings"] = s
		_save_progress()
		_show_message("HITBOX OVERLAY " + ("ON" if bool(s["debug_hitboxes"]) else "OFF"))
		return

	if settings_open:
		if code == KEY_UP or code == KEY_W:
			settings_selected_row = (settings_selected_row + 8) % 9
			audio.play_sfx("ui_select", 0.02)
		elif code == KEY_DOWN or code == KEY_S:
			settings_selected_row = (settings_selected_row + 1) % 9
			audio.play_sfx("ui_select", 0.02)
		elif code == KEY_LEFT or code == KEY_RIGHT or code == KEY_A or code == KEY_D or code == KEY_ENTER or code == KEY_SPACE:
			_cycle_setting_row(settings_selected_row)
		elif code == KEY_ESCAPE:
			settings_open = false
			audio.play_sfx("ui_confirm", 0.0)
		return

	if screen_mode == "transition":
		if code == KEY_SPACE or code == KEY_ENTER or code == KEY_ESCAPE:
			transition_timer = 0.0
		return

	if screen_mode == "title":
		if code == KEY_DOWN or code == KEY_S or code == KEY_RIGHT or code == KEY_D:
			title_selected_idx = (title_selected_idx + 1) % 3
			audio.play_sfx("ui_select", 0.02)
		elif code == KEY_UP or code == KEY_W or code == KEY_LEFT or code == KEY_A:
			title_selected_idx = (title_selected_idx + 2) % 3
			audio.play_sfx("ui_select", 0.02)
		elif code == KEY_M:
			_toggle_difficulty()
		elif code == KEY_ENTER or code == KEY_SPACE:
			audio.play_sfx("ui_confirm", 0.0)
			_activate_title_btn(title_selected_idx)
		return

	if screen_mode == "bosses":
		if code == KEY_ESCAPE:
			audio.play_sfx("ui_select", 0.0)
			_return_to_title()
		elif code == KEY_RIGHT or code == KEY_D:
			bosses_selected_idx = (bosses_selected_idx + 1) % 7
			audio.play_sfx("ui_select", 0.02)
		elif code == KEY_LEFT or code == KEY_A:
			bosses_selected_idx = (bosses_selected_idx + 6) % 7
			audio.play_sfx("ui_select", 0.02)
		elif code == KEY_DOWN or code == KEY_S:
			bosses_selected_idx = mini(6, bosses_selected_idx + 2)
			audio.play_sfx("ui_select", 0.02)
		elif code == KEY_UP or code == KEY_W:
			bosses_selected_idx = maxi(0, bosses_selected_idx - 2)
			audio.play_sfx("ui_select", 0.02)
		elif code == KEY_ENTER or code == KEY_SPACE:
			audio.play_sfx("ui_confirm", 0.0)
			_activate_bosses_index(bosses_selected_idx)
		return

	if screen_mode == "cutscene":
		if post_gf_choice:
			if code == KEY_1 or code == KEY_LEFT or code == KEY_A:
				_start_dead_cat_discovery()
			elif code == KEY_2 or code == KEY_RIGHT or code == KEY_D or code == KEY_ENTER:
				_start_plane_escape()
		else:
			if code == KEY_ESCAPE:
				_finish_cutscene()
			elif code == KEY_SPACE or code == KEY_ENTER or code == KEY_J:
				_advance_cutscene()
		return

	if death_menu_active:
		if code == KEY_ENTER or code == KEY_SPACE:
			_restart_current_fight()
		elif code == KEY_ESCAPE:
			_return_to_title()
		return

	if code == KEY_ESCAPE:
		paused = not paused
		audio.play_sfx("ui_select", 0.0)
		return
	if paused:
		if code == KEY_R:
			_restart_current_fight()
		return

	if code == KEY_SPACE or code == KEY_J:
		_pickaxe_attack()
	elif code == KEY_K:
		_throw_coal(Vector2.ZERO)
	elif code == KEY_L or code == KEY_SHIFT:
		_dodge()
	elif code == KEY_E:
		_start_mining()
	elif code == KEY_T:
		auto_aim = not auto_aim
		audio.play_sfx("ui_select", 0.0)
		_show_message("AUTO AIM " + ("ON" if auto_aim else "OFF"))

func _activate_title_btn(idx: int) -> void:
	if idx == 0:
		_start_story_immediately()
	elif idx == 1:
		_open_bosses_screen()
	else:
		settings_open = true

func _activate_bosses_index(idx: int) -> void:
	play_context = "bosses"
	var ids := ["farhan", "allan", "john_paul", "aaron", "grandfather", "dead_cat", "sentinel"]
	var bid: String = ids[clampi(idx, 0, ids.size() - 1)]
	var cleared: Array = save_data.get("cleared", [])
	if bid == "dead_cat":
		if not cleared.has("grandfather"):
			return
		if not bool(save_data.get("dead_cat_discovered", false)):
			_start_dead_cat_discovery()
		else:
			_begin_shaft_transition("dead_cat", true)
		return
	_begin_shaft_transition(bid, true)

func _touch_pressed(index: int, p: Vector2) -> void:
	if settings_open:
		for i in range(UiRenderer.RECT_SETTINGS_ROWS.size()):
			if UiRenderer.RECT_SETTINGS_ROWS[i].has_point(p):
				settings_selected_row = i
				_cycle_setting_row(i)
				return
		if UiRenderer.RECT_SETTINGS_BACK.has_point(p):
			settings_open = false
			audio.play_sfx("ui_confirm", 0.0)
		return

	if screen_mode == "transition":
		transition_timer = 0.0
		return

	if screen_mode == "title":
		if UiRenderer.RECT_TITLE_DIFF.has_point(p):
			_toggle_difficulty()
			return
		for i in range(UiRenderer.RECT_TITLE_BTNS.size()):
			if UiRenderer.RECT_TITLE_BTNS[i].has_point(p):
				title_selected_idx = i
				audio.play_sfx("ui_confirm", 0.0)
				_activate_title_btn(i)
				return
		var cleared: Array = save_data.get("cleared", [])
		if cleared.has("grandfather") and UiRenderer.RECT_TITLE_ENDING.has_point(p):
			audio.play_sfx("ui_confirm", 0.0)
			_start_plane_escape()
		return

	if screen_mode == "bosses":
		if UiRenderer.RECT_BOSSES_BACK.has_point(p):
			audio.play_sfx("ui_select", 0.0)
			_return_to_title()
			return
		if UiRenderer.RECT_BOSSES_DIFF.has_point(p):
			_toggle_difficulty()
			return
		for i in range(UiRenderer.RECT_HUB_CARDS.size()):
			if UiRenderer.RECT_HUB_CARDS[i].has_point(p):
				bosses_selected_idx = i
				audio.play_sfx("ui_confirm", 0.0)
				_activate_bosses_index(i)
				return
		if UiRenderer.RECT_HUB_PRACTICE.has_point(p):
			bosses_selected_idx = 6
			audio.play_sfx("ui_confirm", 0.0)
			_activate_bosses_index(6)
			return
		if UiRenderer.RECT_HUB_STORY_BTN.has_point(p):
			audio.play_sfx("ui_confirm", 0.0)
			_start_story_immediately()
			return
		if UiRenderer.RECT_HUB_SETTINGS_BTN.has_point(p):
			audio.play_sfx("ui_confirm", 0.0)
			settings_open = true
			return
		return

	if screen_mode == "cutscene":
		if post_gf_choice:
			if UiRenderer.RECT_POST_GF_SECRET.has_point(p):
				_start_dead_cat_discovery()
			elif UiRenderer.RECT_POST_GF_ESCAPE.has_point(p):
				_start_plane_escape()
			return
		if UiRenderer.RECT_CUTSCENE_SKIP.has_point(p):
			audio.play_sfx("ui_confirm", 0.0)
			_finish_cutscene()
		else:
			_advance_cutscene()
		return

	if death_menu_active:
		if UiRenderer.RECT_RESPAWN_RETRY.has_point(p):
			_restart_current_fight()
		elif UiRenderer.RECT_RESPAWN_MENU.has_point(p):
			audio.play_sfx("ui_confirm", 0.0)
			_return_to_title()
		return

	if p.y < 44.0 and p.x < 56.0:
		paused = not paused
		audio.play_sfx("ui_select", 0.0)
		return
	if paused:
		if UiRenderer.RECT_PAUSE_RESUME.has_point(p):
			paused = false
			audio.play_sfx("ui_confirm", 0.0)
		elif UiRenderer.RECT_PAUSE_RESTART.has_point(p):
			paused = false
			_restart_current_fight()
		elif UiRenderer.RECT_PAUSE_SETTINGS.has_point(p):
			settings_open = true
			audio.play_sfx("ui_confirm", 0.0)
		elif UiRenderer.RECT_PAUSE_MENU.has_point(p):
			audio.play_sfx("ui_confirm", 0.0)
			_return_to_title()
		return

	if p.y < 44.0 and p.x > 528.0:
		auto_aim = not auto_aim
		audio.play_sfx("ui_select", 0.0)
		_show_message("AUTO AIM " + ("ON" if auto_aim else "OFF"))
		return

	if p.x < 320.0 and joystick_touch == -1 and p.y > 46.0:
		joystick_touch = index
		joystick_origin = Vector2(clampf(p.x, 50.0, 290.0), clampf(p.y, 124.0, 302.0))
		joystick_vector = Vector2.ZERO
		return

	var sc := clampf(float(_get_settings()["touch_scale"]), 0.80, 1.20)
	if p.distance_to(UiRenderer.BTN_PICK) <= 48.0 * sc:
		pressed_buttons[index] = "pick"
		_pickaxe_attack()
	elif p.distance_to(UiRenderer.BTN_COAL) <= 40.0 * sc:
		coal_touch = index
		coal_touch_origin = p
		coal_aim_vector = Vector2.ZERO
		pressed_buttons[index] = "coal"
	elif p.distance_to(UiRenderer.BTN_DODGE) <= 38.0 * sc:
		pressed_buttons[index] = "dodge"
		_dodge()
	elif p.distance_to(UiRenderer.BTN_MINE) <= 36.0 * sc and _closest_vein() != -1:
		pressed_buttons[index] = "mine"
		_start_mining()

func _touch_dragged(index: int, p: Vector2) -> void:
	if screen_mode != "combat" or paused or settings_open or death_menu_active:
		return
	if index == joystick_touch:
		var offset := p - joystick_origin
		joystick_vector = offset.limit_length(54.0) / 54.0
		move_input = joystick_vector
		_update_facing_from_stick(move_input)
	elif index == coal_touch:
		coal_aim_vector = p - coal_touch_origin

func _touch_released(index: int, _p: Vector2) -> void:
	if index == joystick_touch:
		joystick_touch = -1
		joystick_vector = Vector2.ZERO
		move_input = Vector2.ZERO
	if index == coal_touch:
		var direction := coal_aim_vector
		if direction.length() < 18.0:
			direction = (_get_auto_aim_target() - player_pos) if auto_aim else attack_direction
		_throw_coal(direction)
		coal_touch = -1
		coal_aim_vector = Vector2.ZERO
	pressed_buttons.erase(index)

# =============================================================================
# RENDERING
# =============================================================================

func _draw() -> void:
	draw_rect(Rect2(0, 0, VIEW_W, VIEW_H), C_BG)

	if screen_mode == "title":
		UiRenderer.draw_title_menu(self, sprites, save_data, title_selected_idx, elapsed)
		if settings_open:
			UiRenderer.draw_settings(self, _get_settings(), settings_selected_row)
		_draw_screen_fade()
		return

	if screen_mode == "bosses":
		UiRenderer.draw_bosses_screen(self, sprites, save_data, bosses_selected_idx, elapsed)
		if settings_open:
			UiRenderer.draw_settings(self, _get_settings(), settings_selected_row)
		_draw_screen_fade()
		return

	if screen_mode == "transition":
		UiRenderer.draw_shaft_transition(self, transition_target_boss, transition_timer, transition_duration, elapsed)
		return

	if screen_mode == "cutscene" and (cutscene_kind == "plane_escape" or cutscene_kind == "dead_cat_discovery" or cutscene_kind == "story_prologue"):
		UiRenderer.draw_cutscene(self, sprites, cutscene_kind, current_boss_id, cutscene_lines, cutscene_idx, int(cutscene_chars), post_gf_choice, elapsed, victory_summary_text)
		_draw_screen_fade()
		return

	# 1. Draw 640x360 hand-crafted arena backdrop at native 1:1 sharpness
	draw_set_transform(shake_offset * 2.0, 0.0, Vector2.ONE)
	ArenaRenderer.draw_arena_backdrop_hd(self, boss, sprites)

	# 2. Draw world logic layer in 2x transform (320x180 gameplay space -> 640x360)
	draw_set_transform(shake_offset * 2.0, 0.0, Vector2(2.0, 2.0))
	ArenaRenderer.draw_arena_dynamic(self, boss, elapsed)
	ArenaRenderer.draw_veins(self, veins, player_pos, elapsed)
	BossRenderer.draw_hazards_under(self, boss, elapsed)
	BossRenderer.draw_minions_and_decoys(self, boss, elapsed)
	BossRenderer.draw_boss(self, boss, sprites, elapsed)
	BossRenderer.draw_projectiles(self, coal_projectiles, boss.projectiles, elapsed)
	BossRenderer.draw_player(self, sprites, player_pos, attack_direction, move_input, dodge_direction, dodge_timer, perfect_dodge_timer, counter_strike_timer, player_invuln, player_flash, attack_timer, attack_combo, mining, elapsed)
	BossRenderer.draw_impact_rings(self, impact_rings)
	ArenaRenderer.draw_allan_darkness_overlay(self, boss, elapsed)
	_draw_particles()
	if bool(_get_settings()["debug_hitboxes"]):
		_draw_debug_hitboxes()

	# 3. Draw floating combat numbers & UI in native 640x360 HD text space
	draw_set_transform(shake_offset * 2.0, 0.0, Vector2.ONE)
	_draw_floating_texts()
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)

	if screen_mode == "cutscene":
		UiRenderer.draw_cutscene(self, sprites, cutscene_kind, current_boss_id, cutscene_lines, cutscene_idx, int(cutscene_chars), post_gf_choice, elapsed, victory_summary_text)
		_draw_screen_fade()
		return

	var s := _get_settings()
	var ui_state := {
		"boss": boss,
		"sprites": sprites,
		"boss_hp_trail": boss_hp_trail,
		"player_hearts": player_hearts,
		"coal_ammo": coal_ammo,
		"auto_aim": auto_aim,
		"perfect_dodge_count": perfect_dodge_count,
		"counter_strike_timer": counter_strike_timer,
		"mining": mining,
		"mine_progress": mine_progress,
		"mine_time": MINE_TIME,
		"closest_vein": _closest_vein(),
		"message_text": message_text,
		"message_timer": message_timer,
		"combo_label": combo_label,
		"combo_label_timer": combo_label_timer,
		"dodge_cooldown": dodge_cooldown,
		"elapsed": elapsed,
		"joystick_touch": joystick_touch,
		"joystick_origin": joystick_origin,
		"joystick_vector": joystick_vector,
		"coal_touch": coal_touch,
		"coal_aim_vector": coal_aim_vector,
		"pressed_buttons": pressed_buttons,
		"player_pos": player_pos,
		"attack_direction": attack_direction,
		"touch_opacity": float(s["touch_opacity"]),
		"touch_scale": float(s["touch_scale"]),
	}
	UiRenderer.draw_hud(self, ui_state)
	UiRenderer.draw_touch_controls(self, ui_state)

	var fl_mult := float(s["flash_scale"])
	if damage_flash > 0.0 and fl_mult > 0.01:
		draw_rect(Rect2(0, 0, VIEW_W, VIEW_H), Color(0.88, 0.18, 0.18, damage_flash * 0.25 * fl_mult))
	if paused:
		UiRenderer.draw_pause_overlay(self, str(boss.cfg.get("name", "BOSS")))
	if settings_open:
		UiRenderer.draw_settings(self, s, settings_selected_row)
	if death_reset_timer > 0.0:
		draw_rect(Rect2(0, 0, VIEW_W, VIEW_H), Color(0.02, 0.02, 0.04, 0.68))
		UiRenderer._text_centered(self, "CHOKO DOWN", 320.0, 166.0, 24, C_TEXT)
		UiRenderer._text_centered(self, "Loading something questionable...", 320.0, 194.0, 12, C_MUTED)
	if death_menu_active:
		var attempts: Dictionary = save_data.get("attempts", {})
		var bp: Dictionary = save_data.get("best_phase", {})
		UiRenderer.draw_respawn_menu(
			self,
			str(boss.cfg.get("name", "BOSS")),
			int(attempts.get(current_boss_id, 1)),
			int(bp.get(current_boss_id, boss.best_phase_reached)),
			brainrot_caption_index,
			elapsed
		)
	_draw_screen_fade()

func _draw_screen_fade() -> void:
	if screen_fade > 0.01:
		draw_rect(Rect2(0, 0, VIEW_W, VIEW_H), Color(0.02, 0.02, 0.04, clampf(screen_fade, 0.0, 1.0)))

func _draw_debug_hitboxes() -> void:
	draw_arc(player_pos + Vector2(0, -4), 8.5, 0.0, TAU, 16, Color(0.2, 1.0, 0.4, 0.8), 1.0)
	if boss.hp > 0.0:
		draw_arc(boss.pos, boss.get_hitbox_radius(), 0.0, TAU, 20, Color(1.0, 0.25, 0.25, 0.85), 1.0)
	if attack_timer > 0.0:
		draw_arc(player_pos + attack_direction * 22.0, 19.0, 0.0, TAU, 16, Color(1.0, 0.85, 0.2, 0.85), 1.0)

func _draw_particles() -> void:
	for particle in particles:
		var pos: Vector2 = particle["pos"]
		var tint: Color = particle["color"]
		tint.a = clampf(float(particle["life"]) * 2.8, 0.0, 1.0)
		var size := float(particle["size"])
		draw_rect(Rect2(pos.x, pos.y, size, size), tint)

func _draw_floating_texts() -> void:
	var font := ThemeDB.fallback_font
	for item in floating_texts:
		var pos: Vector2 = Vector2(item["pos"]) * 2.0
		var tint: Color = item["color"]
		tint.a = clampf(float(item["life"]) * 1.6, 0.0, 1.0)
		var text_value: String = item["text"]
		var tw := font.get_string_size(text_value, HORIZONTAL_ALIGNMENT_LEFT, -1.0, 12).x
		var draw_p := pos - Vector2(tw * 0.5, 0.0)
		draw_string(font, draw_p + Vector2(1.0, 1.0), text_value, HORIZONTAL_ALIGNMENT_LEFT, -1.0, 12, Color(0.02, 0.02, 0.04, tint.a * 0.85))
		draw_string(font, draw_p, text_value, HORIZONTAL_ALIGNMENT_LEFT, -1.0, 12, tint)
