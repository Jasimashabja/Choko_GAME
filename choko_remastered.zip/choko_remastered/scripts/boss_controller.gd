extends RefCounted

## CHOKO — Phase 4.4: Nightmare Souls-Like Boss AI & Attack Style Overhaul.
## Features:
## - Player velocity tracking & predictive lead-aiming so circling passively gets caught
## - Relentless 2-3 attack combo chains before earned punish recovery windows
## - Anti-Greed Retaliations (3+ melee hits outside stagger provoke a 0.36s glint counter!)
## - Brand-new signature attack styles: Farhan Domino Fuse Line & Cluster Satchel,
##   Allan Double-Helix Spore Vortex & Bramble Wall, John Paul Pinball Wall Blitz &
##   X-Slash Rifts, Aaron Curving Bone Boomerangs & Bone Lance, Grandfather 3-Hit Elderly
##   Cane Combo & Triple Carts, Dead Cat Phantom Cross-Blink Slashes & Triple Chime Rings.

const BossData := preload("res://scripts/boss_data.gd")

const ARENA_MIN := Vector2(22.0, 58.0)
const ARENA_MAX := Vector2(298.0, 142.0)

var id: String = "sentinel"
var difficulty: String = "nightmare"
var cfg: Dictionary = {}
var pos: Vector2 = Vector2(232.0, 104.0)
var vel: Vector2 = Vector2.ZERO
var facing: Vector2 = Vector2.LEFT
var hp: float = 180.0
var max_hp: float = 180.0
var posture: float = 0.0
var max_posture: float = 100.0
var posture_drain: float = 8.0
var posture_hold_timer: float = 0.0
var phase: int = 1
var best_phase_reached: int = 1
var state: String = "idle"
var state_timer: float = 0.75
var state_duration: float = 0.75
var attack_id: String = ""
var attack_damage: int = 1
var attack_step: int = 0
var attack_target: Vector2 = Vector2.ZERO
var attack_dir: Vector2 = Vector2.LEFT
var attack_hit_done: bool = false
var last_attack_id: String = ""
var ultimate_cooldown: float = 7.0

# Souls-like relentless combo pressure & anti-greed counter tracking
var combo_chain_left: int = 1
var greed_hits: int = 0
var greed_decay_timer: float = 0.0
var last_player_vel: Vector2 = Vector2.ZERO
var sub_timer: float = 0.0

var flash: float = 0.0
var hit_flash: float = 0.0
var attack_flash: float = 0.0
var arena_alarm: float = 0.0
var anim_time: float = 0.0
var visible_alpha: float = 1.0
var phase_banner_text: String = ""
var phase_banner_timer: float = 0.0
var boss_quote_text: String = ""
var boss_quote_timer: float = 0.0
var status_tag: String = ""
var status_color: Color = Color("#eee5cf")

var glint_active: bool = false
var glint_emitted: bool = false

# Boss-specific signature states
var wall_side: int = 0
var wall_bounces_left: int = 0
var disassembled: bool = false
var shadow_veiled: bool = false
var vine_spawn_timer: float = 6.5
var steam_cycle_timer: float = 2.6
var bell_tolls_done: int = 0
var chapel_fractured: bool = false

# Active encounter entities & hazards
var projectiles: Array = []
var bombs: Array = []
var ground_hazards: Array = []
var slash_lines: Array = [] # Delayed glowing cut-lines (John Paul X-Slash, Dead Cat Phantom Blink!)
var blight_zones: Array = []
var tripwires: Array = []
var braziers: Array = []
var snuff_vines: Array = []
var steam_vents: Array = []
var minions: Array = []
var bone_shards: Array = []
var rib_walls: Array = []
var mine_carts: Array = []
var pillars: Array = []
var crystals: Array = []
var shaft_beams: Array = []
var decoys: Array = []
var pulse_rings: Array = []
var catacomb_bells: Array = []
var bell_waves: Array = []
var events: Array = []

func setup(boss_id: String, diff_mode: String = "nightmare") -> void:
	id = boss_id
	difficulty = diff_mode
	var is_easy := (difficulty == "easy")
	cfg = BossData.get_boss(boss_id)
	pos = cfg.get("spawn_pos", Vector2(236.0, 102.0))
	vel = Vector2.ZERO
	facing = Vector2.LEFT
	var raw_hp := float(cfg.get("max_hp", 180.0))
	max_hp = roundf(raw_hp * 0.65) if (is_easy and id != "sentinel") else raw_hp
	hp = max_hp
	var raw_pos := float(cfg.get("max_posture", 100.0))
	max_posture = roundf(raw_pos * 0.75) if (is_easy and id != "sentinel") else raw_pos
	posture = 0.0
	posture_drain = float(cfg.get("posture_drain", 7.5)) * (0.50 if is_easy else 1.0)
	boss_quote_text = ""
	boss_quote_timer = 0.0
	posture_hold_timer = 0.0
	phase = 1
	best_phase_reached = 1
	state = "idle"
	state_timer = 0.58 if id != "sentinel" else 1.20
	state_duration = state_timer
	attack_id = ""
	attack_damage = 1
	attack_step = 0
	attack_target = Vector2(72.0, 110.0)
	attack_dir = Vector2.LEFT
	attack_hit_done = false
	last_attack_id = ""
	ultimate_cooldown = 7.0
	combo_chain_left = 1
	greed_hits = 0
	greed_decay_timer = 0.0
	last_player_vel = Vector2.ZERO
	sub_timer = 0.0
	flash = 0.0
	hit_flash = 0.0
	attack_flash = 0.0
	arena_alarm = 0.0
	anim_time = 0.0
	visible_alpha = 1.0
	phase_banner_text = ""
	phase_banner_timer = 0.0
	status_tag = ""
	status_color = Color("#eee5cf")
	glint_active = false
	glint_emitted = false
	wall_side = 0
	wall_bounces_left = 0
	disassembled = false
	shadow_veiled = (id == "allan")
	vine_spawn_timer = 6.2
	steam_cycle_timer = 2.6
	bell_tolls_done = 0
	chapel_fractured = false

	projectiles.clear()
	bombs.clear()
	ground_hazards.clear()
	slash_lines.clear()
	blight_zones.clear()
	tripwires.clear()
	braziers.clear()
	snuff_vines.clear()
	steam_vents.clear()
	minions.clear()
	bone_shards.clear()
	rib_walls.clear()
	mine_carts.clear()
	pillars.clear()
	crystals.clear()
	shaft_beams.clear()
	decoys.clear()
	pulse_rings.clear()
	catacomb_bells.clear()
	bell_waves.clear()
	events.clear()

	if id == "allan":
		var b_positions: Array = cfg.get("braziers", [])
		for i in range(b_positions.size()):
			braziers.append({
				"pos": b_positions[i],
				"lit": (i == 1),
				"glow": 1.0 if i == 1 else 0.0,
			})
		_refresh_allan_veil(false)
	elif id == "john_paul":
		var v_positions: Array = cfg.get("steam_vents", [])
		for i in range(v_positions.size()):
			steam_vents.append({
				"pos": v_positions[i],
				"state": "idle",
				"timer": 0.0,
				"hit_boss": false,
			})
	elif id == "dead_cat":
		var bell_positions: Array = cfg.get("catacomb_bells", [])
		for bp in bell_positions:
			catacomb_bells.append({
				"pos": bp,
				"cooldown": 0.0,
				"ring_anim": 0.0,
			})

func _emit(ev: Dictionary) -> void:
	if difficulty == "easy" and str(ev.get("type", "")) == "hurt_player":
		var amt := int(ev.get("amount", 1))
		if amt >= 3:
			ev["amount"] = 2
		elif amt == 2:
			ev["amount"] = 1
	events.append(ev)

func consume_events() -> Array:
	var out: Array = events.duplicate()
	events.clear()
	return out

func _predict_pos(player_pos: Vector2, lead_s: float) -> Vector2:
	var eff_lead := lead_s * (0.35 if difficulty == "easy" else 1.0)
	var p := player_pos + last_player_vel * eff_lead
	return Vector2(clampf(p.x, 22.0, 298.0), clampf(p.y, 58.0, 142.0))

func get_hitbox_radius() -> float:
	var base := float(cfg.get("hitbox_radius", 14.0))
	if id == "grandfather" and phase >= 2:
		return base + 4.0
	if id == "aaron" and disassembled:
		return base + 3.0
	return base

func is_vulnerable() -> bool:
	return state == "recovery" or state == "staggered" or disassembled

func is_hittable() -> bool:
	if hp <= 0.0 or state == "defeated" or state == "phase_shift":
		return false
	if id == "dead_cat" and visible_alpha < 0.28:
		return false
	return true

func get_lit_brazier_count() -> int:
	var c := 0
	for b in braziers:
		if bool(b.get("lit", false)):
			c += 1
	return c

func get_nearest_unlit_brazier(from_pos: Vector2) -> int:
	var best_idx := -1
	var best_dist := 9999.0
	for i in range(braziers.size()):
		var b: Dictionary = braziers[i]
		if bool(b.get("lit", false)):
			continue
		var d := from_pos.distance_to(Vector2(b["pos"]))
		if d < best_dist:
			best_dist = d
			best_idx = i
	return best_idx

func get_nearest_crystal(from_pos: Vector2) -> int:
	var best_idx := -1
	var best_dist := 9999.0
	for i in range(crystals.size()):
		var c: Dictionary = crystals[i]
		var d := from_pos.distance_to(Vector2(c["pos"]))
		if d < best_dist:
			best_dist = d
			best_idx = i
	return best_idx

func add_posture(amount: float, reason: String = "") -> void:
	if hp <= 0.0 or state == "defeated" or state == "staggered" or state == "phase_shift":
		return
	posture = minf(max_posture, posture + amount)
	posture_hold_timer = 2.0
	if posture >= max_posture:
		posture = 0.0
		_trigger_posture_break(reason)

func _trigger_posture_break(reason: String) -> void:
	greed_hits = 0
	if id == "aaron":
		_trigger_aaron_disassembly()
		return
	var dur := 2.45 if id != "sentinel" else 2.2
	var label := reason if not reason.is_empty() else "POSTURE BROKEN • 1.45X!"
	_enter_stagger(dur, label)
	_emit({"type": "particles", "pos": pos, "color": Color("#ffd18a"), "count": 28})
	_emit({"type": "float_text", "pos": pos + Vector2(0, -26), "text": "POSTURE BREAK!", "color": Color("#ffd18a")})
	_emit({"type": "message", "text": str(cfg.get("name", "BOSS")) + "  •  POSTURE BROKEN! (+2 COAL)"})
	_emit({"type": "grant_coal", "amount": 2})
	_emit({"type": "shake", "amount": 4.0})
	_emit({"type": "hitstop", "duration": 0.09})
	_emit({"type": "haptic", "ms": 30})
	_emit({"type": "sfx", "name": "posture_break"})

func _refresh_allan_veil(allow_overburn: bool) -> void:
	if id != "allan":
		shadow_veiled = false
		return
	var lit := get_lit_brazier_count()
	var was_veiled := shadow_veiled
	shadow_veiled = lit < 2
	if lit >= 3 and allow_overburn:
		blight_zones.clear()
		snuff_vines.clear()
		add_posture(65.0, "SOLAR FLARE OVERBURN!")
		if state != "staggered":
			_enter_stagger(2.7, "SOLAR FLARE • 1.45X!")
		_emit({"type": "message", "text": "ALL 3 BRAZIERS LIT  •  SOLAR FLARE OVERBURN!"})
		_emit({"type": "float_text", "pos": pos + Vector2(0, -28), "text": "SOLAR FLARE!", "color": Color("#ffd18a")})
		_emit({"type": "particles", "pos": pos, "color": Color("#ffd18a"), "count": 32})
		_emit({"type": "shake", "amount": 4.2})
	elif was_veiled and not shadow_veiled and allow_overburn:
		_enter_stagger(2.1, "EXPOSED BY LIGHT!")
		_emit({"type": "message", "text": "BRAZIERS LIT  •  ALLAN EXPOSED!"})
		_emit({"type": "shake", "amount": 3.2})
		_emit({"type": "particles", "pos": pos, "color": Color("#ffd18a"), "count": 24})
		_emit({"type": "float_text", "pos": pos + Vector2(0, -24), "text": "EXPOSED!", "color": Color("#ffd18a")})

func try_ignite_brazier_at(shot_pos: Vector2) -> bool:
	if id != "allan":
		return false
	for i in range(braziers.size()):
		var b: Dictionary = braziers[i]
		if bool(b.get("lit", false)):
			continue
		if shot_pos.distance_to(Vector2(b["pos"])) <= 17.0:
			b["lit"] = true
			b["glow"] = 1.0
			braziers[i] = b
			var bp := Vector2(b["pos"])
			for j in range(blight_zones.size() - 1, -1, -1):
				var bz: Dictionary = blight_zones[j]
				if Vector2(bz["pos"]).distance_to(bp) <= 68.0:
					blight_zones.remove_at(j)
			_emit({"type": "particles", "pos": bp + Vector2(0, -4), "color": Color("#ffd18a"), "count": 18})
			_emit({"type": "float_text", "pos": bp + Vector2(0, -14), "text": "BRAZIER LIT", "color": Color("#ffd18a")})
			_emit({"type": "shake", "amount": 1.8})
			_emit({"type": "haptic", "ms": 14})
			_emit({"type": "sfx", "name": "brazier_light"})
			_refresh_allan_veil(true)
			return true
	return false

func try_hit_interactive(hit_pos: Vector2, hit_radius: float, damage: float, is_melee: bool) -> bool:
	# 1. FARHAN: Pickaxe bats ticking bombs right back into Farhan!
	if is_melee and id == "farhan":
		for i in range(bombs.size()):
			var b: Dictionary = bombs[i]
			if bool(b["exploded"]) or bool(b.get("batted", false)):
				continue
			if Vector2(b["pos"]).distance_to(hit_pos) <= hit_radius + 11.0:
				b["batted"] = true
				b["flight_t"] = float(b["flight_dur"])
				b["fuse"] = maxf(float(b["fuse"]), 0.95)
				var to_boss := (pos - Vector2(b["pos"])).normalized()
				if to_boss.length() < 0.1:
					to_boss = Vector2.RIGHT
				b["bat_vel"] = to_boss * 210.0
				bombs[i] = b
				_emit({"type": "particles", "pos": Vector2(b["pos"]), "color": Color("#c1fff0"), "count": 14})
				_emit({"type": "float_text", "pos": Vector2(b["pos"]) + Vector2(0, -12), "text": "BAT BACK!", "color": Color("#c1fff0")})
				_emit({"type": "shake", "amount": 2.4})
				_emit({"type": "hitstop", "duration": 0.055})
				_emit({"type": "haptic", "ms": 18})
				return true

	# 2. JOHN PAUL: Pickaxe deflects bouncing Spirit Yarn Orbs back at him!
	if is_melee and id == "john_paul":
		for i in range(projectiles.size()):
			var s: Dictionary = projectiles[i]
			if str(s.get("kind", "")) != "yarn_orb" or bool(s.get("deflected", false)):
				continue
			if Vector2(s["pos"]).distance_to(hit_pos) <= hit_radius + 12.0:
				var to_boss := (pos - Vector2(s["pos"])).normalized()
				if to_boss.length() < 0.1:
					to_boss = Vector2.RIGHT
				s["deflected"] = true
				s["vel"] = to_boss * 200.0
				s["color"] = Color("#ffd18a")
				s["life"] = 3.0
				projectiles[i] = s
				_emit({"type": "particles", "pos": Vector2(s["pos"]), "color": Color("#ffd18a"), "count": 14})
				_emit({"type": "float_text", "pos": Vector2(s["pos"]) + Vector2(0, -12), "text": "DEFLECT!", "color": Color("#ffd18a")})
				_emit({"type": "shake", "amount": 2.2})
				_emit({"type": "hitstop", "duration": 0.055})
				_emit({"type": "haptic", "ms": 18})
				return true

	# 3. ALLAN: Chop crawling snuffing white vines!
	for i in range(snuff_vines.size() - 1, -1, -1):
		var sv: Dictionary = snuff_vines[i]
		var sp: Vector2 = sv["pos"]
		if sp.distance_to(hit_pos) <= hit_radius + 9.0:
			snuff_vines.remove_at(i)
			_emit({"type": "particles", "pos": sp, "color": Color("#ffffff"), "count": 12})
			_emit({"type": "float_text", "pos": sp + Vector2(0, -10), "text": "VINE CUT +1 COAL", "color": Color("#ffd18a")})
			_emit({"type": "grant_coal", "amount": 1})
			add_posture(16.0)
			return true

	# 4. AARON: Smash reassembling bone shards!
	for i in range(bone_shards.size() - 1, -1, -1):
		var bs: Dictionary = bone_shards[i]
		var bp: Vector2 = bs["pos"]
		if bp.distance_to(hit_pos) <= hit_radius + 9.0:
			bone_shards.remove_at(i)
			if disassembled:
				state_timer = minf(3.8, state_timer + 0.40)
			_emit({"type": "particles", "pos": bp, "color": Color("#fff8e6"), "count": 10})
			_emit({"type": "float_text", "pos": bp + Vector2(0, -10), "text": "SHARD BROKEN +1", "color": Color("#ffd18a")})
			_emit({"type": "grant_coal", "amount": 1})
			return true

	# 5. AARON: Smash bone minions for +1 COAL
	for i in range(minions.size() - 1, -1, -1):
		var m: Dictionary = minions[i]
		var mp: Vector2 = m["pos"]
		if mp.distance_to(hit_pos) <= hit_radius + float(m.get("radius", 8.0)):
			m["hp"] = float(m["hp"]) - damage
			m["flash"] = 0.14
			_emit({"type": "particles", "pos": mp, "color": Color("#fff8e6"), "count": 10})
			if float(m["hp"]) <= 0.0:
				minions.remove_at(i)
				_emit({"type": "float_text", "pos": mp + Vector2(0, -10), "text": "+1 COAL", "color": Color("#ffd18a")})
				_emit({"type": "grant_coal", "amount": 1})
				_emit({"type": "shake", "amount": 1.5})
			else:
				minions[i] = m
			return true

	# 6. GRANDFATHER: Shatter Coal-Heart Anchor Crystals!
	for i in range(crystals.size() - 1, -1, -1):
		var c: Dictionary = crystals[i]
		var cp: Vector2 = c["pos"]
		if cp.distance_to(hit_pos) <= hit_radius + 11.0:
			c["hp"] = float(c["hp"]) - damage
			c["flash"] = 0.15
			_emit({"type": "particles", "pos": cp, "color": Color("#ffd08a"), "count": 12})
			if float(c["hp"]) <= 0.0:
				crystals.remove_at(i)
				_emit({"type": "particles", "pos": cp, "color": Color("#e86f5c"), "count": 22})
				_emit({"type": "float_text", "pos": cp + Vector2(0, -14), "text": "TETHER BROKEN!", "color": Color("#ffd08a")})
				_emit({"type": "grant_coal", "amount": 2})
				_emit({"type": "shake", "amount": 3.2})
				_emit({"type": "haptic", "ms": 22})
				hp = maxf(1.0, hp - 26.0)
				add_posture(48.0, "TETHER SHATTERED!")
			else:
				crystals[i] = c
			return true

	# 7. DEAD CAT: Ring Tarnished Catacomb Bells!
	if id == "dead_cat":
		for i in range(catacomb_bells.size()):
			var bell: Dictionary = catacomb_bells[i]
			if float(bell["cooldown"]) > 0.0:
				continue
			var bp: Vector2 = bell["pos"]
			if bp.distance_to(hit_pos) <= hit_radius + 12.0:
				bell["cooldown"] = 8.5
				bell["ring_anim"] = 0.75
				catacomb_bells[i] = bell
				bell_waves.append({"center": bp, "radius": 8.0, "max_radius": 240.0, "alpha": 1.0})
				var cleared_decoys := decoys.size()
				decoys.clear()
				visible_alpha = 1.0
				_emit({"type": "particles", "pos": bp, "color": Color("#ffd18a"), "count": 18})
				_emit({"type": "float_text", "pos": bp + Vector2(0, -14), "text": "CHIME RING!", "color": Color("#ffd18a")})
				_emit({"type": "message", "text": "CATACOMB BELL RUNG  •  ECHOES BANISHED!"})
				_emit({"type": "shake", "amount": 2.6})
				_emit({"type": "haptic", "ms": 20})
				_emit({"type": "sfx", "name": "dead_cat_chime"})
				if cleared_decoys > 0 or state == "reposition" or attack_id == "echo_split" or attack_id == "phantom_blink":
					add_posture(42.0, "REVEALED BY CHIME!")
					if state != "staggered":
						_enter_stagger(1.55, "REVEALED BY BELL!")
				else:
					add_posture(22.0)
				return true

	# 8. DEAD CAT: Banish Echo Decoys directly
	for i in range(decoys.size() - 1, -1, -1):
		var d: Dictionary = decoys[i]
		var dp: Vector2 = d["pos"]
		if dp.distance_to(hit_pos) <= hit_radius + 10.0:
			decoys.remove_at(i)
			_emit({"type": "particles", "pos": dp, "color": Color("#9ecae8"), "count": 12})
			_emit({"type": "float_text", "pos": dp + Vector2(0, -12), "text": "ECHO", "color": Color("#9ecae8")})
			return true

	return false

func take_damage(base_amount: float, is_melee: bool, posture_dmg: float = 0.0) -> Dictionary:
	if not is_hittable():
		return {"hit": false, "damage": 0.0, "tag": ""}

	var mult := 1.0
	var tag := ""
	if id == "allan" and shadow_veiled:
		mult = 0.45
		tag = "VEILED"
	elif id == "grandfather" and not crystals.is_empty():
		mult = 0.68
		tag = "TETHERED"
	elif id == "aaron" and disassembled and is_melee:
		mult = 1.55
		tag = "BONE BREAK!"
	elif state == "staggered":
		mult = 1.45
		tag = "RIPOSTE!"
	elif state == "recovery":
		mult = 1.15
		tag = "OPEN!"

	var final_dmg := maxf(1.0, roundf(base_amount * mult))
	hp = maxf(0.0, hp - final_dmg)
	flash = 0.14
	hit_flash = 0.10

	var p_gain := posture_dmg if posture_dmg > 0.0 else (final_dmg * (0.50 if is_melee else 0.28))
	if id == "allan" and shadow_veiled:
		p_gain *= 0.40

	# Track Anti-Greed melee hits outside staggered Riposte windows!
	if difficulty != "easy" and is_melee and id != "sentinel" and state != "staggered" and not disassembled and hp > 0.0:
		greed_hits += 1
		greed_decay_timer = 1.75
		if greed_hits >= 3 and state != "telegraph" and attack_id != "anti_greed_counter":
			greed_hits = 0
			_trigger_anti_greed_retaliation()

	# Dead Cat: striking real silhouette during echo_split telegraph triggers instant counter!
	if id == "dead_cat" and state == "telegraph" and attack_id == "echo_split" and hp > 0.0:
		decoys.clear()
		add_posture(52.0, "REAL FORM COUNTERED!")
		if state != "staggered":
			_enter_stagger(1.75, "REAL FORM COUNTERED!")
		_emit({"type": "float_text", "pos": pos + Vector2(0, -24), "text": "COUNTER!", "color": Color("#e5f6ff")})
	elif hp > 0.0:
		add_posture(p_gain)

	if hp <= 0.0:
		_on_defeated()
		return {"hit": true, "damage": final_dmg, "tag": tag}

	var ratio := hp / max_hp
	var p2 := float(cfg.get("phase2_ratio", 0.66))
	var p3 := float(cfg.get("phase3_ratio", 0.33))
	if phase == 1 and ratio <= p2:
		_trigger_phase_shift(2)
	elif phase == 2 and ratio <= p3:
		_trigger_phase_shift(3)

	return {"hit": true, "damage": final_dmg, "tag": tag}

func _trigger_anti_greed_retaliation() -> void:
	# Punishes reckless melee mashing with a fast, readable 0.36s glint counter-burst!
	attack_id = "anti_greed_counter"
	attack_damage = 1
	attack_hit_done = false
	glint_emitted = false
	vel = Vector2.ZERO
	wall_side = 0
	state = "telegraph"
	state_duration = 0.36
	state_timer = 0.36
	status_tag = "! COUNTER BURST — ROLL !"
	status_color = Color("#ff7b6b")
	_emit({"type": "float_text", "pos": pos + Vector2(0, -26), "text": "COUNTER!", "color": Color("#ff7b6b")})

func _exec_anti_greed_retaliation(player_pos: Vector2) -> void:
	state = "active"
	attack_flash = 0.24
	var away := (pos - player_pos).normalized()
	if away.length() < 0.1:
		away = Vector2.RIGHT
	var to_p := -away

	if id == "farhan":
		# Backstep evade + point-blank flash bomb!
		vel = away * 170.0
		_spawn_bomb(pos, player_pos, 0.20, 0.62, 26.0, 1)
		for ang in [-0.35, 0.0, 0.35]:
			projectiles.append({"pos": pos, "vel": to_p.rotated(float(ang)) * 125.0, "life": 2.0, "radius": 4.5, "damage": 1, "kind": "spark", "color": Color("#ffe0a3")})
		state_duration = 0.24
	elif id == "allan":
		# Point-blank ring of white thorns!
		ground_hazards.append({"kind": "root_spike", "pos": pos, "radius": 34.0, "telegraph": 0.12, "max_telegraph": 0.12, "active": 0.26, "damage": 1, "hit_done": false, "leave_blight": true, "color": Color("#ffffff")})
		for k in range(6):
			var a := float(k) * (TAU / 6.0)
			projectiles.append({"pos": pos, "vel": Vector2.RIGHT.rotated(a) * 85.0, "life": 2.4, "radius": 4.5, "damage": 1, "kind": "white_petal", "color": Color("#ffffff")})
		state_duration = 0.24
	elif id == "john_paul":
		# Feline backflip + 3 razor claw crescents!
		vel = away * 195.0
		for ang in [-0.30, 0.0, 0.30]:
			projectiles.append({"pos": pos, "vel": to_p.rotated(float(ang)) * 145.0, "life": 2.0, "radius": 5.0, "damage": 1, "kind": "spark", "color": Color("#d6fff5")})
		state_duration = 0.22
	elif id == "aaron":
		# Swirling close-range rib-nova!
		for k in range(8):
			var a := float(k) * (TAU / 8.0)
			projectiles.append({"pos": pos, "vel": Vector2.RIGHT.rotated(a) * 100.0, "life": 2.4, "radius": 4.5, "damage": 1, "kind": "bone", "spin": a, "color": Color("#fff8e6")})
		state_duration = 0.26
	elif id == "grandfather":
		# Heavy iron-cane shockwave sweep!
		ground_hazards.append({"kind": "cane_quake", "pos": pos, "radius": 44.0, "telegraph": 0.10, "max_telegraph": 0.10, "active": 0.26, "damage": 1, "hit_done": false, "color": Color("#ffd08a")})
		_emit({"type": "shake", "amount": 3.4})
		state_duration = 0.28
	elif id == "dead_cat":
		# Instant phantom blink behind Choko + rapid slash line!
		var blink_p := Vector2(clampf(player_pos.x - to_p.x * 36.0, 26.0, 294.0), clampf(player_pos.y - to_p.y * 36.0, 60.0, 140.0))
		slash_lines.append({"a": pos, "b": blink_p, "telegraph": 0.26, "max_telegraph": 0.26, "active": 0.20, "damage": 1, "hit_done": false, "color": Color("#e5f6ff")})
		pos = blink_p
		state_duration = 0.24
	else:
		state_duration = 0.20
	state_timer = state_duration

func _trigger_aaron_disassembly() -> void:
	disassembled = true
	greed_hits = 0
	state = "staggered"
	state_timer = 3.1
	state_duration = 3.1
	vel = Vector2.ZERO
	glint_active = false
	status_tag = "DISASSEMBLED • 1.55X PICKAXE!"
	status_color = Color("#ffd18a")
	var shard_origins := [
		Vector2(24.0, 62.0),
		Vector2(296.0, 62.0),
		Vector2(24.0, 140.0),
		Vector2(296.0, 140.0),
		Vector2(160.0, 58.0),
	]
	for so in shard_origins:
		bone_shards.append({"pos": so, "speed": 42.0 + float(phase) * 7.0})
	_emit({"type": "particles", "pos": pos, "color": Color("#fff8e6"), "count": 28})
	_emit({"type": "float_text", "pos": pos + Vector2(0, -26), "text": "SHATTERED!", "color": Color("#ffd18a")})
	_emit({"type": "message", "text": "AARON DISASSEMBLED  •  STRIKE OR BREAK SHARDS!"})
	_emit({"type": "shake", "amount": 3.8})
	_emit({"type": "haptic", "ms": 26})

func _enter_stagger(duration: float, label: String) -> void:
	state = "staggered"
	state_timer = duration
	state_duration = duration
	vel = Vector2.ZERO
	wall_side = 0
	wall_bounces_left = 0
	glint_active = false
	combo_chain_left = 0
	status_tag = label
	status_color = Color("#ffd18a")

func _trigger_phase_shift(new_phase: int) -> void:
	phase = new_phase
	best_phase_reached = maxi(best_phase_reached, phase)
	greed_hits = 0
	if id == "sentinel":
		var p_titles: Array = cfg.get("phase_titles", ["", "", ""])
		if new_phase - 1 < p_titles.size():
			phase_banner_text = str(p_titles[new_phase - 1])
			phase_banner_timer = 1.8
		return

	state = "phase_shift"
	state_timer = 0.85
	state_duration = 0.85
	vel = Vector2.ZERO
	wall_side = 0
	wall_bounces_left = 0
	visible_alpha = 1.0
	glint_active = false
	attack_id = ""
	ground_hazards.clear()
	slash_lines.clear()
	shaft_beams.clear()
	decoys.clear()
	arena_alarm = 0.85

	var titles: Array = cfg.get("phase_titles", ["", "PHASE II", "PHASE III"])
	phase_banner_text = str(titles[clampi(new_phase - 1, 0, titles.size() - 1)])
	phase_banner_timer = 2.4
	var quotes: Array = cfg.get("phase_quotes", ["", "", ""])
	if new_phase - 1 < quotes.size():
		var q := str(quotes[new_phase - 1])
		if not q.is_empty():
			boss_quote_text = q
			boss_quote_timer = 3.4
	status_tag = phase_banner_text
	status_color = cfg.get("accent_hi", Color("#ffd18a"))

	_emit({"type": "particles", "pos": pos, "color": cfg.get("accent_hi", Color("#ffd18a")), "count": 34})
	_emit({"type": "shake", "amount": 4.4})
	_emit({"type": "haptic", "ms": 28})
	_emit({"type": "sfx", "name": "phase_shift"})
	_emit({"type": "message", "text": str(cfg.get("name", "BOSS")) + "  •  " + phase_banner_text})
	_emit({"type": "grant_coal", "amount": 1})

	if id == "allan":
		for i in range(braziers.size()):
			var b: Dictionary = braziers[i]
			if i != 1 or new_phase == 3:
				b["lit"] = false
				b["glow"] = 0.0
			braziers[i] = b
		shadow_veiled = get_lit_brazier_count() < 2
	elif id == "grandfather":
		if new_phase == 2:
			_spawn_coal_crystal(Vector2(66.0, 74.0))
			_emit({"type": "float_text", "pos": pos + Vector2(0, -28), "text": "CORRUPTED ELDER", "color": Color("#e86f5c")})
		elif new_phase == 3:
			chapel_fractured = true
			ultimate_cooldown = 3.5
			_spawn_coal_crystal(Vector2(66.0, 128.0))
			_spawn_coal_crystal(Vector2(254.0, 74.0))
			_emit({"type": "float_text", "pos": pos + Vector2(0, -28), "text": "THE BELL TOLLS!", "color": Color("#ffd08a")})
	elif id == "dead_cat" and new_phase == 3:
		ultimate_cooldown = 3.8

func _spawn_coal_crystal(at: Vector2) -> void:
	if crystals.size() >= 3:
		return
	crystals.append({"pos": at, "hp": 36.0, "max_hp": 36.0, "fire_cd": 1.8, "flash": 0.0})
	_emit({"type": "particles", "pos": at, "color": Color("#ffd08a"), "count": 14})
	_emit({"type": "message", "text": "COAL-HEART CRYSTAL RAISED  •  SHATTER IT!"})

func _on_defeated() -> void:
	state = "defeated"
	state_timer = 0.0
	vel = Vector2.ZERO
	wall_side = 0
	wall_bounces_left = 0
	disassembled = false
	visible_alpha = 1.0
	glint_active = false
	projectiles.clear()
	bombs.clear()
	ground_hazards.clear()
	slash_lines.clear()
	blight_zones.clear()
	tripwires.clear()
	snuff_vines.clear()
	minions.clear()
	bone_shards.clear()
	rib_walls.clear()
	mine_carts.clear()
	pillars.clear()
	crystals.clear()
	shaft_beams.clear()
	decoys.clear()
	pulse_rings.clear()
	bell_waves.clear()
	status_tag = "DEFEATED"
	status_color = Color("#c1fff0")
	_emit({"type": "particles", "pos": pos, "color": cfg.get("accent_hi", Color("#c1fff0")), "count": 48})
	_emit({"type": "shake", "amount": 5.0})
	_emit({"type": "haptic", "ms": 38})
	_emit({"type": "sfx", "name": "boss_defeated"})
	_emit({"type": "boss_defeated"})

func update(delta: float, player_pos: Vector2, player_mining: bool = false, player_vel: Vector2 = Vector2.ZERO) -> void:
	anim_time += delta
	last_player_vel = player_vel
	flash = maxf(0.0, flash - delta)
	hit_flash = maxf(0.0, hit_flash - delta)
	attack_flash = maxf(0.0, attack_flash - delta)
	arena_alarm = maxf(0.0, arena_alarm - delta)
	phase_banner_timer = maxf(0.0, phase_banner_timer - delta)
	boss_quote_timer = maxf(0.0, boss_quote_timer - delta)
	ultimate_cooldown = maxf(0.0, ultimate_cooldown - delta)

	if greed_decay_timer > 0.0:
		greed_decay_timer = maxf(0.0, greed_decay_timer - delta)
		if greed_decay_timer <= 0.0:
			greed_hits = 0

	if hp <= 0.0 or state == "defeated":
		return

	if posture_hold_timer > 0.0:
		posture_hold_timer = maxf(0.0, posture_hold_timer - delta)
	elif posture > 0.0 and state != "staggered":
		posture = maxf(0.0, posture - posture_drain * delta)

	# Anti-greed mining awareness: campaign bosses immediately cut idle/recovery short to punish greedy mining!
	if difficulty != "easy" and player_mining and id != "sentinel":
		if state == "idle" and state_timer > 0.14:
			state_timer = 0.14
		elif state == "recovery" and state_timer > 0.25:
			state_timer = 0.25

	_update_projectiles(delta, player_pos)
	_update_bombs(delta, player_pos)
	_update_tripwires(delta, player_pos)
	_update_blight_zones(delta, player_pos)
	_update_ground_hazards(delta, player_pos)
	_update_slash_lines(delta, player_pos)
	_update_snuff_vines(delta, player_pos)
	_update_steam_vents(delta, player_pos)
	_update_minions(delta, player_pos)
	_update_bone_shards(delta)
	_update_rib_walls(delta, player_pos)
	_update_mine_carts(delta, player_pos)
	_update_pillars(delta, player_pos)
	_update_crystals(delta, player_pos)
	_update_shaft_beams(delta, player_pos)
	_update_decoys(delta, player_pos)
	_update_pulse_rings(delta, player_pos)
	_update_catacomb_bells(delta)

	if state == "phase_shift":
		state_timer -= delta
		if state_timer <= 0.0:
			if id == "aaron":
				_trigger_aaron_disassembly()
			else:
				state = "idle"
				state_timer = 0.26
				state_duration = 0.26
		return

	if state == "staggered":
		state_timer -= delta
		if state_timer <= 0.0:
			disassembled = false
			bone_shards.clear()
			status_tag = ""
			state = "idle"
			state_timer = 0.22
			state_duration = 0.22
		return

	# Handle Anti-Greed Counter Burst uniformly for all bosses
	if attack_id == "anti_greed_counter":
		if state == "telegraph":
			_check_glint_window(0.20)
			state_timer -= delta
			if state_timer <= 0.0:
				glint_active = false
				_exec_anti_greed_retaliation(player_pos)
			return
		elif state == "active":
			pos += vel * delta
			pos.x = clampf(pos.x, ARENA_MIN.x, ARENA_MAX.x)
			pos.y = clampf(pos.y, ARENA_MIN.y, ARENA_MAX.y)
			state_timer -= delta
			if state_timer <= 0.0:
				vel = Vector2.ZERO
				attack_id = ""
				state = "idle"
				state_timer = 0.26
				state_duration = 0.26
				status_tag = ""
			return

	if state == "idle" or state == "reposition":
		var to_p := player_pos - pos
		if to_p.length() > 2.0:
			facing = to_p.normalized()

	var ai_dt := delta * (0.82 if (difficulty == "easy" and state == "telegraph" and id != "sentinel") else 1.0)
	match id:
		"sentinel":
			_ai_sentinel(ai_dt, player_pos)
		"farhan":
			_ai_farhan(ai_dt, player_pos)
		"allan":
			_ai_allan(ai_dt, player_pos)
		"john_paul":
			_ai_john_paul(ai_dt, player_pos)
		"aaron":
			_ai_aaron(ai_dt, player_pos)
		"grandfather":
			_ai_grandfather(ai_dt, player_pos)
		"dead_cat":
			_ai_dead_cat(ai_dt, player_pos)

	if wall_side == 0:
		pos.x = clampf(pos.x, ARENA_MIN.x, ARENA_MAX.x)
		pos.y = clampf(pos.y, ARENA_MIN.y, ARENA_MAX.y)

func _check_glint_window(lead_time: float = 0.17) -> void:
	if state == "telegraph" and state_timer <= lead_time and state_timer > 0.0:
		glint_active = true
		if not glint_emitted:
			glint_emitted = true
			_emit({"type": "particles", "pos": pos + Vector2(0, -14), "color": Color("#ffffff"), "count": 7})
			_emit({"type": "sfx", "name": "boss_glint"})
	else:
		glint_active = false

func _finish_attack_or_chain(recovery_dur: float, recovery_tag: String) -> void:
	# Relentless Souls-like chaining: if chain remains, immediately flow into the next attack!
	if combo_chain_left > 0:
		combo_chain_left -= 1
		vel = Vector2.ZERO
		glint_active = false
		state = "idle"
		state_timer = 0.16 if phase >= 2 else 0.22
		state_duration = state_timer
		status_tag = ""
	else:
		_enter_recovery(recovery_dur, recovery_tag)

func _roll_combo_chain() -> int:
	if difficulty == "easy":
		return 0
	# NIGHTMARE: P1: 1-2 chained attacks | P2: 2 chained attacks | P3: 2-3 relentless chained attacks!
	if phase == 1:
		return 1 if (randi() % 100) < 55 else 0
	if phase == 2:
		return 1
	return 2 if (randi() % 100) < 60 else 1

# =============================================================================
# 0. QUARRY SENTINEL (NON-CAMPAIGN PRACTICE CONSTRUCT — PRESERVED FAIR TRAINING)
# =============================================================================

func _ai_sentinel(delta: float, player_pos: Vector2) -> void:
	phase = 1 if hp > 120.0 else (2 if hp > 60.0 else 3)
	best_phase_reached = maxi(best_phase_reached, phase)
	if state == "telegraph":
		_check_glint_window(0.15)
		state_timer -= delta
		if state_timer <= 0.0:
			glint_active = false
			var origin := pos + Vector2(0, -4)
			var direction := (attack_target - origin).normalized()
			if direction.length() < 0.1:
				direction = Vector2.LEFT
			var spread: Array = [0.0]
			var speed := 78.0
			if phase == 2:
				spread = [-0.24, 0.0, 0.24]
				speed = 86.0
			elif phase == 3:
				spread = [-0.40, -0.20, 0.0, 0.20, 0.40]
				speed = 96.0
			for angle in spread:
				projectiles.append({
					"pos": origin,
					"vel": direction.rotated(float(angle)) * speed,
					"life": 3.2,
					"radius": 5.0,
					"damage": 1,
					"kind": "sentinel",
					"color": Color("#e66a61") if phase == 3 else Color("#77d8d0"),
				})
			_emit({"type": "particles", "pos": origin, "color": Color("#77d8d0"), "count": 10 + phase * 3})
			attack_flash = 0.22
			arena_alarm = 0.24
			state = "idle"
			state_timer = 2.6 if phase == 1 else (2.2 if phase == 2 else 1.85)
			state_duration = state_timer
			status_tag = ""
	else:
		state_timer -= delta
		if state_timer <= 0.0:
			attack_id = "sentinel_volley"
			attack_target = player_pos
			attack_damage = 1
			glint_emitted = false
			state = "telegraph"
			state_duration = 0.88 if phase == 1 else (0.74 if phase == 2 else 0.64)
			state_timer = state_duration
			status_tag = "VOLLEY CHARGING"
			status_color = Color("#e66a61")

# =============================================================================
# 1. FARHAN — HYPER-AGILE RIVAL BOMBER (DOMINO FUSES, CLUSTER SATCHEL, 3-STEP BLITZ)
# =============================================================================

func _ai_farhan(delta: float, player_pos: Vector2) -> void:
	if state == "idle":
		state_timer -= delta
		if state_timer <= 0.0:
			var dist := pos.distance_to(player_pos)
			var choices: Array = []
			if dist < 82.0:
				choices.append("feint_swipe")
				choices.append("bomb_arc")
			else:
				choices.append("bomb_arc")
				choices.append("strafe_toss")
			choices.append("domino_line")
			if phase >= 2:
				choices.append("satchel_blast")
				choices.append("tripwire_shutter")
			if phase >= 3:
				choices.append("carpet_run")
			_start_farhan_attack(_pick_next(choices), player_pos)
	elif state == "reposition":
		pos += vel * delta
		state_timer -= delta
		if state_timer <= 0.0:
			vel = Vector2.ZERO
			state = "idle"
			state_timer = 0.16 if phase < 3 else 0.10
			state_duration = state_timer
	elif state == "telegraph":
		_check_glint_window(0.16)
		state_timer -= delta
		if attack_id == "feint_swipe":
			if state_timer > state_duration * 0.45:
				var perp := Vector2(-attack_dir.y, attack_dir.x)
				pos += perp * 84.0 * delta
			elif state_timer > 0.18:
				attack_dir = (_predict_pos(player_pos, 0.18) - pos).normalized()
				facing = attack_dir
		if state_timer <= 0.0:
			glint_active = false
			_exec_farhan_active(player_pos)
	elif state == "active":
		state_timer -= delta
		if attack_id == "feint_swipe":
			pos += attack_dir * 192.0 * delta
			if not attack_hit_done and pos.distance_to(player_pos) <= 22.0:
				attack_hit_done = true
				_emit({"type": "hurt_player", "amount": 1, "pos": player_pos})
			if state_timer <= 0.0:
				if attack_step == 0:
					# Agile flank follow-up + live trap bomb ahead of Choko!
					attack_step = 1
					attack_dir = (_predict_pos(player_pos, 0.22) - pos).normalized()
					attack_hit_done = false
					state_timer = 0.21
					state_duration = 0.21
					attack_flash = 0.16
					_spawn_bomb(pos, _predict_pos(player_pos, 0.35), 0.26, 0.85, 22.0, 1)
					_emit({"type": "particles", "pos": pos, "color": Color("#ffe0a3"), "count": 9})
				elif attack_step == 1 and phase >= 2:
					# Phase 2/3 backflip grenade + twin spark fan!
					attack_step = 2
					vel = -attack_dir * 135.0
					_spawn_bomb(pos, _predict_pos(player_pos, 0.25), 0.30, 0.78, 24.0, 1)
					for ang in [-0.26, 0.0, 0.26]:
						projectiles.append({"pos": pos, "vel": attack_dir.rotated(float(ang)) * 124.0, "life": 2.4, "radius": 4.5, "damage": 1, "kind": "spark", "color": Color("#ffe0a3")})
					state_timer = 0.22
					state_duration = 0.22
				else:
					vel = Vector2.ZERO
					_finish_attack_or_chain(0.74 if phase == 1 else (0.58 if phase == 2 else 0.48), "OPEN • RELOADING")
		elif attack_id == "carpet_run":
			pos += vel * delta
			if attack_step < 6 and state_timer <= state_duration - float(attack_step) * 0.16:
				attack_step += 1
				var drop_p := Vector2(clampf(pos.x + randf_range(-14, 14), 26, 294), clampf(pos.y + randf_range(-14, 14), 60, 140))
				_spawn_bomb(pos, drop_p, 0.22, 0.80, 23.0, 1)
			if state_timer <= 0.0:
				vel = Vector2.ZERO
				_finish_attack_or_chain(0.82, "OPEN • SATCHEL EMPTY")
		else:
			if state_timer <= 0.0:
				_finish_attack_or_chain(0.76 if attack_id == "satchel_blast" else 0.62, "OPEN • RELOADING")
	elif state == "recovery":
		state_timer -= delta
		if state_timer <= 0.0:
			status_tag = ""
			combo_chain_left = _roll_combo_chain()
			var desired := Vector2(256.0 if player_pos.x < 160.0 else 64.0, clampf(player_pos.y + randf_range(-34, 34), 62.0, 138.0))
			vel = (desired - pos).normalized() * (108.0 + float(phase) * 18.0)
			state = "reposition"
			state_duration = clampf(pos.distance_to(desired) / maxf(1.0, vel.length()), 0.20, 0.56)
			state_timer = state_duration

func _start_farhan_attack(pick: String, player_pos: Vector2) -> void:
	attack_id = pick
	attack_step = 0
	attack_hit_done = false
	glint_emitted = false
	attack_target = _predict_pos(player_pos, 0.25)
	attack_dir = (attack_target - pos).normalized()
	if attack_dir.length() < 0.1:
		attack_dir = Vector2.LEFT
	facing = attack_dir
	state = "telegraph"
	if pick == "feint_swipe":
		attack_damage = 1
		state_duration = 0.54 if phase < 3 else 0.44
		status_tag = "FEINT BLITZ COMBO!"
		status_color = Color("#f0a256")
	elif pick == "bomb_arc":
		attack_damage = 1
		state_duration = 0.46
		status_tag = "PREDICTIVE BOMBS • BAT BACK!"
		status_color = Color("#f0a256")
	elif pick == "domino_line":
		attack_damage = 1
		state_duration = 0.52
		status_tag = "DOMINO FUSE CHAIN!"
		status_color = Color("#ffd18a")
	elif pick == "strafe_toss":
		attack_damage = 1
		state_duration = 0.44
		status_tag = "CROSSFIRE BOMBS + SPARKS"
		status_color = Color("#f0a256")
	elif pick == "tripwire_shutter":
		attack_damage = 1
		state_duration = 0.52
		status_tag = "INTERSECTING TRIPWIRES!"
		status_color = Color("#ffd18a")
	elif pick == "satchel_blast":
		attack_damage = 2
		state_duration = 0.78
		status_tag = "!! 2-HEART CLUSTER SATCHEL !!"
		status_color = Color("#e66a61")
		_emit({"type": "float_text", "pos": pos + Vector2(0, -24), "text": "2-HEART CLUSTER!", "color": Color("#e66a61")})
	elif pick == "carpet_run":
		attack_damage = 1
		state_duration = 0.52
		status_tag = "DEPOT CARPET BLITZ"
		status_color = Color("#f0a256")
	state_timer = state_duration

func _exec_farhan_active(player_pos: Vector2) -> void:
	state = "active"
	attack_flash = 0.22
	arena_alarm = 0.28
	var lead := _predict_pos(player_pos, 0.30)
	if attack_id == "feint_swipe":
		attack_dir = (_predict_pos(player_pos, 0.16) - pos).normalized()
		state_duration = 0.22
		state_timer = 0.22
		_emit({"type": "particles", "pos": pos, "color": Color("#ffe0a3"), "count": 10})
	elif attack_id == "bomb_arc":
		var count := 3 if phase == 1 else (4 if phase == 2 else 5)
		for i in range(count):
			var offset := Vector2(float(i - (count - 1) * 0.5) * 30.0, randf_range(-16.0, 16.0))
			var target := Vector2(clampf(lead.x + offset.x, 28.0, 292.0), clampf(lead.y + offset.y, 60.0, 140.0))
			_spawn_bomb(pos, target, 0.32 + float(i) * 0.06, 0.92, 23.0, 1)
		state_duration = 0.25
		state_timer = 0.25
	elif attack_id == "domino_line":
		# 5-bomb rapid chain explosion line sweeping straight across Choko's path!
		var line_dir := (lead - pos).normalized()
		if line_dir.length() < 0.1:
			line_dir = Vector2.LEFT
		for i in range(5):
			var target := pos + line_dir * (34.0 + float(i) * 32.0)
			target.x = clampf(target.x, 26.0, 294.0)
			target.y = clampf(target.y, 60.0, 140.0)
			_spawn_bomb(pos, target, 0.24 + float(i) * 0.07, 0.64 + float(i) * 0.14, 24.0, 1)
		state_duration = 0.28
		state_timer = 0.28
	elif attack_id == "strafe_toss":
		var perp := Vector2(-attack_dir.y, attack_dir.x)
		_spawn_bomb(pos, Vector2(clampf(lead.x + perp.x * 26.0, 28.0, 292.0), clampf(lead.y + perp.y * 26.0, 60.0, 140.0)), 0.30, 0.88, 22.0, 1)
		_spawn_bomb(pos, Vector2(clampf(lead.x - perp.x * 26.0, 28.0, 292.0), clampf(lead.y - perp.y * 26.0, 60.0, 140.0)), 0.36, 0.88, 22.0, 1)
		var fan: Array = [-0.24, 0.0, 0.24] if phase < 3 else [-0.36, -0.18, 0.0, 0.18, 0.36]
		for ang in fan:
			projectiles.append({
				"pos": pos + Vector2(0, -4),
				"vel": attack_dir.rotated(float(ang)) * (116.0 + float(phase) * 10.0),
				"life": 2.6,
				"radius": 4.5,
				"damage": 1,
				"kind": "spark",
				"color": Color("#ffe0a3"),
			})
		state_duration = 0.25
		state_timer = 0.25
	elif attack_id == "tripwire_shutter":
		var wy := clampf(lead.y, 64.0, 136.0)
		var wx := clampf(lead.x, 38.0, 282.0)
		tripwires.append({"a": Vector2(18.0, wy), "b": Vector2(302.0, wy), "arm_t": 0.45, "life": 4.5, "triggered": false})
		if phase >= 2:
			tripwires.append({"a": Vector2(wx, 54.0), "b": Vector2(wx, 146.0), "arm_t": 0.58, "life": 4.5, "triggered": false})
		state_duration = 0.26
		state_timer = 0.26
	elif attack_id == "satchel_blast":
		_spawn_bomb(pos, Vector2(clampf(lead.x, 40.0, 280.0), clampf(lead.y, 64.0, 136.0)), 0.38, 1.05, 36.0, 2, true)
		state_duration = 0.32
		state_timer = 0.32
	elif attack_id == "carpet_run":
		var dest := Vector2(40.0 if pos.x > 160.0 else 280.0, clampf(player_pos.y, 66.0, 134.0))
		vel = (dest - pos).normalized() * 190.0
		state_duration = 0.92
		state_timer = 0.92

func _spawn_bomb(from_pos: Vector2, to_pos: Vector2, flight_dur: float, fuse_dur: float, radius: float, damage: int, cluster: bool = false) -> void:
	bombs.append({
		"pos": from_pos,
		"start_pos": from_pos,
		"target_pos": to_pos,
		"flight_t": 0.0,
		"flight_dur": flight_dur,
		"fuse": fuse_dur,
		"max_fuse": fuse_dur,
		"radius": radius,
		"damage": damage,
		"cluster": cluster,
		"exploded": false,
		"blast_flash": 0.0,
		"batted": false,
		"bat_vel": Vector2.ZERO,
	})

# =============================================================================
# 2. ALLAN — RELENTLESS DARK FLORA ARCHITECT (HELIX VORTEX, BRAMBLE WALL, TRIPLE CLEAVE)
# =============================================================================

func _ai_allan(delta: float, player_pos: Vector2) -> void:
	if get_lit_brazier_count() > 0 and snuff_vines.size() < (1 if phase == 1 else 2):
		vine_spawn_timer -= delta
		if vine_spawn_timer <= 0.0:
			vine_spawn_timer = 8.2 if phase == 1 else (5.8 if phase == 2 else 4.5)
			var spawned := 0
			for i in range(braziers.size()):
				var b: Dictionary = braziers[i]
				if bool(b.get("lit", false)):
					snuff_vines.append({
						"pos": pos,
						"target_idx": i,
						"speed": 34.0 + float(phase) * 7.0,
					})
					spawned += 1
					if spawned >= (1 if phase == 1 else 2):
						break
			if spawned > 0:
				_emit({"type": "message", "text": "WHITE VINES CRAWLING TO BRAZIERS  •  CHOP THEM!"})

	if state == "idle":
		status_tag = "SHADOW VEIL (45% DMG) • LIGHT BRAZIERS" if shadow_veiled else ""
		status_color = Color("#9ca6b8")
		state_timer -= delta
		if state_timer <= 0.0:
			var choices: Array = ["root_line", "spore_vortex", "bramble_wall"]
			if phase >= 2:
				choices.append("thorn_sweep")
				choices.append("root_cage")
			if phase >= 3:
				choices.append("cathedral_overgrowth")
			_start_allan_attack(_pick_next(choices), player_pos)
	elif state == "reposition":
		pos += vel * delta
		state_timer -= delta
		if state_timer <= 0.0:
			vel = Vector2.ZERO
			state = "idle"
			state_timer = 0.24 if phase < 3 else 0.16
			state_duration = state_timer
	elif state == "telegraph":
		_check_glint_window(0.16)
		state_timer -= delta
		if state_timer <= 0.0:
			glint_active = false
			_exec_allan_active(player_pos)
	elif state == "active":
		state_timer -= delta
		if attack_id == "spore_vortex":
			# 3 rapid staggered counter-rotating white petal spirals!
			sub_timer -= delta
			if sub_timer <= 0.0 and attack_step < 3:
				sub_timer = 0.26
				attack_step += 1
				var petals := 8 + phase * 2
				var spin_dir := 1.0 if attack_step % 2 == 1 else -1.0
				var base_ang := anim_time * 1.4 * spin_dir + float(attack_step) * 0.28
				var spd := 72.0 + float(phase) * 10.0
				for i in range(petals):
					var ang := base_ang + TAU * float(i) / float(petals)
					projectiles.append({
						"pos": pos + Vector2(0, -4),
						"vel": Vector2.RIGHT.rotated(ang) * spd,
						"life": 3.4,
						"radius": 4.5,
						"damage": 1,
						"kind": "white_petal",
						"color": Color("#ffffff") if attack_step % 2 == 1 else Color("#cfe0eb"),
					})
				_emit({"type": "particles", "pos": pos, "color": Color("#ffffff"), "count": 12})
		elif attack_id == "thorn_sweep" and not attack_hit_done:
			var to_p := player_pos - pos
			if to_p.length() <= 72.0 and (attack_step == 2 or to_p.normalized().dot(attack_dir) >= 0.10):
				attack_hit_done = true
				_emit({"type": "hurt_player", "amount": 2, "pos": player_pos})
		if state_timer <= 0.0:
			if attack_id == "thorn_sweep" and attack_step < (phase - 1):
				# P2 chains reverse sweep; P3 chains 3rd 360-degree pale briar nova!
				attack_step += 1
				attack_hit_done = false
				attack_dir = (_predict_pos(player_pos, 0.14) - pos).normalized()
				facing = attack_dir
				glint_emitted = false
				state = "telegraph"
				state_duration = 0.44 if attack_step == 1 else 0.50
				state_timer = state_duration
				status_tag = "!! 360° 2-HEART BRIAR NOVA !!" if attack_step == 2 else "!! REVERSE 2-HEART LASH !!"
			else:
				_finish_attack_or_chain(0.84 if attack_id == "thorn_sweep" else 0.64, "OPEN • ROOTS RETRACTING")
	elif state == "recovery":
		state_timer -= delta
		if state_timer <= 0.0:
			status_tag = ""
			combo_chain_left = _roll_combo_chain()
			var desired := Vector2(randf_range(58.0, 262.0), randf_range(64.0, 130.0))
			if desired.distance_to(player_pos) < 55.0:
				desired.x = 256.0 if player_pos.x < 160.0 else 64.0
			vel = (desired - pos).normalized() * (82.0 + float(phase) * 14.0)
			state = "reposition"
			state_duration = clampf(pos.distance_to(desired) / maxf(1.0, vel.length()), 0.25, 0.72)
			state_timer = state_duration

func _start_allan_attack(pick: String, player_pos: Vector2) -> void:
	attack_id = pick
	attack_step = 0
	sub_timer = 0.0
	attack_hit_done = false
	glint_emitted = false
	attack_target = _predict_pos(player_pos, 0.22)
	attack_dir = (attack_target - pos).normalized()
	if attack_dir.length() < 0.1:
		attack_dir = Vector2.LEFT
	facing = attack_dir
	state = "telegraph"
	if pick == "root_line":
		attack_damage = 1
		state_duration = 0.50
		status_tag = "PREDICTIVE WHITE ROOTS"
		status_color = Color("#e8eef2")
	elif pick == "spore_vortex":
		attack_damage = 1
		state_duration = 0.54
		status_tag = "DOUBLE-HELIX SPORE VORTEX!"
		status_color = Color("#ffffff")
	elif pick == "bramble_wall":
		attack_damage = 1
		state_duration = 0.58
		status_tag = "SWEEPING BRAMBLE WALL!"
		status_color = Color("#ffffff")
	elif pick == "root_cage":
		attack_damage = 1
		state_duration = 0.58
		status_tag = "WHITE ROOT CAGE + PETALS!"
		status_color = Color("#ffffff")
	elif pick == "thorn_sweep":
		attack_damage = 2
		state_duration = 0.84
		status_tag = "!! 2-HEART THORN CLEAVE !!"
		status_color = Color("#e66a61")
		_emit({"type": "float_text", "pos": pos + Vector2(0, -24), "text": "2-HEART CLEAVE!", "color": Color("#e66a61")})
	elif pick == "cathedral_overgrowth":
		attack_damage = 1
		state_duration = 0.64
		status_tag = "CATHEDRAL OVERGROWTH!"
		status_color = Color("#ffffff")
	state_timer = state_duration

func _exec_allan_active(player_pos: Vector2) -> void:
	state = "active"
	attack_flash = 0.25
	var lead := _predict_pos(player_pos, 0.26)
	if attack_id == "root_line":
		# Twin converging root lines (direct + predictive lead!)
		for lane in [0, 1]:
			var tgt := lead if lane == 0 else player_pos
			var dir := (tgt - pos).normalized()
			if dir.length() < 0.1:
				dir = Vector2.LEFT
			var angle_off := 0.0 if lane == 0 else (0.24 if phase >= 2 else 0.0)
			if lane == 1 and phase == 1:
				continue
			for i in range(6 + phase):
				var p := pos + dir.rotated(angle_off) * (20.0 + float(i) * 23.0)
				p.x = clampf(p.x, 22.0, 298.0)
				p.y = clampf(p.y, 58.0, 142.0)
				ground_hazards.append({
					"kind": "root_spike", "pos": p, "radius": 13.0,
					"telegraph": 0.40 + float(i) * 0.09, "max_telegraph": 0.40 + float(i) * 0.09,
					"active": 0.34, "damage": 1, "hit_done": false, "leave_blight": (i % 2 == 1),
					"color": Color("#edf4f7"),
				})
		state_duration = 0.32
		state_timer = 0.32
	elif attack_id == "spore_vortex":
		sub_timer = 0.0
		state_duration = 0.85
		state_timer = 0.85
	elif attack_id == "bramble_wall":
		# Vertical sweeping line of white roots marching across the arena with one narrow escape gap!
		var from_left := pos.x < 160.0
		var gap_row := randi() % 4
		for step_x in range(4):
			var wx := (48.0 + float(step_x) * 68.0) if from_left else (272.0 - float(step_x) * 68.0)
			for row in range(4):
				if row == gap_row:
					continue
				var wy := 64.0 + float(row) * 25.0
				ground_hazards.append({
					"kind": "root_spike", "pos": Vector2(wx, wy), "radius": 14.0,
					"telegraph": 0.48 + float(step_x) * 0.22, "max_telegraph": 0.48 + float(step_x) * 0.22,
					"active": 0.32, "damage": 1, "hit_done": false, "leave_blight": (step_x == 2 and row == 1),
					"color": Color("#ffffff"),
				})
			gap_row = (gap_row + 1) % 4
		state_duration = 0.42
		state_timer = 0.42
	elif attack_id == "root_cage":
		var gap_idx := randi() % 7
		for i in range(7):
			if i == gap_idx:
				continue
			var ang := float(i) * (TAU / 7.0)
			var p := lead + Vector2.RIGHT.rotated(ang) * 28.0
			p.x = clampf(p.x, 22.0, 298.0)
			p.y = clampf(p.y, 58.0, 142.0)
			ground_hazards.append({
				"kind": "root_spike", "pos": p, "radius": 13.0,
				"telegraph": 0.56, "max_telegraph": 0.56, "active": 0.38,
				"damage": 1, "hit_done": false, "leave_blight": true, "color": Color("#ffffff"),
			})
		# Layer an aimed petal spread forcing movement through the cage gap!
		var d := (lead - pos).normalized()
		for ang in [-0.20, 0.0, 0.20]:
			projectiles.append({"pos": pos, "vel": d.rotated(float(ang)) * 88.0, "life": 3.0, "radius": 4.5, "damage": 1, "kind": "white_petal", "color": Color("#ffffff")})
		state_duration = 0.35
		state_timer = 0.35
	elif attack_id == "thorn_sweep":
		_emit({"type": "particles", "pos": pos + attack_dir * 28.0, "color": Color("#ffffff"), "count": 22})
		_emit({"type": "shake", "amount": 3.4})
		state_duration = 0.24
		state_timer = 0.24
	elif attack_id == "cathedral_overgrowth":
		for i in range(7):
			var ang := float(i) * (TAU / 7.0) + anim_time
			var p := lead + Vector2.RIGHT.rotated(ang) * 32.0
			p.x = clampf(p.x, 24.0, 296.0)
			p.y = clampf(p.y, 60.0, 140.0)
			ground_hazards.append({
				"kind": "root_spike", "pos": p, "radius": 14.0,
				"telegraph": 0.58, "max_telegraph": 0.58, "active": 0.36,
				"damage": 1, "hit_done": false, "leave_blight": (i % 2 == 0), "color": Color("#ffffff"),
			})
		state_duration = 0.36
		state_timer = 0.36

# =============================================================================
# 3. JOHN PAUL — APEX FELINE PREDATOR (PINBALL WALL BLITZ, X-SLASH RIFTS, MULTI-ORBS)
# =============================================================================

func _ai_john_paul(delta: float, player_pos: Vector2) -> void:
	steam_cycle_timer -= delta
	if steam_cycle_timer <= 0.0 and not steam_vents.is_empty():
		steam_cycle_timer = 3.6 if phase == 1 else (2.7 if phase == 2 else 2.1)
		var count := 1 if phase == 1 else 2
		for _k in range(count):
			var idx := randi() % steam_vents.size()
			var sv: Dictionary = steam_vents[idx]
			if str(sv["state"]) == "idle":
				sv["state"] = "hiss"
				sv["timer"] = 0.90
				sv["hit_boss"] = false
				steam_vents[idx] = sv

	if state == "idle":
		state_timer -= delta
		if state_timer <= 0.0:
			var dist := pos.distance_to(player_pos)
			var choices: Array = ["wall_pounce", "x_slash_ambush", "yarn_orb"]
			if dist < 96.0:
				choices.append("claw_flurry")
			if phase >= 2:
				choices.append("predator_pounce")
			_start_jp_attack(_pick_next(choices), player_pos)
	elif state == "reposition":
		pos += vel * delta
		state_timer -= delta
		if state_timer <= 0.0:
			vel = Vector2.ZERO
			if (attack_id == "wall_pounce" or attack_id == "predator_pounce") and wall_bounces_left > 0:
				# Fire a sharp wall-kick claw crescent toward Choko on EVERY wall bounce!
				var kick_dir := (_predict_pos(player_pos, 0.22) - pos).normalized()
				projectiles.append({"pos": pos, "vel": kick_dir * (118.0 + float(phase) * 12.0), "life": 2.6, "radius": 5.0, "damage": 1, "kind": "spark", "color": Color("#8ce0cf")})
				wall_bounces_left -= 1
				_pick_jp_wall_perch(player_pos)
				return
			if attack_id == "wall_pounce" or attack_id == "predator_pounce":
				attack_target = _predict_pos(player_pos, 0.20)
				attack_dir = (attack_target - pos).normalized()
				if attack_dir.length() < 0.1:
					attack_dir = Vector2.LEFT
				facing = attack_dir
				glint_emitted = false
				state = "telegraph"
				state_duration = 0.54 if attack_id == "wall_pounce" else 0.78
				state_timer = state_duration
				if attack_id == "predator_pounce":
					status_tag = "!! 2-HEART PREDATOR POUNCE !!"
					status_color = Color("#e66a61")
					_emit({"type": "float_text", "pos": pos + Vector2(0, -18), "text": "2-HEART POUNCE!", "color": Color("#e66a61")})
				else:
					status_tag = "WALL POUNCE LOCKED"
					status_color = Color("#8ce0cf")
			else:
				state = "idle"
				state_timer = 0.16
				state_duration = 0.16
	elif state == "telegraph":
		_check_glint_window(0.16)
		state_timer -= delta
		if (attack_id == "wall_pounce" or attack_id == "predator_pounce" or attack_id == "x_slash_ambush") and state_timer > 0.24:
			attack_target = _predict_pos(player_pos, 0.18)
			attack_dir = (attack_target - pos).normalized()
			facing = attack_dir
		if state_timer <= 0.0:
			glint_active = false
			_exec_jp_active(player_pos)
	elif state == "active":
		state_timer -= delta
		if attack_id == "wall_pounce" or attack_id == "predator_pounce":
			var spd := 260.0 if attack_id == "wall_pounce" else 295.0
			pos += attack_dir * spd * delta
			if not attack_hit_done and pos.distance_to(player_pos) <= 18.0:
				attack_hit_done = true
				_emit({"type": "hurt_player", "amount": attack_damage, "pos": player_pos})
			var hit_edge := pos.x <= 24.0 or pos.x >= 296.0 or pos.y <= 58.0 or pos.y >= 142.0
			if state_timer <= 0.0 or (hit_edge and state_timer < state_duration - 0.12):
				wall_side = 0
				if attack_id == "predator_pounce" and attack_step < (1 if phase == 2 else 2):
					attack_step += 1
					attack_hit_done = false
					glint_emitted = false
					attack_target = _predict_pos(player_pos, 0.18)
					attack_dir = (attack_target - pos).normalized()
					state = "telegraph"
					state_duration = 0.46 if phase == 2 else 0.38
					state_timer = state_duration
					status_tag = "!! CHAINED PREDATOR POUNCE !!"
				else:
					_emit({"type": "particles", "pos": pos + Vector2(0, 4), "color": Color("#8ce0cf"), "count": 12})
					_emit({"type": "shake", "amount": 2.4})
					_finish_attack_or_chain(1.05 if not attack_hit_done else 0.65, "CLAWS STUCK • PUNISH!")
		elif attack_id == "x_slash_ambush":
			var start_p := pos
			pos += attack_dir * 310.0 * delta
			if not attack_hit_done and pos.distance_to(player_pos) <= 18.0:
				attack_hit_done = true
				_emit({"type": "hurt_player", "amount": 1, "pos": player_pos})
			if state_timer <= 0.0:
				# Leave a glowing delayed Claw-Rift slash line along the entire dash path!
				slash_lines.append({"a": attack_target, "b": pos, "telegraph": 0.42, "max_telegraph": 0.42, "active": 0.22, "damage": 1, "hit_done": false, "color": Color("#8ce0cf")})
				if attack_step < (1 if phase >= 2 else 0):
					attack_step += 1
					attack_hit_done = false
					attack_target = pos
					attack_dir = (_predict_pos(player_pos, 0.16) - pos).normalized()
					facing = attack_dir
					glint_emitted = false
					state = "telegraph"
					state_duration = 0.38
					state_timer = 0.38
					status_tag = "REVERSE X-SLASH!"
				else:
					_finish_attack_or_chain(0.85, "OPEN • CLAWS COOLING")
		elif attack_id == "claw_flurry":
			pos += attack_dir * 148.0 * delta
			if not attack_hit_done and pos.distance_to(player_pos) <= 21.0:
				attack_hit_done = true
				_emit({"type": "hurt_player", "amount": 1, "pos": player_pos})
			if state_timer <= 0.0:
				if attack_step < (2 if phase == 1 else 3):
					attack_step += 1
					attack_hit_done = false
					attack_dir = (_predict_pos(player_pos, 0.12) - pos).normalized()
					facing = attack_dir
					if attack_step == 2:
						# Deceptive 3rd-hit roll-catch delay!
						glint_emitted = false
						state = "telegraph"
						state_duration = 0.36
						state_timer = 0.36
						status_tag = "DELAYED FINISHER CLAW!"
					else:
						state_timer = 0.16
						state_duration = 0.16
						attack_flash = 0.14
						_emit({"type": "particles", "pos": pos + attack_dir * 12.0, "color": Color("#d6fff5"), "count": 8})
				else:
					_finish_attack_or_chain(0.82, "OPEN • CATCHING BREATH")
		else:
			if state_timer <= 0.0:
				_finish_attack_or_chain(0.62, "OPEN")
	elif state == "recovery":
		state_timer -= delta
		if state_timer <= 0.0:
			status_tag = ""
			combo_chain_left = _roll_combo_chain()
			state = "idle"
			state_timer = 0.22 if phase < 3 else 0.12
			state_duration = state_timer

func _pick_jp_wall_perch(player_pos: Vector2) -> void:
	var choices := [1, 2, 3]
	choices.erase(wall_side)
	var next_side: int = choices[randi() % choices.size()]
	wall_side = next_side
	var dest := Vector2(18.0, clampf(player_pos.y + randf_range(-20, 20), 64.0, 134.0))
	if next_side == 2:
		dest = Vector2(302.0, clampf(player_pos.y + randf_range(-20, 20), 64.0, 134.0))
	elif next_side == 3:
		dest = Vector2(clampf(player_pos.x + randf_range(-50, 50), 48.0, 272.0), 54.0)
	vel = (dest - pos).normalized() * 245.0
	state = "reposition"
	state_duration = clampf(pos.distance_to(dest) / 245.0, 0.14, 0.48)
	state_timer = state_duration
	_emit({"type": "particles", "pos": pos, "color": Color("#8ce0cf"), "count": 7})

func _start_jp_attack(pick: String, player_pos: Vector2) -> void:
	attack_id = pick
	attack_step = 0
	attack_hit_done = false
	glint_emitted = false
	attack_damage = 2 if pick == "predator_pounce" else 1
	if pick == "wall_pounce" or pick == "predator_pounce":
		wall_bounces_left = 1 if phase == 1 else (2 if phase == 2 else 3)
		_pick_jp_wall_perch(player_pos)
		status_tag = "PINBALL WALL BLITZ!"
		status_color = Color("#8ce0cf")
	elif pick == "x_slash_ambush":
		wall_side = 0
		attack_target = pos
		attack_dir = (_predict_pos(player_pos, 0.18) - pos).normalized()
		facing = attack_dir
		state = "telegraph"
		state_duration = 0.50
		state_timer = state_duration
		status_tag = "X-SLASH CLAW RIFT!"
		status_color = Color("#d6fff5")
	elif pick == "claw_flurry":
		wall_side = 0
		attack_dir = (player_pos - pos).normalized()
		facing = attack_dir
		state = "telegraph"
		state_duration = 0.44
		state_timer = state_duration
		status_tag = "4-HIT CLAW FLURRY"
		status_color = Color("#8ce0cf")
	elif pick == "yarn_orb":
		wall_side = 0
		attack_dir = (_predict_pos(player_pos, 0.24) - pos).normalized()
		facing = attack_dir
		state = "telegraph"
		state_duration = 0.48
		state_timer = state_duration
		status_tag = "SPIRIT YARN ORBS • DEFLECT!"
		status_color = Color("#d6fff5")

func _exec_jp_active(player_pos: Vector2) -> void:
	state = "active"
	attack_flash = 0.22
	if attack_id == "wall_pounce" or attack_id == "predator_pounce":
		wall_side = 0
		state_duration = 0.52
		state_timer = 0.52
		_emit({"type": "particles", "pos": pos, "color": Color("#d6fff5"), "count": 14})
		_emit({"type": "shake", "amount": 2.2})
	elif attack_id == "x_slash_ambush":
		attack_target = pos # store dash origin so we draw rift from origin -> end!
		state_duration = 0.34
		state_timer = 0.34
		_emit({"type": "particles", "pos": pos, "color": Color("#d6fff5"), "count": 14})
	elif attack_id == "claw_flurry":
		attack_dir = (_predict_pos(player_pos, 0.12) - pos).normalized()
		state_duration = 0.18
		state_timer = 0.18
	elif attack_id == "yarn_orb":
		var count := 1 if phase == 1 else (2 if phase == 2 else 3)
		for i in range(count):
			var spread := float(i - (count - 1) * 0.5) * 0.34
			var dir := attack_dir.rotated(spread)
			projectiles.append({
				"pos": pos + Vector2(0, -4),
				"vel": dir * (112.0 + float(phase) * 12.0),
				"life": 5.8,
				"radius": 6.0,
				"damage": 1,
				"kind": "yarn_orb",
				"bounces": 5 + phase,
				"deflected": false,
				"color": Color("#8ce0cf"),
			})
		state_duration = 0.22
		state_timer = 0.22

# =============================================================================
# 4. AARON — FOSSIL CRYPT NECROMANCER (BONE BOOMERANGS, TWIN RIB WAVES, STALACTITES)
# =============================================================================

func _ai_aaron(delta: float, player_pos: Vector2) -> void:
	if state == "idle":
		state_timer -= delta
		if state_timer <= 0.0:
			var choices: Array = ["bone_boomerang", "bone_volley", "rib_barriers"]
			if phase >= 2:
				choices.append("stalactite_drop")
			if minions.size() < (2 if phase < 3 else 3):
				choices.append("summon_minions")
			if phase >= 2:
				choices.append("rib_crush")
			_start_aaron_attack(_pick_next(choices), player_pos)
	elif state == "reposition":
		pos += vel * delta
		state_timer -= delta
		if state_timer <= 0.0:
			vel = Vector2.ZERO
			state = "idle"
			state_timer = 0.22 if phase < 3 else 0.14
			state_duration = state_timer
	elif state == "telegraph":
		_check_glint_window(0.16)
		state_timer -= delta
		if state_timer <= 0.0:
			glint_active = false
			_exec_aaron_active(player_pos)
	elif state == "active":
		state_timer -= delta
		if state_timer <= 0.0:
			_finish_attack_or_chain(0.84 if attack_id == "rib_crush" else 0.64, "OPEN • RATTLING")
	elif state == "recovery":
		state_timer -= delta
		if state_timer <= 0.0:
			status_tag = ""
			combo_chain_left = _roll_combo_chain()
			var desired := Vector2(246.0 if player_pos.x < 160.0 else 74.0, clampf(player_pos.y + randf_range(-24, 24), 64.0, 136.0))
			vel = (desired - pos).normalized() * (74.0 + float(phase) * 14.0)
			state = "reposition"
			state_duration = clampf(pos.distance_to(desired) / maxf(1.0, vel.length()), 0.25, 0.72)
			state_timer = state_duration

func _start_aaron_attack(pick: String, player_pos: Vector2) -> void:
	attack_id = pick
	glint_emitted = false
	attack_target = _predict_pos(player_pos, 0.24)
	attack_dir = (attack_target - pos).normalized()
	if attack_dir.length() < 0.1:
		attack_dir = Vector2.LEFT
	facing = attack_dir
	state = "telegraph"
	if pick == "bone_boomerang":
		attack_damage = 1
		state_duration = 0.50
		status_tag = "CURVING BONE BOOMERANGS!"
		status_color = Color("#fff8e6")
	elif pick == "bone_volley":
		attack_damage = 1
		state_duration = 0.48
		status_tag = "CROSS BONE BARRAGE"
		status_color = Color("#ded5be")
	elif pick == "rib_barriers":
		attack_damage = 1
		state_duration = 0.56
		status_tag = "TWIN CLOSING RIB WALLS!"
		status_color = Color("#fff8e6")
	elif pick == "stalactite_drop":
		attack_damage = 1
		state_duration = 0.52
		status_tag = "CASCADING STALACTITE STORM!"
		status_color = Color("#ffd18a")
	elif pick == "summon_minions":
		attack_damage = 1
		state_duration = 0.56
		status_tag = "BONE MINIONS RISING"
		status_color = Color("#ded5be")
	elif pick == "rib_crush":
		attack_damage = 2
		state_duration = 0.82
		status_tag = "!! 2-HEART CRYPT RIB-CRUSH !!"
		status_color = Color("#e66a61")
		_emit({"type": "float_text", "pos": pos + Vector2(0, -24), "text": "2-HEART CRUSH!", "color": Color("#e66a61")})
	state_timer = state_duration

func _exec_aaron_active(player_pos: Vector2) -> void:
	state = "active"
	attack_flash = 0.22
	var lead := _predict_pos(player_pos, 0.24)
	if attack_id == "bone_boomerang":
		# Spinning giant bone boomerangs that fly out AND curve back toward Aaron!
		var spreads: Array = [-0.36, 0.36] if phase == 1 else ([-0.45, 0.0, 0.45] if phase == 2 else [-0.55, -0.18, 0.18, 0.55])
		for ang in spreads:
			projectiles.append({
				"pos": pos + Vector2(0, -5),
				"vel": attack_dir.rotated(float(ang)) * (145.0 + float(phase) * 12.0),
				"life": 3.2,
				"radius": 5.5,
				"damage": 1,
				"kind": "bone",
				"boomerang": true,
				"age": 0.0,
				"spin": randf() * TAU,
				"color": Color("#ffd18a"),
			})
		state_duration = 0.26
		state_timer = 0.26
	elif attack_id == "bone_volley":
		var spread: Array = [-0.30, 0.0, 0.30] if phase == 1 else ([-0.44, -0.22, 0.0, 0.22, 0.44] if phase == 2 else [-0.56, -0.28, 0.0, 0.28, 0.56])
		var spd := 108.0 + float(phase) * 12.0
		for ang in spread:
			projectiles.append({
				"pos": pos + Vector2(0, -5),
				"vel": attack_dir.rotated(float(ang)) * spd,
				"life": 3.4,
				"radius": 5.0,
				"damage": 1,
				"kind": "bone",
				"spin": randf() * TAU,
				"color": Color("#fff8e6"),
			})
		state_duration = 0.24
		state_timer = 0.24
	elif attack_id == "rib_barriers":
		var gap_y := clampf(lead.y + randf_range(-18.0, 18.0), 74.0, 126.0)
		var gap_h := 32.0 if phase < 3 else 27.0
		var spd := 74.0 + float(phase) * 12.0
		rib_walls.append({"x": 20.0, "vx": spd, "gap_y": gap_y, "gap_h": gap_h, "telegraph": 0.40, "life": 3.0, "width": 8.0, "damage": 1})
		rib_walls.append({"x": 300.0, "vx": -spd, "gap_y": gap_y, "gap_h": gap_h, "telegraph": 0.40, "life": 3.0, "width": 8.0, "damage": 1})
		var gap_y2 := clampf(198.0 - gap_y, 74.0, 126.0)
		rib_walls.append({"x": 16.0, "vx": spd * 0.94, "gap_y": gap_y2, "gap_h": gap_h + 2.0, "telegraph": 0.98, "life": 3.4, "width": 8.0, "damage": 1})
		if phase == 3:
			rib_walls.append({"x": 304.0, "vx": -spd * 0.94, "gap_y": gap_y2, "gap_h": gap_h + 2.0, "telegraph": 0.98, "life": 3.4, "width": 8.0, "damage": 1})
		_emit({"type": "shake", "amount": 2.4})
		state_duration = 0.34
		state_timer = 0.34
	elif attack_id == "stalactite_drop":
		var count := 6 if phase == 2 else 9
		for i in range(count):
			var sp := Vector2(
				clampf(lead.x + randf_range(-56.0, 56.0), 26.0, 294.0),
				clampf(lead.y + randf_range(-32.0, 32.0), 62.0, 138.0)
			)
			ground_hazards.append({
				"kind": "stalactite", "pos": sp, "radius": 14.0,
				"telegraph": 0.48 + float(i) * 0.11, "max_telegraph": 0.48 + float(i) * 0.11,
				"active": 0.28, "damage": 1, "hit_done": false, "splinter": true, "color": Color("#fff8e6"),
			})
		state_duration = 0.38
		state_timer = 0.38
	elif attack_id == "summon_minions":
		var count := 2 if phase < 3 else 3
		for _i in range(count):
			var mp := Vector2(clampf(pos.x + randf_range(-46.0, 46.0), 34.0, 286.0), clampf(pos.y + randf_range(-28.0, 28.0), 64.0, 136.0))
			minions.append({"pos": mp, "vel": Vector2.ZERO, "hp": 24.0, "flash": 0.0, "radius": 7.0})
			_emit({"type": "particles", "pos": mp, "color": Color("#fff8e6"), "count": 10})
		_emit({"type": "message", "text": "SMASH BONE MINIONS FOR +1 COAL!"})
		state_duration = 0.26
		state_timer = 0.26
	elif attack_id == "rib_crush":
		var safe_x := clampf(lead.x, 76.0, 244.0)
		ground_hazards.append({
			"kind": "rib_crush", "pos": Vector2(safe_x - 56.0, 100.0),
			"rect": Rect2(14.0, 52.0, maxf(24.0, safe_x - 36.0), 96.0),
			"radius": 0.0, "telegraph": 0.74, "max_telegraph": 0.74, "active": 0.36,
			"damage": 2, "hit_done": false, "color": Color("#fff8e6"),
		})
		ground_hazards.append({
			"kind": "rib_crush", "pos": Vector2(safe_x + 56.0, 100.0),
			"rect": Rect2(safe_x + 22.0, 52.0, maxf(24.0, 306.0 - (safe_x + 22.0)), 96.0),
			"radius": 0.0, "telegraph": 0.74, "max_telegraph": 0.74, "active": 0.36,
			"damage": 2, "hit_done": false, "color": Color("#fff8e6"),
		})
		if phase == 3:
			# Delayed vertical Bone Lance cutting straight down the safe corridor (forces a crisp roll!)
			slash_lines.append({"a": Vector2(safe_x, 52.0), "b": Vector2(safe_x, 148.0), "telegraph": 0.92, "max_telegraph": 0.92, "active": 0.22, "damage": 1, "hit_done": false, "color": Color("#ffd18a")})
		state_duration = 0.42
		state_timer = 0.42

# =============================================================================
# 5. GRANDFATHER — ELDERLY OVERSEER NIGHTMARE (3-HIT CANE COMBO, TRIPLE CARTS, 3♥ BELL TOLL)
#    Canon: Grandfather remains visibly ELDERLY across ALL 3 phases!
# =============================================================================

func _ai_grandfather(delta: float, player_pos: Vector2) -> void:
	if state == "idle":
		state_timer -= delta
		if state_timer <= 0.0:
			if phase == 3 and ultimate_cooldown <= 0.0:
				_start_gf_attack("bell_toll_cataclysm", player_pos)
				return
			var choices: Array = []
			if phase == 1:
				choices = ["cane_combo", "mine_cart", "coal_barrage"]
			elif phase == 2:
				choices = ["cane_combo", "giant_cane_quake", "mine_cart", "crypt_doors", "rising_pillars"]
				if crystals.size() < 2:
					choices.append("raise_crystal")
			else:
				choices = ["giant_cane_quake", "coal_duel_spiral", "shaft_rotation", "mine_cart", "crypt_doors"]
				if crystals.size() < 3:
					choices.append("raise_crystal")
			_start_gf_attack(_pick_next(choices), player_pos)
	elif state == "reposition":
		pos += vel * delta
		state_timer -= delta
		if state_timer <= 0.0:
			vel = Vector2.ZERO
			state = "idle"
			state_timer = 0.24 if phase < 3 else 0.14
			state_duration = state_timer
	elif state == "telegraph":
		_check_glint_window(0.16)
		state_timer -= delta
		if attack_id == "bell_toll_cataclysm":
			var progress := 1.0 - (state_timer / maxf(0.01, state_duration))
			var target_tolls := 1 if progress < 0.34 else (2 if progress < 0.68 else 3)
			if target_tolls > bell_tolls_done:
				bell_tolls_done = target_tolls
				_emit({"type": "shake", "amount": 3.0})
				_emit({"type": "haptic", "ms": 22})
				_emit({"type": "float_text", "pos": pos + Vector2(0, -32), "text": "TOLL " + str(bell_tolls_done) + "/3", "color": Color("#ffd08a")})
				_emit({"type": "sfx", "name": "bell_toll"})
				if bell_tolls_done == 2:
					# Add a slow expanding ember ring during the 2nd toll so reaching Safe Circle + timing roll feels epic!
					pulse_rings.append({"center": Vector2(160.0, 100.0), "radius": 8.0, "max_radius": 230.0, "speed": 74.0, "thickness": 7.0, "damage": 1, "hit_done": false, "gap_angle": (player_pos - Vector2(160.0, 100.0)).angle() + 0.5, "gap_width": 0.72})
		if state_timer <= 0.0:
			glint_active = false
			_exec_gf_active(player_pos)
	elif state == "active":
		state_timer -= delta
		if state_timer <= 0.0:
			if attack_id == "cane_combo" and attack_step < 2:
				attack_step += 1
				attack_dir = (_predict_pos(player_pos, 0.16) - pos).normalized()
				facing = attack_dir
				glint_emitted = false
				state = "telegraph"
				attack_damage = 2 if attack_step == 2 else 1
				state_duration = 0.62 if attack_step == 2 else 0.34
				state_timer = state_duration
				status_tag = "!! 2-HEART ELDER CANE FINISHER !!" if attack_step == 2 else "IRON CANE FOLLOW-UP!"
			else:
				var rec := 1.75 if attack_id == "bell_toll_cataclysm" else (0.92 if attack_damage == 2 else 0.64)
				var tag := "EXHAUSTED • HEAVY PUNISH!" if attack_id == "bell_toll_cataclysm" else "OPEN • LEANING ON CANE"
				_finish_attack_or_chain(rec, tag)
	elif state == "recovery":
		state_timer -= delta
		if state_timer <= 0.0:
			status_tag = ""
			combo_chain_left = _roll_combo_chain()
			var desired := Vector2(244.0 if player_pos.x < 160.0 else 78.0, clampf(player_pos.y, 66.0, 134.0))
			vel = (desired - pos).normalized() * (68.0 if phase < 3 else 88.0)
			state = "reposition"
			state_duration = clampf(pos.distance_to(desired) / maxf(1.0, vel.length()), 0.25, 0.72)
			state_timer = state_duration

func _start_gf_attack(pick: String, player_pos: Vector2) -> void:
	attack_id = pick
	attack_step = 0
	attack_hit_done = false
	glint_emitted = false
	attack_target = _predict_pos(player_pos, 0.22)
	attack_dir = (attack_target - pos).normalized()
	if attack_dir.length() < 0.1:
		attack_dir = Vector2.LEFT
	facing = attack_dir
	state = "telegraph"
	if pick == "cane_combo":
		attack_damage = 1
		state_duration = 0.54
		status_tag = "3-HIT ELDERLY CANE COMBO!"
		status_color = Color("#ffd08a")
	elif pick == "mine_cart":
		attack_damage = 2
		state_duration = 0.54
		status_tag = "!! 2-HEART TRIPLE CARTS !!" if phase == 3 else "!! 2-HEART RUNAWAY CARTS !!"
		status_color = Color("#e66a61")
		_emit({"type": "message", "text": "WATCH THE LIT RAIL LANES  •  2-HEART MINE CARTS!"})
	elif pick == "coal_barrage":
		attack_damage = 1
		state_duration = 0.50
		status_tag = "PREDICTIVE COAL BARRAGE"
		status_color = Color("#e86f5c")
	elif pick == "raise_crystal":
		attack_damage = 1
		state_duration = 0.58
		status_tag = "RAISING COAL-HEART CRYSTAL!"
		status_color = Color("#ffd08a")
	elif pick == "giant_cane_quake":
		attack_damage = 2
		state_duration = 0.84
		status_tag = "!! 2-HEART ELDER QUAKE + SHARDS !!"
		status_color = Color("#e66a61")
		_emit({"type": "float_text", "pos": pos + Vector2(0, -28), "text": "2-HEART QUAKE!", "color": Color("#e66a61")})
	elif pick == "crypt_doors":
		attack_damage = 1
		state_duration = 0.56
		status_tag = "CHAPEL DOORS OPENING"
		status_color = Color("#ffd08a")
	elif pick == "rising_pillars":
		attack_damage = 1
		state_duration = 0.56
		status_tag = "RISING CHAPEL STONES"
		status_color = Color("#e86f5c")
	elif pick == "coal_duel_spiral":
		attack_damage = 1
		state_duration = 0.52
		status_tag = "COAL-VS-COAL COUNTER SPIRAL!"
		status_color = Color("#ffd08a")
	elif pick == "shaft_rotation":
		attack_damage = 1
		state_duration = 0.68
		status_tag = "ROTATING FURNACE CROSS BEAMS!"
		status_color = Color("#e86f5c")
	elif pick == "bell_toll_cataclysm":
		attack_damage = 3
		ultimate_cooldown = 13.5
		bell_tolls_done = 0
		state_duration = 1.75
		arena_alarm = 1.9
		status_tag = "!!! 3-HEART BELL TOLL • ENTER CYAN SAFE RING !!!"
		status_color = Color("#ff5e57")
		_emit({"type": "message", "text": "3-HEART BELL TOLL  •  STEP INTO A CYAN SAFE CIRCLE!"})
		var safe_a := Vector2(
			clampf(player_pos.x + (54.0 if player_pos.x < 160.0 else -54.0), 54.0, 266.0),
			clampf(player_pos.y + (-20.0 if player_pos.y > 100.0 else 20.0), 74.0, 126.0)
		)
		var safe_b := Vector2(clampf(320.0 - safe_a.x, 54.0, 266.0), clampf(200.0 - safe_a.y, 74.0, 126.0))
		ground_hazards.append({
			"kind": "cataclysm_bell", "pos": Vector2(160.0, 100.0), "radius": 0.0,
			"telegraph": 1.75, "max_telegraph": 1.75, "active": 0.28, "damage": 3, "hit_done": false,
			"color": Color("#ff4d4d"),
			"safe_circles": [{"pos": safe_a, "radius": 24.0}, {"pos": safe_b, "radius": 24.0}],
		})
	state_timer = state_duration

func _exec_gf_active(player_pos: Vector2) -> void:
	state = "active"
	attack_flash = 0.26
	var lead := _predict_pos(player_pos, 0.25)
	if attack_id == "cane_combo":
		# Step toward Choko and slam! Step 2 (3rd hit) is a 2-heart radial ember eruption!
		pos += attack_dir * 18.0
		var is_fin := (attack_step == 2)
		ground_hazards.append({
			"kind": "cane_quake",
			"pos": pos + attack_dir * 26.0,
			"radius": 38.0 if is_fin else 28.0,
			"telegraph": 0.30 if is_fin else 0.24,
			"max_telegraph": 0.30 if is_fin else 0.24,
			"active": 0.28,
			"damage": 2 if is_fin else 1,
			"hit_done": false,
			"color": Color("#e66a61") if is_fin else Color("#ffd08a"),
		})
		if is_fin:
			for k in range(8):
				var a := float(k) * (TAU / 8.0) + anim_time
				projectiles.append({"pos": pos, "vel": Vector2.RIGHT.rotated(a) * 96.0, "life": 3.0, "radius": 5.0, "damage": 1, "kind": "dark_coal", "color": Color("#ffd08a")})
			_emit({"type": "shake", "amount": 3.8})
		else:
			for ang in [-0.22, 0.0, 0.22]:
				projectiles.append({"pos": pos, "vel": attack_dir.rotated(float(ang)) * 102.0, "life": 2.8, "radius": 5.0, "damage": 1, "kind": "dark_coal", "color": Color("#ffd08a")})
		state_duration = 0.26
		state_timer = 0.26
	elif attack_id == "mine_cart":
		var lane_y := clampf(lead.y, 64.0, 136.0)
		var from_right := (randi() % 2 == 0)
		mine_carts.append({"pos": Vector2(316.0 if from_right else 4.0, lane_y), "vel": Vector2(-215.0 if from_right else 215.0, 0.0), "y": lane_y, "telegraph": 0.58, "active": false, "damage": 2, "hit_done": false})
		if phase >= 2:
			var lane_y2 := clampf(lane_y + (26.0 if lane_y < 100.0 else -26.0), 62.0, 138.0)
			mine_carts.append({"pos": Vector2(4.0 if from_right else 316.0, lane_y2), "vel": Vector2(215.0 if from_right else -215.0, 0.0), "y": lane_y2, "telegraph": 1.00, "active": false, "damage": 2, "hit_done": false})
		if phase == 3:
			var lane_y3 := clampf(200.0 - lane_y, 62.0, 138.0)
			mine_carts.append({"pos": Vector2(316.0 if from_right else 4.0, lane_y3), "vel": Vector2(-225.0 if from_right else 225.0, 0.0), "y": lane_y3, "telegraph": 1.42, "active": false, "damage": 2, "hit_done": false})
		state_duration = 0.34
		state_timer = 0.34
	elif attack_id == "coal_barrage":
		for ang in [-0.44, -0.22, 0.0, 0.22, 0.44]:
			projectiles.append({"pos": pos + Vector2(0, -6), "vel": attack_dir.rotated(float(ang)) * (108.0 + float(phase) * 10.0), "life": 3.2, "radius": 5.0, "damage": 1, "kind": "dark_coal", "color": Color("#e86f5c")})
		state_duration = 0.26
		state_timer = 0.26
	elif attack_id == "raise_crystal":
		var cpos := Vector2(68.0 if pos.x > 160.0 else 252.0, 74.0 if player_pos.y > 100.0 else 128.0)
		_spawn_coal_crystal(cpos)
		state_duration = 0.28
		state_timer = 0.28
	elif attack_id == "giant_cane_quake":
		ground_hazards.append({"kind": "cane_quake", "pos": pos, "radius": 50.0, "telegraph": 0.44, "max_telegraph": 0.44, "active": 0.30, "damage": 2, "hit_done": false, "color": Color("#e66a61")})
		ground_hazards.append({"kind": "cane_quake", "pos": Vector2(clampf(lead.x, 34.0, 286.0), clampf(lead.y, 64.0, 136.0)), "radius": 30.0, "telegraph": 0.58, "max_telegraph": 0.58, "active": 0.30, "damage": 2, "hit_done": false, "color": Color("#e66a61")})
		for k in range(6):
			var a := float(k) * (TAU / 6.0) + attack_dir.angle()
			projectiles.append({"pos": pos + Vector2(0, -6), "vel": Vector2.RIGHT.rotated(a) * 96.0, "life": 3.0, "radius": 5.0, "damage": 1, "kind": "dark_coal", "color": Color("#e86f5c")})
		_emit({"type": "shake", "amount": 4.0})
		state_duration = 0.40
		state_timer = 0.40
	elif attack_id == "crypt_doors":
		for side_x in [18.0, 302.0]:
			for offset_y in [-20.0, 0.0, 20.0]:
				var origin := Vector2(float(side_x), 98.0 + float(offset_y))
				var dir := (lead - origin).normalized()
				projectiles.append({"pos": origin, "vel": dir * 74.0, "life": 4.2, "radius": 5.5, "damage": 1, "kind": "coal_wisp", "homing": 1.35, "color": Color("#ffd08a")})
				_emit({"type": "particles", "pos": origin, "color": Color("#ffd08a"), "count": 6})
		state_duration = 0.34
		state_timer = 0.34
	elif attack_id == "rising_pillars":
		for i in range(5):
			var pp := Vector2(clampf(lead.x + float(i - 2) * 38.0, 34.0, 286.0), clampf(lead.y + randf_range(-20.0, 20.0), 64.0, 136.0))
			pillars.append({"pos": pp, "telegraph": 0.56 + float(i) * 0.10, "life": 2.6, "radius": 14.0, "active": false, "damage": 1, "hit_done": false})
		state_duration = 0.38
		state_timer = 0.38
	elif attack_id == "coal_duel_spiral":
		var arms := 12
		var base_ang := anim_time
		for i in range(arms):
			var ang := base_ang + TAU * float(i) / float(arms)
			projectiles.append({"pos": pos + Vector2(0, -6), "vel": Vector2.RIGHT.rotated(ang) * 96.0, "life": 3.4, "radius": 5.0, "damage": 1, "kind": "dark_coal", "color": Color("#ffd08a")})
			if i % 2 == 0:
				projectiles.append({"pos": pos + Vector2(0, -6), "vel": Vector2.RIGHT.rotated(ang + 0.25) * 66.0, "life": 3.8, "radius": 5.0, "damage": 1, "kind": "dark_coal", "color": Color("#e86f5c")})
		state_duration = 0.32
		state_timer = 0.32
	elif attack_id == "shaft_rotation":
		var base_a := (player_pos - Vector2(160.0, 100.0)).angle() + PI * 0.5
		var av := 1.05 if (randi() % 2 == 0) else -1.05
		shaft_beams.append({"center": Vector2(160.0, 100.0), "angle": base_a, "ang_vel": av, "telegraph": 0.72, "life": 3.2, "length": 145.0, "damage": 1})
		shaft_beams.append({"center": Vector2(160.0, 100.0), "angle": base_a + PI * 0.5, "ang_vel": av, "telegraph": 0.72, "life": 3.2, "length": 145.0, "damage": 1})
		state_duration = 0.42
		state_timer = 0.42
	elif attack_id == "bell_toll_cataclysm":
		_emit({"type": "shake", "amount": 5.4})
		_emit({"type": "haptic", "ms": 40})
		state_duration = 0.35
		state_timer = 0.35

# =============================================================================
# 6. THE DEAD CAT — ULTIMATE HIDDEN NIGHTMARE (PHANTOM CROSS-BLINK, TRIPLE RINGS, 3♥ REQUIEM)
#    Canon: unlocks strictly after Grandfather; connection to John Paul unconfirmed!
# =============================================================================

func _ai_dead_cat(delta: float, player_pos: Vector2) -> void:
	if state == "idle":
		visible_alpha = minf(1.0, visible_alpha + delta * 3.5)
		state_timer -= delta
		if state_timer <= 0.0:
			if phase == 3 and ultimate_cooldown <= 0.0:
				_start_dc_attack("requiem_chime", player_pos)
				return
			var choices: Array = ["phantom_blink", "chime_pulse", "echo_split"]
			if phase >= 2:
				choices.append("paw_trail_pounce")
				choices.append("triple_chime")
			_start_dc_attack(_pick_next(choices), player_pos)
	elif state == "reposition":
		pos += vel * delta
		visible_alpha = 0.32
		state_timer -= delta
		if state_timer <= 0.0:
			vel = Vector2.ZERO
			visible_alpha = 1.0
			state = "idle"
			state_timer = 0.22 if phase < 3 else 0.14
			state_duration = state_timer
	elif state == "telegraph":
		_check_glint_window(0.16)
		state_timer -= delta
		if attack_id == "echo_split":
			visible_alpha = 0.88
		if state_timer <= 0.0:
			glint_active = false
			_exec_dc_active(player_pos)
	elif state == "active":
		state_timer -= delta
		if attack_id == "phantom_blink":
			sub_timer -= delta
			var total_blinks := 3 if phase < 3 else 4
			if sub_timer <= 0.0 and attack_step < total_blinks:
				sub_timer = 0.28 if phase < 3 else 0.22
				attack_step += 1
				var prev := pos
				var ang := randf() * TAU
				var dest := _predict_pos(player_pos, 0.16) + Vector2.RIGHT.rotated(ang) * 56.0
				dest.x = clampf(dest.x, 28.0, 292.0)
				dest.y = clampf(dest.y, 60.0, 140.0)
				var cut_end := _predict_pos(player_pos, 0.14) + (_predict_pos(player_pos, 0.14) - dest).normalized() * 52.0
				slash_lines.append({"a": dest, "b": cut_end, "telegraph": 0.44, "max_telegraph": 0.44, "active": 0.20, "damage": 1, "hit_done": false, "color": Color("#e5f6ff")})
				pos = dest
				visible_alpha = 0.65
				_emit({"type": "particles", "pos": prev, "color": Color("#9ecae8"), "count": 8})
				_emit({"type": "sfx", "name": "dead_cat_chime"})
		elif attack_id == "echo_split":
			pos += attack_dir * 210.0 * delta
			if not attack_hit_done and pos.distance_to(player_pos) <= 17.0:
				attack_hit_done = true
				_emit({"type": "hurt_player", "amount": 1, "pos": player_pos})
		if state_timer <= 0.0:
			visible_alpha = 1.0
			var rec := 1.75 if attack_id == "requiem_chime" else 0.72
			var tag := "STILLNESS • HEAVY PUNISH!" if attack_id == "requiem_chime" else "SILHOUETTE SOLID • OPEN"
			_finish_attack_or_chain(rec, tag)
	elif state == "recovery":
		visible_alpha = 1.0
		state_timer -= delta
		if state_timer <= 0.0:
			status_tag = ""
			combo_chain_left = _roll_combo_chain()
			var desired := Vector2(randf_range(46.0, 274.0), randf_range(62.0, 136.0))
			if desired.distance_to(player_pos) < 62.0:
				desired.x = 268.0 if player_pos.x < 160.0 else 52.0
			vel = (desired - pos).normalized() * 165.0
			state = "reposition"
			state_duration = clampf(pos.distance_to(desired) / 165.0, 0.20, 0.56)
			state_timer = state_duration

func _start_dc_attack(pick: String, player_pos: Vector2) -> void:
	attack_id = pick
	attack_step = 0
	sub_timer = 0.0
	attack_hit_done = false
	glint_emitted = false
	attack_target = _predict_pos(player_pos, 0.20)
	attack_dir = (attack_target - pos).normalized()
	if attack_dir.length() < 0.1:
		attack_dir = Vector2.LEFT
	facing = attack_dir
	state = "telegraph"
	if pick == "phantom_blink":
		attack_damage = 1
		state_duration = 0.48
		status_tag = "PHANTOM CROSS-BLINK SLASH!"
		status_color = Color("#e5f6ff")
	elif pick == "chime_pulse" or pick == "triple_chime":
		attack_damage = 1
		state_duration = 0.54
		status_tag = "TRIPLE CHIME CADENCE • WEAVE OR ROLL!" if pick == "triple_chime" else "CHIME PULSE • GAP OR ROLL"
		status_color = Color("#9ecae8")
	elif pick == "echo_split":
		attack_damage = 1
		state_duration = 0.72
		status_tag = "ILLUSION SWARM • HIT GOLD CHARM OR BELL!"
		status_color = Color("#e5f6ff")
		var decoy_count := 2 if phase == 1 else (3 if phase == 2 else 4)
		for k in range(decoy_count):
			var ang := float(k) * (TAU / float(decoy_count)) + randf() * 0.5
			var dpos := player_pos + Vector2.RIGHT.rotated(ang) * 76.0
			dpos.x = clampf(dpos.x, 34.0, 286.0)
			dpos.y = clampf(dpos.y, 60.0, 138.0)
			var ddir := (_predict_pos(player_pos, 0.18) - dpos).normalized()
			decoys.append({
				"pos": dpos, "vel": ddir * 185.0, "target": player_pos,
				"telegraph": 0.72, "active": 0.50, "life": 1.25, "hit_done": false, "damage": 1,
			})
	elif pick == "paw_trail_pounce":
		attack_damage = 2
		state_duration = 0.76
		status_tag = "!! 2-HEART 5-NODE PAW HUNT !!"
		status_color = Color("#e66a61")
		_emit({"type": "float_text", "pos": pos + Vector2(0, -24), "text": "2-HEART HUNT!", "color": Color("#e66a61")})
	elif pick == "requiem_chime":
		attack_damage = 3
		ultimate_cooldown = 13.5
		state_duration = 1.80
		arena_alarm = 1.9
		status_tag = "!!! 3-HEART REQUIEM CHIME • ENTER SAFE LANE !!!"
		status_color = Color("#ff5e57")
		_emit({"type": "message", "text": "3-HEART REQUIEM CHIME  •  ENTER SAFE LANE & ROLL CHIME!"})
		var lane_x := clampf(player_pos.x + (38.0 if player_pos.x < 160.0 else -38.0), 48.0, 238.0)
		ground_hazards.append({
			"kind": "cataclysm_requiem", "pos": Vector2(160.0, 100.0), "radius": 0.0,
			"telegraph": 1.80, "max_telegraph": 1.80, "active": 0.28, "damage": 3, "hit_done": false,
			"color": Color("#b4d8ff"),
			"safe_rect": Rect2(lane_x, 52.0, 34.0, 96.0),
		})
		# Layer one sweeping chime pulse ring during Requiem!
		pulse_rings.append({"center": pos, "radius": 8.0, "max_radius": 240.0, "speed": 78.0, "thickness": 7.0, "damage": 1, "hit_done": false, "gap_angle": (player_pos - pos).angle() + PI * 0.5, "gap_width": 0.65})
	state_timer = state_duration

func _exec_dc_active(player_pos: Vector2) -> void:
	state = "active"
	attack_flash = 0.24
	if attack_id == "phantom_blink":
		sub_timer = 0.0
		state_duration = 0.95
		state_timer = 0.95
	elif attack_id == "chime_pulse" or attack_id == "triple_chime":
		var gap_ang := (player_pos - pos).angle() + PI * 0.45
		var ring_count := 2 if attack_id == "chime_pulse" else 3
		for r_i in range(ring_count):
			pulse_rings.append({
				"center": pos,
				"radius": 10.0 - float(r_i) * 18.0,
				"max_radius": 245.0,
				"speed": (96.0 if phase < 3 else 110.0) - float(r_i) * 14.0,
				"thickness": 7.0,
				"damage": 1,
				"hit_done": false,
				"gap_angle": gap_ang + float(r_i) * (PI * 0.85),
				"gap_width": 0.58,
			})
		_emit({"type": "particles", "pos": pos, "color": Color("#e5f6ff"), "count": 14})
		_emit({"type": "sfx", "name": "dead_cat_chime"})
		state_duration = 0.34
		state_timer = 0.34
	elif attack_id == "echo_split":
		attack_dir = (_predict_pos(player_pos, 0.16) - pos).normalized()
		state_duration = 0.46
		state_timer = 0.46
	elif attack_id == "paw_trail_pounce":
		var p_start := pos
		var p_end := _predict_pos(player_pos, 0.30)
		var nodes := 5
		for i in range(nodes):
			var t := float(i + 1) / float(nodes)
			var node_pos := p_start.lerp(p_end, t)
			var is_final := (i == nodes - 1)
			ground_hazards.append({
				"kind": "paw_node", "pos": node_pos, "radius": 22.0 if is_final else 13.0,
				"telegraph": 0.28 + float(i) * 0.14, "max_telegraph": 0.28 + float(i) * 0.14,
				"active": 0.26, "damage": 2 if is_final else 1, "hit_done": false,
				"color": Color("#e66a61") if is_final else Color("#9ecae8"),
			})
		pos = p_end
		state_duration = 0.62
		state_timer = 0.62
	elif attack_id == "requiem_chime":
		_emit({"type": "shake", "amount": 5.0})
		_emit({"type": "haptic", "ms": 36})
		state_duration = 0.35
		state_timer = 0.35

# =============================================================================
# SHARED HELPERS & INTERACTIVE HAZARD UPDATES
# =============================================================================

func _pick_next(choices: Array) -> String:
	if choices.is_empty():
		return ""
	if choices.size() == 1:
		last_attack_id = str(choices[0])
		return last_attack_id
	var filtered: Array = []
	for c in choices:
		if str(c) != last_attack_id:
			filtered.append(str(c))
	var pick: String = str(filtered[randi() % filtered.size()]) if not filtered.is_empty() else str(choices[0])
	last_attack_id = pick
	return pick

func _enter_recovery(duration: float, tag: String) -> void:
	state = "recovery"
	var eff := duration * (1.38 if difficulty == "easy" else 1.0)
	state_duration = eff
	state_timer = eff
	vel = Vector2.ZERO
	glint_active = false
	status_tag = tag
	status_color = Color("#ffd18a")

func _update_projectiles(delta: float, player_pos: Vector2) -> void:
	for i in range(projectiles.size() - 1, -1, -1):
		var s: Dictionary = projectiles[i]
		var p: Vector2 = s["pos"]
		var v: Vector2 = s["vel"]
		var deflected := bool(s.get("deflected", false))

		if deflected:
			var to_b := (pos - p).normalized() * v.length()
			v = v.lerp(to_b, clampf(delta * 7.5, 0.0, 1.0))
			p += v * delta
			s["pos"] = p
			s["vel"] = v
			s["life"] = float(s["life"]) - delta
			if p.distance_to(pos) <= get_hitbox_radius() + 8.0:
				take_damage(30.0, false, 52.0)
				if state != "staggered" and hp > 0.0:
					_enter_stagger(1.75, "KNOCKED DOWN BY ORB!")
				_emit({"type": "particles", "pos": pos, "color": Color("#ffd18a"), "count": 22})
				_emit({"type": "float_text", "pos": pos + Vector2(0, -22), "text": "30 KNOCKDOWN!", "color": Color("#ffd18a")})
				_emit({"type": "shake", "amount": 3.4})
				projectiles.remove_at(i)
				continue
			if float(s["life"]) <= 0.0:
				projectiles.remove_at(i)
			else:
				projectiles[i] = s
			continue

		# Aaron's Curving Bone Boomerangs arc outward, slow, then whip BACK toward Aaron!
		if bool(s.get("boomerang", false)):
			var age := float(s.get("age", 0.0)) + delta
			s["age"] = age
			if age > 0.42:
				var back := (pos - p).normalized() * 165.0
				v = v.lerp(back, clampf(delta * 3.8, 0.0, 1.0))
				if age > 0.95 and p.distance_to(pos) < 12.0:
					projectiles.remove_at(i)
					continue

		var homing := float(s.get("homing", 0.0))
		if homing > 0.0:
			var desired := (player_pos - p).normalized() * v.length()
			v = v.lerp(desired, clampf(homing * delta, 0.0, 1.0))
		p += v * delta * (0.80 if difficulty == "easy" else 1.0)

		var bounces := int(s.get("bounces", 0))
		if bounces > 0:
			var bounced := false
			if p.x < 16.0 or p.x > 304.0:
				v.x = -v.x
				p.x = clampf(p.x, 16.0, 304.0)
				bounced = true
			if p.y < 54.0 or p.y > 146.0:
				v.y = -v.y
				p.y = clampf(p.y, 54.0, 146.0)
				bounced = true
			if bounced:
				s["bounces"] = bounces - 1
				_emit({"type": "particles", "pos": p, "color": Color("#d6fff5"), "count": 6})

		s["pos"] = p
		s["vel"] = v
		s["life"] = float(s["life"]) - delta
		var r := float(s.get("radius", 5.0))
		if p.distance_to(player_pos + Vector2(0, -4)) < r + 4.5:
			_emit({"type": "hurt_player", "amount": int(s.get("damage", 1)), "pos": p})
			projectiles.remove_at(i)
		elif float(s["life"]) <= 0.0 or p.x < -10.0 or p.x > 330.0 or p.y < 24.0 or p.y > 184.0:
			projectiles.remove_at(i)
		else:
			projectiles[i] = s

func _update_bombs(delta: float, player_pos: Vector2) -> void:
	for i in range(bombs.size() - 1, -1, -1):
		var b: Dictionary = bombs[i]
		if bool(b["exploded"]):
			b["blast_flash"] = float(b["blast_flash"]) - delta
			if float(b["blast_flash"]) <= 0.0:
				bombs.remove_at(i)
			else:
				bombs[i] = b
			continue

		if bool(b.get("batted", false)):
			var bp: Vector2 = b["pos"] + Vector2(b["bat_vel"]) * delta
			b["pos"] = bp
			b["target_pos"] = bp
			b["fuse"] = float(b["fuse"]) - delta
			var hit_boss := bp.distance_to(pos) <= get_hitbox_radius() + 10.0
			if hit_boss or float(b["fuse"]) <= 0.0 or bp.x < 12.0 or bp.x > 308.0 or bp.y < 48.0 or bp.y > 152.0:
				b["exploded"] = true
				b["blast_flash"] = 0.26
				_emit({"type": "particles", "pos": bp, "color": Color("#c1fff0"), "count": 26})
				_emit({"type": "shake", "amount": 3.8})
				if hit_boss:
					take_damage(34.0, false, 48.0)
					if state != "staggered" and hp > 0.0:
						_enter_stagger(1.50, "STUNNED BY OWN BOMB!")
					_emit({"type": "float_text", "pos": pos + Vector2(0, -24), "text": "34 BOOM!", "color": Color("#c1fff0")})
					_emit({"type": "sfx", "name": "bomb_blast"})
			bombs[i] = b
			continue

		var ft := float(b["flight_t"])
		var fdur := float(b["flight_dur"])
		if ft < fdur:
			ft = minf(fdur, ft + delta)
			b["flight_t"] = ft
			var ratio := ft / maxf(0.01, fdur)
			b["pos"] = Vector2(b["start_pos"]).lerp(Vector2(b["target_pos"]), ratio)
		else:
			b["pos"] = b["target_pos"]
			b["fuse"] = float(b["fuse"]) - delta
			if float(b["fuse"]) <= 0.0:
				b["exploded"] = true
				b["blast_flash"] = 0.24
				var bp: Vector2 = b["target_pos"]
				var rad := float(b["radius"])
				var dmg := int(b["damage"])
				_emit({"type": "particles", "pos": bp, "color": Color("#ffe0a3"), "count": 20 if dmg == 1 else 32})
				_emit({"type": "shake", "amount": 2.6 if dmg == 1 else 4.2})
				_emit({"type": "haptic", "ms": 18 if dmg == 1 else 28})
				_emit({"type": "sfx", "name": "bomb_blast"})
				if dmg >= 2:
					blight_zones.append({"pos": bp, "radius": 22.0, "life": 6.0, "kind": "cinder", "tick": 0.35})
				if bool(b.get("cluster", false)):
					for k in range(4):
						var a := float(k) * (PI * 0.5) + PI * 0.25
						projectiles.append({"pos": bp, "vel": Vector2.RIGHT.rotated(a) * 112.0, "life": 2.2, "radius": 4.5, "damage": 1, "kind": "spark", "color": Color("#ffe0a3")})
				if player_pos.distance_to(bp) <= rad:
					_emit({"type": "hurt_player", "amount": dmg, "pos": bp})
		bombs[i] = b

func _update_slash_lines(delta: float, player_pos: Vector2) -> void:
	for i in range(slash_lines.size() - 1, -1, -1):
		var sl: Dictionary = slash_lines[i]
		var tele := float(sl["telegraph"])
		if tele > 0.0:
			sl["telegraph"] = tele - delta
			slash_lines[i] = sl
			continue
		var act := float(sl["active"]) - delta
		sl["active"] = act
		if not bool(sl["hit_done"]):
			var a: Vector2 = sl["a"]
			var b: Vector2 = sl["b"]
			var ab := b - a
			var ab_len := maxf(1.0, ab.length())
			var t := clampf((player_pos - a).dot(ab) / (ab_len * ab_len), 0.0, 1.0)
			var closest := a + ab * t
			if player_pos.distance_to(closest) <= 9.0:
				sl["hit_done"] = true
				_emit({"type": "hurt_player", "amount": int(sl.get("damage", 1)), "pos": closest})
		if act <= 0.0:
			slash_lines.remove_at(i)
		else:
			slash_lines[i] = sl

func _update_tripwires(delta: float, player_pos: Vector2) -> void:
	for i in range(tripwires.size() - 1, -1, -1):
		var tw: Dictionary = tripwires[i]
		var arm := float(tw["arm_t"])
		if arm > 0.0:
			tw["arm_t"] = arm - delta
			tripwires[i] = tw
			continue
		tw["life"] = float(tw["life"]) - delta
		var a: Vector2 = tw["a"]
		var b: Vector2 = tw["b"]
		var ab := b - a
		var ab_len := maxf(1.0, ab.length())
		var t := clampf((player_pos - a).dot(ab) / (ab_len * ab_len), 0.0, 1.0)
		var closest := a + ab * t
		var tripped := player_pos.distance_to(closest) <= 7.5
		if tripped or float(tw["life"]) <= 0.0:
			for k in range(5):
				var p := a.lerp(b, float(k + 0.5) / 5.0)
				ground_hazards.append({
					"kind": "trip_blast", "pos": p, "radius": 18.0,
					"telegraph": 0.28 + float(k) * 0.05, "max_telegraph": 0.28 + float(k) * 0.05,
					"active": 0.24, "damage": 1, "hit_done": false, "color": Color("#f0a256"),
				})
			_emit({"type": "shake", "amount": 2.4})
			tripwires.remove_at(i)
		else:
			tripwires[i] = tw

func _update_blight_zones(delta: float, player_pos: Vector2) -> void:
	for i in range(blight_zones.size() - 1, -1, -1):
		var bz: Dictionary = blight_zones[i]
		bz["life"] = float(bz["life"]) - delta
		bz["tick"] = maxf(0.0, float(bz["tick"]) - delta)
		if player_pos.distance_to(Vector2(bz["pos"])) <= float(bz["radius"]) and float(bz["tick"]) <= 0.0:
			bz["tick"] = 0.72
			_emit({"type": "hurt_player", "amount": 1, "pos": player_pos})
		if float(bz["life"]) <= 0.0:
			blight_zones.remove_at(i)
		else:
			blight_zones[i] = bz

func _update_snuff_vines(delta: float, player_pos: Vector2) -> void:
	for i in range(snuff_vines.size() - 1, -1, -1):
		var sv: Dictionary = snuff_vines[i]
		var idx := int(sv["target_idx"])
		if idx < 0 or idx >= braziers.size() or not bool(braziers[idx]["lit"]):
			snuff_vines.remove_at(i)
			continue
		var target := Vector2(braziers[idx]["pos"])
		var sp: Vector2 = sv["pos"]
		var dir := (target - sp).normalized()
		sp += dir * float(sv["speed"]) * delta
		sv["pos"] = sp
		if sp.distance_to(player_pos) <= 9.0:
			_emit({"type": "hurt_player", "amount": 1, "pos": sp})
		if sp.distance_to(target) <= 8.0:
			var b: Dictionary = braziers[idx]
			b["lit"] = false
			b["glow"] = 0.0
			braziers[idx] = b
			shadow_veiled = get_lit_brazier_count() < 2
			_emit({"type": "particles", "pos": target, "color": Color("#e8eef2"), "count": 14})
			_emit({"type": "float_text", "pos": target + Vector2(0, -12), "text": "BRAZIER SNUFFED!", "color": Color("#9ca6b8")})
			snuff_vines.remove_at(i)
		else:
			snuff_vines[i] = sv

func _update_steam_vents(delta: float, player_pos: Vector2) -> void:
	for i in range(steam_vents.size()):
		var sv: Dictionary = steam_vents[i]
		var st := str(sv["state"])
		if st == "idle":
			continue
		sv["timer"] = float(sv["timer"]) - delta
		var vp: Vector2 = sv["pos"]
		if st == "hiss" and float(sv["timer"]) <= 0.0:
			sv["state"] = "erupt"
			sv["timer"] = 1.45
			_emit({"type": "particles", "pos": vp, "color": Color("#d6fff5"), "count": 12})
		elif st == "erupt":
			if player_pos.distance_to(vp) <= 13.0:
				_emit({"type": "hurt_player", "amount": 1, "pos": vp})
			if id == "john_paul" and not bool(sv["hit_boss"]) and pos.distance_to(vp) <= 18.0 and state != "staggered":
				sv["hit_boss"] = true
				take_damage(26.0, false, 46.0)
				if state != "staggered" and hp > 0.0:
					_enter_stagger(1.65, "SCALDED BY STEAM!")
				_emit({"type": "float_text", "pos": vp + Vector2(0, -18), "text": "SCALDED! 26", "color": Color("#ffd18a")})
				_emit({"type": "shake", "amount": 3.0})
			if float(sv["timer"]) <= 0.0:
				sv["state"] = "idle"
		steam_vents[i] = sv

func _update_ground_hazards(delta: float, player_pos: Vector2) -> void:
	for i in range(ground_hazards.size() - 1, -1, -1):
		var h: Dictionary = ground_hazards[i]
		var tele := float(h["telegraph"])
		if tele > 0.0:
			h["telegraph"] = tele - delta
			if float(h["telegraph"]) <= 0.0:
				if bool(h.get("leave_blight", false)) and blight_zones.size() < 7:
					blight_zones.append({"pos": h["pos"], "radius": 14.0, "life": 6.5, "kind": "blight", "tick": 0.30})
				if bool(h.get("splinter", false)):
					var hp_pos: Vector2 = h["pos"]
					for k in range(4):
						var ang := float(k) * (PI * 0.5) + PI * 0.25
						projectiles.append({
							"pos": hp_pos, "vel": Vector2.RIGHT.rotated(ang) * 86.0,
							"life": 2.4, "radius": 4.0, "damage": 1, "kind": "bone",
							"spin": randf() * TAU, "color": Color("#fff8e6"),
						})
					_emit({"type": "particles", "pos": hp_pos, "color": Color("#fff8e6"), "count": 10})
					_emit({"type": "shake", "amount": 1.8})
			ground_hazards[i] = h
			continue
		var act := float(h["active"]) - delta
		h["active"] = act
		if not bool(h["hit_done"]):
			var kind := str(h["kind"])
			var dmg := int(h.get("damage", 1))
			var hit := false
			if kind == "cataclysm_bell":
				var in_safe := false
				for sc in h.get("safe_circles", []):
					if player_pos.distance_to(Vector2(sc["pos"])) <= float(sc["radius"]):
						in_safe = true
						break
				hit = not in_safe
			elif kind == "cataclysm_requiem":
				var sr: Rect2 = h.get("safe_rect", Rect2())
				hit = not sr.has_point(player_pos)
			elif h.has("rect") and Rect2(h["rect"]).size.length() > 1.0:
				hit = Rect2(h["rect"]).has_point(player_pos)
			else:
				hit = player_pos.distance_to(Vector2(h["pos"])) <= float(h.get("radius", 14.0))
			if hit:
				h["hit_done"] = true
				_emit({"type": "hurt_player", "amount": dmg, "pos": player_pos})
		if act <= 0.0:
			ground_hazards.remove_at(i)
		else:
			ground_hazards[i] = h

func _update_minions(delta: float, player_pos: Vector2) -> void:
	for i in range(minions.size() - 1, -1, -1):
		var m: Dictionary = minions[i]
		var mp: Vector2 = m["pos"]
		var dir := (player_pos - mp).normalized()
		mp += dir * 44.0 * delta
		mp.x = clampf(mp.x, 18.0, 302.0)
		mp.y = clampf(mp.y, 56.0, 144.0)
		m["pos"] = mp
		m["flash"] = maxf(0.0, float(m.get("flash", 0.0)) - delta)
		if mp.distance_to(player_pos) <= 11.0:
			_emit({"type": "hurt_player", "amount": 1, "pos": mp})
			m["pos"] = mp - dir * 16.0
		minions[i] = m

func _update_bone_shards(delta: float) -> void:
	for i in range(bone_shards.size() - 1, -1, -1):
		var bs: Dictionary = bone_shards[i]
		var bp: Vector2 = bs["pos"]
		var dir := (pos - bp).normalized()
		bp += dir * float(bs["speed"]) * delta
		bs["pos"] = bp
		if bp.distance_to(pos) <= 12.0:
			hp = minf(max_hp, hp + 16.0)
			state_timer = maxf(0.1, state_timer - 0.35)
			_emit({"type": "float_text", "pos": pos + Vector2(0, -18), "text": "+16 REASSEMBLE", "color": Color("#ded5be")})
			_emit({"type": "particles", "pos": pos, "color": Color("#fff8e6"), "count": 8})
			bone_shards.remove_at(i)
		else:
			bone_shards[i] = bs

func _update_rib_walls(delta: float, player_pos: Vector2) -> void:
	for i in range(rib_walls.size() - 1, -1, -1):
		var w: Dictionary = rib_walls[i]
		var tele := float(w["telegraph"])
		if tele > 0.0:
			w["telegraph"] = tele - delta
			rib_walls[i] = w
			continue
		w["x"] = float(w["x"]) + float(w["vx"]) * delta
		w["life"] = float(w["life"]) - delta
		var wx := float(w["x"])
		var half_w := float(w["width"]) * 0.5 + 3.0
		var gap_y := float(w["gap_y"])
		var half_gap := float(w["gap_h"]) * 0.5
		if absf(player_pos.x - wx) <= half_w and absf(player_pos.y - gap_y) > half_gap:
			_emit({"type": "hurt_player", "amount": int(w.get("damage", 1)), "pos": Vector2(wx, player_pos.y)})
		if float(w["life"]) <= 0.0 or wx < 6.0 or wx > 314.0:
			rib_walls.remove_at(i)
		else:
			rib_walls[i] = w

func _update_mine_carts(delta: float, player_pos: Vector2) -> void:
	for i in range(mine_carts.size() - 1, -1, -1):
		var c: Dictionary = mine_carts[i]
		var tele := float(c["telegraph"])
		if tele > 0.0:
			c["telegraph"] = tele - delta
			if float(c["telegraph"]) <= 0.0:
				c["active"] = true
				_emit({"type": "shake", "amount": 2.4})
			mine_carts[i] = c
			continue
		var cp: Vector2 = c["pos"]
		cp += Vector2(c["vel"]) * delta
		c["pos"] = cp
		if not bool(c["hit_done"]) and absf(player_pos.x - cp.x) <= 15.0 and absf(player_pos.y - cp.y) <= 12.0:
			c["hit_done"] = true
			_emit({"type": "hurt_player", "amount": int(c.get("damage", 2)), "pos": cp})
		if cp.x < -28.0 or cp.x > 348.0:
			mine_carts.remove_at(i)
		else:
			mine_carts[i] = c

func _update_pillars(delta: float, player_pos: Vector2) -> void:
	for i in range(pillars.size() - 1, -1, -1):
		var pl: Dictionary = pillars[i]
		var tele := float(pl["telegraph"])
		if tele > 0.0:
			pl["telegraph"] = tele - delta
			if float(pl["telegraph"]) <= 0.0:
				pl["active"] = true
				_emit({"type": "particles", "pos": Vector2(pl["pos"]), "color": Color("#8b7f8c"), "count": 12})
				_emit({"type": "shake", "amount": 2.2})
				if not bool(pl["hit_done"]) and player_pos.distance_to(Vector2(pl["pos"])) <= float(pl["radius"]):
					pl["hit_done"] = true
					_emit({"type": "hurt_player", "amount": int(pl.get("damage", 1)), "pos": Vector2(pl["pos"])})
			pillars[i] = pl
			continue
		pl["life"] = float(pl["life"]) - delta
		if float(pl["life"]) <= 0.0:
			pillars.remove_at(i)
		else:
			pillars[i] = pl

func _update_crystals(delta: float, player_pos: Vector2) -> void:
	for i in range(crystals.size()):
		var c: Dictionary = crystals[i]
		c["flash"] = maxf(0.0, float(c["flash"]) - delta)
		c["fire_cd"] = float(c["fire_cd"]) - delta
		if float(c["fire_cd"]) <= 0.0:
			c["fire_cd"] = 2.4 if phase == 2 else 1.85
			var cp: Vector2 = c["pos"]
			var dir := (_predict_pos(player_pos, 0.20) - cp).normalized()
			projectiles.append({
				"pos": cp, "vel": dir * 82.0, "life": 3.5, "radius": 4.5,
				"damage": 1, "kind": "dark_coal", "color": Color("#ffd08a"),
			})
		crystals[i] = c

func _update_shaft_beams(delta: float, player_pos: Vector2) -> void:
	for i in range(shaft_beams.size() - 1, -1, -1):
		var sb: Dictionary = shaft_beams[i]
		var tele := float(sb["telegraph"])
		if tele > 0.0:
			sb["telegraph"] = tele - delta
			shaft_beams[i] = sb
			continue
		sb["angle"] = float(sb["angle"]) + float(sb["ang_vel"]) * delta
		sb["life"] = float(sb["life"]) - delta
		var center: Vector2 = sb["center"]
		var beam_dir := Vector2.RIGHT.rotated(float(sb["angle"]))
		var to_p := player_pos - center
		var proj := to_p.dot(beam_dir)
		var perp := absf(to_p.x * beam_dir.y - to_p.y * beam_dir.x)
		if absf(proj) <= float(sb["length"]) and perp <= 7.0:
			_emit({"type": "hurt_player", "amount": int(sb.get("damage", 1)), "pos": player_pos})
		if float(sb["life"]) <= 0.0:
			shaft_beams.remove_at(i)
		else:
			shaft_beams[i] = sb

func _update_decoys(delta: float, player_pos: Vector2) -> void:
	for i in range(decoys.size() - 1, -1, -1):
		var d: Dictionary = decoys[i]
		var tele := float(d["telegraph"])
		if tele > 0.0:
			d["telegraph"] = tele - delta
			decoys[i] = d
			continue
		var dp: Vector2 = d["pos"]
		dp += Vector2(d["vel"]) * delta
		d["pos"] = dp
		d["active"] = float(d["active"]) - delta
		if not bool(d["hit_done"]) and dp.distance_to(player_pos) <= 13.0:
			d["hit_done"] = true
			_emit({"type": "hurt_player", "amount": int(d.get("damage", 1)), "pos": dp})
		if float(d["active"]) <= 0.0:
			decoys.remove_at(i)
		else:
			decoys[i] = d

func _update_pulse_rings(delta: float, player_pos: Vector2) -> void:
	for i in range(pulse_rings.size() - 1, -1, -1):
		var pr: Dictionary = pulse_rings[i]
		var r := float(pr["radius"]) + float(pr["speed"]) * delta
		pr["radius"] = r
		if r > 4.0 and not bool(pr["hit_done"]):
			var dist := player_pos.distance_to(Vector2(pr["center"]))
			var thick := float(pr.get("thickness", 7.0))
			if absf(dist - r) <= thick * 0.65:
				var p_ang := (player_pos - Vector2(pr["center"])).angle()
				var diff := absf(wrapf(p_ang - float(pr["gap_angle"]), -PI, PI))
				if diff > float(pr["gap_width"]) * 0.5:
					pr["hit_done"] = true
					_emit({"type": "hurt_player", "amount": int(pr.get("damage", 1)), "pos": player_pos})
		if r >= float(pr["max_radius"]):
			pulse_rings.remove_at(i)
		else:
			pulse_rings[i] = pr

func _update_catacomb_bells(delta: float) -> void:
	for i in range(catacomb_bells.size()):
		var b: Dictionary = catacomb_bells[i]
		b["cooldown"] = maxf(0.0, float(b["cooldown"]) - delta)
		b["ring_anim"] = maxf(0.0, float(b["ring_anim"]) - delta)
		catacomb_bells[i] = b
	for i in range(bell_waves.size() - 1, -1, -1):
		var bw: Dictionary = bell_waves[i]
		bw["radius"] = float(bw["radius"]) + 280.0 * delta
		bw["alpha"] = maxf(0.0, 1.0 - float(bw["radius"]) / float(bw["max_radius"]))
		if float(bw["radius"]) >= float(bw["max_radius"]):
			bell_waves.remove_at(i)
		else:
			bell_waves[i] = bw
