# Phase 2.4 — Secret Encounter Story & Respawn Presentation

## Scope
This phase adds the respawn presentation to the playable combat prototype and records the intended story beats for the campaign's hidden Dead Cat encounter. The current project is still the Quarry Sentinel combat sandbox; the campaign boss encounter is a design/story addition, not yet a playable boss fight.

## Hidden encounter: The Dead Cat

**Unlock condition:** Defeat Grandfather, then find the concealed route that opens beyond his underground arena.

### Discovery sequence
1. After Grandfather's defeat, the arena goes quiet. The normal exit remains dark, but a small service light begins blinking behind a cracked section of the chamber.
2. Choko finds a narrow maintenance passage. The deeper he walks, the less the mine sounds like a mine: distant machinery stops, leaving only a soft, irregular bell-like chime.
3. A sealed door opens into an old, forgotten room. Its floor is covered in dust, but a fresh trail leads toward the centre. Choko pauses rather than immediately charging forward.
4. The Dead Cat appears from the darkness. Keep the reveal brief and strange; let its silhouette, movement and sound design carry the unease rather than graphic imagery.

### Pre-fight dialogue (placeholder)
- **Choko:** "...This place wasn't on the map."
- **Choko:** "Hey. Are you guarding something?"
- **The Dead Cat:** *A low, familiar-sounding chime answers. It does not speak.*
- **Choko:** "Okay. I guess we're doing this."

### Encounter direction
- The boss should feel unlike the six main underground bosses: quieter, more mysterious, and built around anticipation and unusual movement.
- Telegraph every attack clearly so the fight is fair on a phone screen.
- Use the arena itself to tell the story: old objects, a sealed exit, subtle environmental reactions and a distinctive sound motif.
- Do not establish a connection to John Paul unless the story canon confirms it. Do not explain the Dead Cat's origin in this phase.

### After the encounter
The room becomes still. Choko discovers a small, non-essential secret reward and a short clue that makes the player curious about the mine's past without resolving the mystery. Keep the ending quiet; no long exposition dump.

## Respawn menu — “one more video”

When Choko loses all hearts, the combat scene fades to a dark, quiet screen. Choko is shown sitting behind a small laptop, watching a sequence of deliberately ridiculous fictional brainrot clips. The captions rotate every few seconds:

- `SIGMA MINING ARC`
- `BRO REALLY SAID 'WHAT'`
- `NPC MOMENT +999`
- `THE WIFI IS THE FINAL BOSS`

A single large **RESPAWN** button returns Choko to the training room with full hearts and restored resources. On keyboard, Enter, Space or Escape also respawns. The joke should stay quick and readable, with no real-world video, logos or copyrighted clips.

## Implementation status
- Implemented in this prototype: timed death transition, animated rotating laptop captions, procedural pixel-art Choko/laptop screen, touch respawn button, keyboard respawn, clean training-room reset.
- Story design added: Dead Cat discovery, short pre-fight exchange, encounter tone and post-fight beat.
- Not yet implemented: campaign progression, hidden door trigger, Dead Cat boss AI/attacks, bespoke sprite animation, music and sound effects.
