# Phase 3.1 — Souls-Like Boss Overhaul & Interactive Arena Elements

## Overview
Phase 3.1 upgrades all six underground campaign/secret boss encounters (plus the preserved Quarry Sentinel practice construct) to Souls-like intensity and mechanical depth while keeping every Phase 2.5/3.0 canon rule, five-heart baseline, grounded four-direction movement, multi-touch controls, and laptop brainrot respawn screen intact.

## Core Souls-Like Combat Additions
- **Boss Posture Gauge & Posture Breaks:** Added centered Posture bar beneath every boss HP bar (`max_posture`: 80–135 with passive decay after `2.4s` idle). Reaching 100% triggers **`POSTURE BROKEN!`** (`1.45x` Riposte damage, `+2 COAL` drop, hit-stop, screen shake).
- **Perfect Dodge → Counter-Strike Riposte:** Landing a `0.13s` Perfect Dodge now grants `+1 COAL`, `+18` Boss Posture, and a `1.25s` **COUNTER READY** window (turning the `HIT` button to cyan `CTR`) that turns Choko's next pickaxe swing into a `1.6x` damage, `36` Posture **COUNTER STRIKE!**.
- **Delayed Roll-Catch Glints:** Added a `0.17s–0.18s` white-gold 4-point star glint right before delayed heavy strikes, feints, and pounces release so panic-rolling is punished while disciplined timing is rewarded.
- **Anti-Greed Mining Reaction:** Campaign bosses compress remaining idle delay to `0.24s` if Choko begins mining while they are idle.

## Per-Boss Souls-Like Upgrades & Interactive Elements

| Boss | HP / Posture | New Interactive Elements | Souls-Like Escalation |
|---|---:|---|---|
| **Farhan** | 290 / 100 | Pickaxe Bomb Batting (`32` dmg + `44` Posture + stun); Blast Shutter Laser Tripwires (P2/P3); `2♥` Satchel Cinder Zones | Delayed roll-catch feint-slash, mid-combo bomb drop, P3 backflip grenade finisher |
| **Allan** | 310 / 110 | 3 Oil Braziers + **Solar Flare Overburn** (all 3 lit); choppable **Snuffing White Vines** (`+1 COAL`); **Pale Blight Pools** | Root Cages with escape notch, dual staggered spore rings, P3 double `2♥` Thorn Cleave |
| **John Paul** | 320 / 105 | Pickaxe **Spirit Yarn Orb Deflection** (wall knockdown, `28` dmg + `48` Posture); **3 Pressurized Steam Vents** (scald boss for `24` dmg + `42` Posture!) | Multi-wall parkour pounce chains (up to 3 wall kicks), chained `2♥` Predator Pounce, 4-hit P3 claw flurry |
| **Aaron** | 340 / 100 | **4 Sliding Reassembly Bone Shards** (heal `+12 HP` unless smashed for `+1 COAL` + stun extension); **Falling Fossil Stalactites** w/ splinters | Staggered dual-wave Rib Barriers, `1.55x` Pickaxe `BONE BREAK!` while disassembled, `2♥` Crypt Rib-Crush |
| **Grandfather** | 440 / 135 | **Coal-Heart Anchor Crystals** (tether reduces boss dmg to `72%`; shatter for `22` burst dmg + `44` Posture + `+2 COAL`) | Visibly elderly in all 3 phases; staggered twin-lane `2♥` carts; delayed `2♥` Elder Cane Quake + shards; P3 Dual Rotating Shaft Beams; rare `3♥` Bell Toll Cataclysm |
| **The Dead Cat** *(Secret)* | 380 / 120 | **2 Tarnished Catacomb Bells** (strike to fire golden Clearing Chime Wave that banishes Echo Decoys & reveals stealth for Posture/stagger) | Gold-charm Silhouette Swap-Feints, dual opposing-gap Chime Pulse Rings, 4-node accelerating `2♥` Paw-Trail, rare `3♥` Requiem Chime |
| **Quarry Sentinel** *(Practice)* | 180 / 80 | Non-campaign practice construct preserved; now supports Posture Breaks & Counter-Strike practice | Preserved 1/3/5-shot volley escalation |

## Verification Status
- Static verification passed across all 6 GDScript files, `scenes/main.tscn`, `project.godot`, `res://` links, cross-module symbols, and ZIP integrity (`0` errors, `0` warnings).
- **Not runtime-tested:** No Godot executable was present in this environment. Runtime execution and balance playtesting on desktop/Android remain required.

## Phase 3.1.1 Hotfix (Godot 4.7.2 Strict GDScript Typing)
- Fixed `scripts/main.gd:417` parse error (`Cannot infer the type of "posture_dmg"`) by explicitly typing `posture_dmg: float` and wrapping the untyped array lookup in `float(...)`.
- Converted `choices` and `_pick_next()` in `scripts/boss_controller.gd` from `Array[String]` to `Array` with `str(...)` casts to prevent Godot 4 runtime typed-array assignment errors during Grandfather's AI loop.
- Hardened loop-variable typing in `scripts/ui_and_cutscenes.gd` (`_draw_wrapped`) and `scripts/boss_renderer.gd` (`_draw_allan`).
