# Phase 2.3 — Directional Combat and Game-Feel Pass

## Design decision
The playable training room is now a top-down grounded arena. This makes four-direction movement and four-direction melee mechanically honest: up/down move across the floor plane, not vertically into the air. Choko cannot fly.

## Improvements
- 4-way ground movement, normalized diagonal speed and cardinal facing lock.
- Pickaxe hit checks use a forward cone/rectangle along the selected cardinal direction.
- New top-down Choko sprite composition with direction-specific head position, scarf, satchel, stride and pickaxe swing.
- Coal throw follows the intended aim vector.
- Three escalating sentinel attack patterns: one aimed bolt, three-bolt fan, five-bolt fan.
- Stronger arena architecture and more visual landmarks.
- Reworked HUD, phase display and combat prompts.

## Test checklist
1. Move up, down, left and right; Choko should remain on the floor plane.
2. Move in a direction, release the joystick, and tap HIT; the attack should retain that direction.
3. Approach the sentinel from each side and confirm directional pickaxe hits.
4. Hold COAL, drag in four directions and release; the projectile should travel in that direction.
5. Observe the sentinel at full, middle and low health; attack spread should increase while warning markers remain visible.
6. Test mine interactions at all three seam locations.

## Known scope limits
No final sprite sheets, final music/SFX, save system, campaign boss logic or Android store signing is included in this phase.
