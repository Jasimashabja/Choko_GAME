# Phase 4.5 — Easy / Nightmare Modes & Overhauled Boss Encounters

## Difficulty Mode System
- Added persistent `difficulty` setting (`"nightmare"` default, `"easy"` option) saved to `user://choko_save.json`.
- Added instant mode switchers on the **Title Screen** (`RECT_TITLE_DIFF` + keyboard `M`), **Bosses Screen** (`RECT_BOSSES_DIFF`), and **Settings Screen** (Row 0), plus a live `EASY` / `NIGHTMARE` badge on the combat HUD and victory banner.
- **EASY Mode Balancing:** `65%` Boss HP, `75%` Boss Posture, `50%` Posture drain, zero Anti-Greed Retaliations, single-attack cadence, `1.38x` recovery windows, `1.22x` telegraph time, `0.35x` lead-aim, `0.80x` hostile projectile speed, `2♥ -> 1♥` and `3♥ -> 2♥` damage cap, `8` starting coal, `6.5s` vein respawn, `0.18s` Perfect Dodge window, `0.72s` roll cooldown, and `1.28s–1.35s` hit i-frames.
- **NIGHTMARE Mode Balancing:** Retains the full relentless Phase 4.4 Souls-like gauntlet.

## Boss Encounter Lines, Live Phase Banter & Storytelling Props
- Polished all 6 boss encounter scripts (`scripts/boss_data.gd`) incorporating the creator's signature lines for Farhan, Allan (white cotton + Grandfather's darkness), John Paul (kitten business + wrath of the Mighty Shaji Kitten), Aaron (interrupted love life with Steve), Grandfather (mining coal forever for his heaters), and The Dead Cat / Ghost Cat (revenge for murder; link to John Paul remains unconfirmed).
- Added live **Mid-Fight Phase 2 & Phase 3 Boss Banter Banners** with `44×44` character portraits during phase shifts (`scripts/boss_controller.gd` + `scripts/ui_and_cutscenes.gd`).
- Added encounter storytelling props in `scripts/arena_renderer.gd`: Aaron's flickering romantic date-night candles for Steve, Allan's drifting white cotton fluff tufts, Grandfather's glowing iron chapel heater grates, John Paul's golden-cyan Shaji Kitten aura, and Farhan's P2/P3 blast-shutter lock beacons.

## Verification
- Static audit passed: 8 scripts, 24 PNGs, 32 WAVs, `project.godot`, `scenes/main.tscn`, cross-module symbols, Godot 4.7.2 strict typing, and ZIP integrity (`0` errors, `0` warnings).
- Runtime execution in Godot 4.x was not performed because no Godot binary is installed in this environment.
