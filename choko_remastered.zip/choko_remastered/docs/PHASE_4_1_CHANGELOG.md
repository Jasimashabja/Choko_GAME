# Phase 4.1 — HD Crisp Text, 640×360 Visual Overhaul & Hand-Crafted Arenas

## Core Visual & Readability Fixes
- **Eliminated Pixelated Text:** Upgraded `project.godot` from `320×180` `viewport` stretch to `640×360` `canvas_items` (`aspect="keep"`). All UI, HUD, Hub, Settings, Cutscene, Respawn, and floating combat text now renders at native display sharpness with `10px–24px` sizing and crisp drop shadows.
- **Fixed Godot 4 Texture Filter Setting:** Updated `textures/default_filters/texture_filter=0` (Nearest) from `1` (Linear) so all pixel-art textures render razor-sharp.
- **Preserved 100% of Gameplay Balance:** Combat physics, movement speeds, hitboxes, boss attacks, and safe zones remain in the verified `320×180` logical coordinate model rendered inside a clean `2.0x` world transform, while high-res arenas and 2× sprites render at true `1:1` pixel density in `640×360`.

## Art & UI Upgrades
- **7 Textured `640×360` Underground Arenas (`assets/arenas/arena_*.png`):** Farhan's Floodlit Explosives Depot, Allan's Lightless Root Cathedral, John Paul's Drainage & Rail Station, Aaron's Fossil Crypt, Grandfather's Buried Chapel, The Dead Cat's Sealed Catacomb, and the Quarry Sentinel Training Chamber.
- **Upgraded 2× High-Detail Pixel-Art Sprites (`assets/sprites/*_sheet.png`):** Choko `48×48` (4 directions × 4 frames), Farhan `64×64`, Allan `72×72`, John Paul `64×64`, Aaron `64×64`, Grandfather `96×96` (elderly across all 3 phases), Dead Cat `64×64`, Sentinel `72×72`.
- **Upgraded `96×96` Ornate Portraits (`assets/sprites/portraits/portrait_*.png`):** Displayed in both Cutscene dialogue panels and Boss Hub selection cards.
- **Upgraded UI Layouts (`scripts/ui_and_cutscenes.gd` & `scripts/main.gd`):** Native `640×360` beveled panels, portrait Hub cards, refined multi-touch controls, enriched Plane Escape dawn sky, and upgraded Laptop Brainrot Respawn screen.

## Verification
- Static audit passed: 8 scripts, 23 PNGs, 30 WAVs, `project.godot`, `scenes/main.tscn`, cross-module symbols, Godot 4.7.2 strict typing, and ZIP integrity (`0` errors, `0` warnings).
- Runtime testing NOT performed in this environment (no Godot binary available).
