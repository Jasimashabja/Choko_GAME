# Phase 4.3 — Instant-Start Story, Souls-Like Combat Juice & Visual Polish

## Player-Facing Changes
- **Zero-Spoiler Instant-Start STORY:** Removed the preview/roadmap story screen so clicking **STORY** immediately launches the campaign (Prologue → Shaft I on fresh play, or straight to the next uncleared shaft on continue).
- **Refined Indie Title Screen:** Asymmetric high-craft layout featuring animated Choko on the foreground rails, swaying volumetric mine lanterns, rising embers, bold `CHOKO — THE LAST SHIFT` lockup, and clean right-aligned `STORY` / `BOSSES` / `SETTINGS` stack with non-spoiling progress tags.
- **Underground Shaft Transition Cards:** Added atmospheric 1.45s shaft transition screens with animated elevator guide rails and `shaft_transition.wav` audio between encounters (tap/Space to skip).
- **Typewriter Cutscenes & Smooth Fades:** Dialogue reveals smoothly with `text_blip.wav` ticks (tap once to complete line, tap again to advance) and smooth fade transitions across screens.
- **Souls-Like Combat Juice Upgrades:**
  - `0.14s` input buffering on pickaxe attacks and dodge rolls for crisp mobile and keyboard responsiveness.
  - Smooth white trailing Boss HP drain bar.
  - Multi-layered glowing crescent pickaxe slash trails (amber normal, fiery Heavy Finish, electric cyan Counter-Strike).
  - Translucent cyan Choko sprite ghost afterimages during dodge rolls.
  - Directional velocity trails on coal throws and boss projectiles, boss hit-recoil jitter, expanding impact shockwave rings, and a 1-heart low-health edge pulse.

## Verification
- Static verification passed: 8 scripts, 24 PNGs, 32 WAVs, `project.godot`, `scenes/main.tscn`, cross-module symbols, Godot 4.7.2 strict typing, and ZIP integrity (`0` errors, `0` warnings).
- Runtime execution in Godot 4.x was not performed because no Godot binary is installed in this environment.
