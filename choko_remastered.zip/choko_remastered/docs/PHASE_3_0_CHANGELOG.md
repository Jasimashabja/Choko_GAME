# Phase 3.0 — Major Boss-Combat Overhaul Changelog

## Summary
Phase 3.0 expands the Phase 2.5 precision-combat prototype into a full 6-boss underground boss rush plus the preserved non-campaign Quarry Sentinel practice encounter, while maintaining 100% continuity with Choko's grounded 4-direction movement, Perfect Dodge, coal mining, multi-touch controls, and laptop brainrot respawn presentation.

## Architecture Changes
- Kept `scenes/main.tscn` intact (`Main` -> `res://scripts/main.gd`) for seamless Android project import.
- Split boss definitions, AI, rendering, and UI into modular GDScript files:
  - `scripts/boss_data.gd`
  - `scripts/boss_controller.gd`
  - `scripts/arena_renderer.gd`
  - `scripts/boss_renderer.gd`
  - `scripts/ui_and_cutscenes.gd`
  - `scripts/main.gd`
- Added persistent save storage at `user://choko_save.json` tracking cleared encounters, per-boss attempt counts, best phase reached, and Dead Cat discovery state.

## Boss Combat Overhaul & Balance Table

| Boss | Arena (All Underground) | HP | Phases | Punish Window | 2-Heart Attacks | Rare 3-Heart Attacks |
|---|---|---:|---|---|---|---|
| Quarry Sentinel *(Practice)* | Quarry Training Chamber | 180 | 3 | Always open | None | None |
| 1. Farhan | Subterranean Explosives Depot | 240 | 3 | Reload / post-lunge recovery (`1.15x`) | Satchel Charge (P2/P3) | None |
| 2. Allan | Lightless Root Cathedral | 260 | 3 | Light 2+ braziers -> `2.5s` Exposed Stagger (`1.35x`) | Thorn Lash Sweep (P2/P3) | None |
| 3. John Paul | Underground Drainage & Rail Station | 270 | 3 | Dodged pounce -> `1.45s` Claws Stuck (`1.15x`) | Predator Wall-Pounce (P2/P3) | None |
| 4. Aaron | Fossil Crypt Mine Tunnel | 280 | 3 | Disassembled Stagger -> `3.2s` `1.5x` Pickaxe Bonus | Crypt Rib-Crush (P3) | None |
| 5. Grandfather | Buried Chapel Beneath the Quarry | 360 | 3 | Leaning on Cane / `1.85s` Post-Bell Exhaustion | Runaway Cart (P1–3), Giant Cane Quake (P2–3) | Bell Toll Cataclysm (P3, `16s` CD, `1.75s` telegraph, 2 cyan Safe Circles) |
| 6. The Dead Cat *(Secret)* | Sealed Catacomb Beneath the Chapel | 310 | 3 | Counter real silhouette during Echo Split (`1.75s`) / Post-Requiem (`1.80s`) | Silent Paw-Trail Pounce (P2/P3) | Requiem Chime (P3, `16.5s` CD, `1.85s` telegraph, bright Safe Lane) |

## Canon Compliance Checklist
- Choko is a boy; Farhan is Choko's lover/rival (throws bombs, never planes; becomes ally after victory).
- Allan is a dark supernatural being who creates and controls glowing white plants.
- John Paul is a cat-human hybrid (pointed ears, tail, wall-runs, claws, yarn orb).
- Grandfather remains visibly elderly (white hair, white beard, spectacles, hunched stance, iron cane) in all three phases, including corrupted Phases 2 and 3.
- Hidden Dead Cat unlocks strictly after Grandfather is defeated, via the blinking service light and maintenance passage discovery sequence; any link to John Paul remains unconfirmed.
- All six boss arenas are underground; the quarry airstrip appears solely in the Plane Escape ending cutscene.
- Grounded 4-direction floor-plane movement preserved (Choko never flies when moving vertically).

## Bug Fixes Carried Forward from Phase 2.5 Inspection
- Removed unused variables (`distance`, `in_front`) in melee hit detection.
- Removed redundant unreachable `death_menu_active` keyboard branches.
- Aligned Laptop Respawn Menu `RESPAWN` button hit rect with its rendered rect and added a `HUB` button.
- Extended Perfect Dodge (`0.13s` window) from projectiles-only to all hostile boss attacks (melee lunges, bombs, beams, ground shockwaves, pulse rings, and multi-heart strikes).
- Added a particle cap (`140`) to protect mobile 60 FPS stability during dense multi-phase fights.

## Verification Status
- Static verification completed: all `res://` preloads, `scenes/main.tscn`, `project.godot`, bracket balance, GDScript 4 typing patterns, and ZIP archive integrity passed.
- Runtime verification NOT performed: no Godot 4.x executable was present in the build environment. Test in Godot 4.x desktop and Android before final balance tuning.
