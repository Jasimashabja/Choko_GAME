# CHOKO — Revised design bible (Phase 1 lock)

## High concept
**Choko** is a difficult, precision-focused 2D pixel-art boss rush. Choko is a boy trapped in his grandfather's vast underground coal quarry. There are no ordinary combat levels: the campaign is a chain of six handcrafted boss encounters, linked by short story transitions and the mine's service tunnels. Every boss arena is underground and visually/mechanically distinct.

The emotional core is Choko's attempt to escape with Farhan, the boy he loves. Farhan is not a disposable villain: the grandfather has manipulated him into guarding the route out. The first fight is a painful misunderstanding that resolves into an alliance after the duel.

## Story outline
1. **The shift:** Choko is forced to work in the quarry. He finds Farhan's old signal token and learns that the escape route is still possible.
2. **The sealed route:** Five locks/barriers protect the old freight lift. Each boss controls one section of the route, deliberately or because the grandfather has trapped them there.
3. **The truth:** The grandfather has been feeding the mine's ancient coal-heart with fear, memories, and the spirits of animals lost in the tunnels. The strange black growths are not ordinary coal.
4. **The betrayal:** After the grandfather falls, the coal-heart breaks open and reveals the secret sixth boss, **Dead Cat's Soul** — a single, spectral guardian formed from the mine's lost cats and the grief bound to the tunnels. It is eerie and sorrowful, not graphic.
5. **Escape:** With the coal-heart finally quiet, Choko and Farhan reach the old quarry airstrip. In the ending cutscene, they board the waiting small plane and fly away from the quarry. There is no outdoor boss fight; the airstrip appears only in the escape ending.

## Campaign order

| # | Boss | Underground arena identity | Fight identity |
|---|---|---|---|
| 1 | **Farhan** | Floodlit subterranean explosives depot with suspended cargo rails and blast shutters | Agile rival/lover; feints, timed bomb throws, delayed blast zones, quick close-range strings; vulnerable after committing to a bomb combo |
| 2 | **Allan** | Lightless root cathedral deep below the coal seam | A super-dark being who creates and controls glowing white plants; area denial, plant traps, creeping growth, light-management; coal can ignite fixed braziers to expose him |
| 3 | **John Paul** | Vertical drainage shaft and abandoned underground rail station | Cat-human hybrid; wall runs, pounces, fast claw strings, ricocheting yarn-like spirit orb; punish the recovery after a missed leap |
| 4 | **Aaron** | Fossil crypt built into an old mine tunnel | Skeleton; bone volleys, closing rib barriers, summoned bone-minions, reassembly; pickaxe bonus while disassembled |
| 5 | **Grandfather** | Buried chapel beneath the quarry, with a stained-glass window and a bell shaft | Three escalating forms: cane/cart/coal; corrupted giant with rising platforms and opening doors; collapsing rotating mine-shaft arena and final coal-versus-coal duel |
| 6 | **Dead Cat's Soul** (secret) | The sealed catacomb beneath the chapel, where abandoned mine tunnels meet the coal-heart | Uncanny multi-pattern encounter built around spectral silhouettes, echo decoys, and arena-wide pulse timing; the surprise is revealed only after the grandfather is defeated |

## Design constraints and quality targets
- **No standard enemy stages.** The main progression is six boss fights, short transitions, and the save-point room.
- **All six boss arenas are underground.** The chapel is buried below the quarry; the final airstrip is used only after the final victory.
- **Farhan throws bombs, never planes.** Bombs must have readable landing markers, fuse states, and blast boundaries. His moveset should mix ranged zoning with evasive movement and close-range feints so he feels like a skilled, emotionally conflicted rival rather than a stationary grenade turret.
- **Hard but fair.** Attacks are learnable and consistently telegraphed. Difficulty comes from overlapping patterns, spacing, resource pressure, and precise punish windows—not invisible hits or random unavoidable damage.
- **Player baseline retained:** five hearts; short hit invulnerability; three-hit pickaxe combo; limited arcing coal throws; exposed one-second mining; dodge roll with brief invulnerability and cooldown.
- **Coal is a tactical resource.** Mining is risky, boss stagger drops provide recovery opportunities, and some encounters use coal for light or arena interactions. Ammunition caps and drop timing will be tuned during playtests.
- **Mobile-first.** Landscape orientation, large touch targets, floating left joystick, right-side attack arc, adjustable opacity/size, optional nearest-boss aim, and a top-corner pause button.
- **Performance target:** stable 60 FPS on mid-range Android devices. Prefer lightweight 2D drawing, limited particles, pooled effects, and simple collision shapes. Avoid expensive full-screen effects and excessive dynamic lights.
- **Readability:** silhouette-first sprites, limited palette per arena, strong attack telegraphs, screen-shake restraint, and accessibility options for flash intensity and vibration.
- **Save behaviour:** save after each boss. On death, show the save-point room, attempt count, and best previous boss progress; retry restarts that boss from its beginning.

## Boss structure (locked for later implementation)
Each boss has three health phases. Phase thresholds and detailed HP/damage values will be tuned in Phase 3/4 playtests rather than guessed now. Every attack will be implemented as a state with:
- a visible wind-up/telegraph;
- an active hit window and explicit hitbox;
- recovery time or a punish opportunity;
- damage and knockback values stored in one balance resource;
- a unique response to phase transitions.

The grandfather is the hardest required boss. Dead Cat's Soul is a secret post-grandfather encounter and the final, most demanding fight. The surprise boss should feel like a new ruleset, not merely a larger health bar.

## Audio direction (placeholders for later)
- Farhan: restless chiptune breakbeat, dry snare, bright square-wave lead; bomb fuse tick, soft thud, warning chirp, layered blast.
- Allan: sparse low drones, detuned bells, icy arpeggio; root crack, thorn sweep, torch ignition, reveal shimmer.
- John Paul: quick staccato bass, playful but tense square lead; paw dash, claw swish, wall kick, bouncing orb.
- Aaron: hollow percussion, minor-key pulse, rattling metallic rhythm; bone toss, rib-wall scrape, reassembly clack.
- Grandfather: church-bell motif over heavy low pulse; each phase adds instruments and rhythmic layers; cane tap, cart rumble, coal impact, bell toll, arena fracture.
- Dead Cat's Soul: fragile music-box melody warped by reversed chiptune textures; spectral purr-like synth, echo chime, soul pulse, final silence hit.
- Ending: the main escape theme returns, now with a hopeful melody and engine/propeller rhythm.

## Art scale plan
- Choko and common props: 16×16 or 16×24 logical pixel sprites.
- Bosses: 32×32 to 64×64 logical sprites, with separate animation rows per state.
- Background tiles: 16×16; foreground hazards: 16×16 or 16×32.
- Boss portraits/cutscene art: 96×96 or 160×90 logical compositions.
- Import all pixel art with nearest filtering; avoid fractional sprite positions and non-integer scaling.

---

## Phase 2 implementation — playable control/combat sandbox (updated in Phase 2.3)

This phase replaces the title test with a self-contained training arena. The target in this scene is a **Quarry Sentinel training construct**, not the first story boss. The arena is now a grounded top-down chamber so four-direction movement and melee are mechanically real. The sentinel telegraphs escalating one-shot, three-shot and five-shot volleys so the player can test dodging and invulnerability without introducing Boss 1's mechanics prematurely.

### Implemented player systems
- 5-heart health display; practice resets automatically at zero hearts.
- Floating left-side touch joystick, with multi-touch support and four-direction ground-plane movement. Vertical joystick movement moves Choko across the floor; it is not a jump or flight input.
- Three-step pickaxe combo: 13 / 17 / 26 damage, short cooldown, cardinal-direction hit check and single-hit-per-swing protection.
- Coal throws with a visible drag-to-aim line. A short tap uses the Auto Aim setting; Auto Aim can be toggled by tapping the top-right HUD label or pressing T on a keyboard.
- Coal has a 12-piece capacity. The test starts with 5 pieces.
- Three mineable coal veins. Mining takes 1 second, roots the player in place, and grants 3 coal. Depleted veins return after 8 seconds.
- Dodge roll travels quickly and grants brief invulnerability, with a 1.05-second cooldown.
- Player damage grants 1.05 seconds of invulnerability. Mining is interrupted by damage.
- Hit-stop, screen shake, particles, damage flash, and haptic feedback on supported touchscreen devices.
- Keyboard fallback for desktop testing: WASD / arrows for four-direction floor movement, Space or J to pickaxe, K to throw, Shift or L to dodge, E to mine, T to toggle auto-aim, Escape to pause.

### Phase 2 balance values
| System | Value |
|---|---:|
| Logical viewport | 320 × 180 |
| Player hearts | 5 |
| Coal start / capacity | 6 / 12 |
| Mining duration / yield | 1.0 s / 3 coal |
| Pickaxe combo damage | 13 / 17 / 26 |
| Coal hit damage | 19 |
| Dodge duration / i-frames | 0.31 s |
| Dodge cooldown | 1.05 s |
| Damage i-frames | 1.05 s |

These are prototype tuning values, not final campaign balance. They will be adjusted during playtesting on the target phone.

### Current limitations / next phase
- Player and enemy sprites are procedural placeholder drawings; replace later with hand-authored pixel sprite sheets.
- The Quarry Sentinel is stationary and exists only to test core combat. Story-boss movement, bespoke boss state machines, campaign progression, and persistent save data are later phases.
- Audio files are not included yet. The next polish phases will add original chiptune tracks and sound effects.

### Phase 2.3 direction and camera decision
The player prototype uses a grounded top-down arena rather than a side-view floor lane. This was chosen so up, down, left and right are all valid movement and pickaxe directions. Moving the joystick upward or downward changes Choko's position on the ground plane; it never changes his elevation. The final campaign camera and boss arenas will retain this readability unless playtesting demonstrates a better control model.
