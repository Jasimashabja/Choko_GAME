# Phase 4.0 — Audio, Pixel-Art Presentation & Mobile UX Overhaul

## New Modules
- `scripts/audio_manager.gd`: Self-contained chiptune music looper (`finished`-signal looping) + 8-channel pooled SFX manager with live volume updates and `ResourceLoader.exists()` safety guards.
- `scripts/sprite_bank.gd`: Loads and caches all 8 pixel-art PNG sprite sheets and 8 `48×48` cutscene dialogue portraits, rendering pixel-snapped `draw_texture_rect_region` frames.

## New Assets
- **8 Original Chiptune Music Tracks (`assets/audio/music/*.wav`, 22050 Hz 16-bit mono):** `hub_mine`, `farhan`, `allan`, `john_paul`, `aaron`, `grandfather`, `dead_cat`, `escape_plane`.
- **22 Tactile SFX (`assets/audio/sfx/*.wav`, 22050 Hz 16-bit mono):** 3-hit pickaxe swings, Counter-Strike clang, coal throw/impact, mining tick/complete, dodge whoosh, Perfect Dodge chime, normal & heavy hurt, Posture Break shatter, delayed-attack Boss Glint ping, phase shift, boss defeated fanfare, bomb blast, brazier ignition, Grandfather bell toll, Dead Cat chime, UI select/confirm.
- **8 Pixel-Art Sprite Sheets (`assets/sprites/*_sheet.png`):** Choko (`96×96`, 4 directions × 4 animation columns), Farhan, Allan, John Paul, Aaron, Grandfather (`192×48` elderly across all 3 phases), The Dead Cat, and Quarry Sentinel.
- **8 Pixel-Art Cutscene Portraits (`assets/sprites/portraits/portrait_*.png`, `48×48`):** Choko, Farhan, Allan, John Paul, Aaron, Grandfather, The Dead Cat, and Quarry Sentinel.

## UX, Settings & Mastery Additions
- Added full **Settings & Accessibility** screen accessible from both Hub (`SETTINGS`) and Pause (`SETTINGS`): Music Volume, SFX Volume, Touch Opacity, Touch Button Scale (scales drawn & touch-detection radii), Screen Shake, Hit Flash Intensity, and Haptics toggle.
- Added per-boss **Mastery Tracking** persisted in `user://choko_save.json`: best clear time (`s`), No-Hit Crown (`★`), and best Perfect Dodge count displayed on Hub cards and Victory headers.
- All Phase 2.5 / 3.1.1 mechanics, canon constraints, and Godot 4.7.2 strict typing fixes are preserved.

## Verification
- Static verification passed across all 8 GDScript files, `project.godot`, `scenes/main.tscn`, 16 PNGs, 30 WAVs, cross-module symbols, and ZIP integrity (`0` errors, `0` warnings).
- **Not runtime-tested:** No Godot executable was present in the build environment.
