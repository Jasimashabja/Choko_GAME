# Phase 2.5 — Precision Combat Feel Pass

## Player-facing changes
- Added a 0.13-second Perfect Dodge timing window at the beginning of each dodge roll.
- A hostile projectile that intersects Choko during that window triggers a Perfect Dodge, awards +1 coal up to the 12-coal cap, and increments the run counter.
- Ordinary dodge invulnerability and post-hit invulnerability still avoid damage, but no longer grant a false PARRY label or reward.
- Added a short cyan timing arc, a HUD count, and a brief tutorial hint.
- Added restrained hit-stop, particles, and haptics to make the timing reward readable without obscuring the arena.

## Design constraints preserved
- Four-direction grounded movement and attacks remain unchanged.
- Vertical joystick input remains floor-plane movement; it is not a jump or flight control.
- The respawn laptop/brainrot scene and hidden Dead Cat story-design notes are retained.
- The Dead Cat's identity, appearance, and relationship to John Paul remain unresolved pending the creator's direction.

## Verification
- Source and project files were inspected and the output ZIP was checked for archive integrity and expected files.
- A Godot executable was not available in this environment, so this build has not been runtime-tested in the Godot editor or on an Android device.
