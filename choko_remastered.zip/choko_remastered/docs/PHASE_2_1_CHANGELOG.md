# Phase 2.1 — Visual and feel pass

This update responds to the first Android playtest. The earlier build was functional but read as a debug room. This pass improves composition, hierarchy, atmosphere, and combat readability while preserving the same player-system scope.

## Art direction
- Palette: coal-black navy, smoky violet stone, ember amber and spectral cyan.
- Composition: a deep tunnel mouth creates a focal point behind the sentinel; wooden and metal supports frame the room; the rail trench and mine cart communicate the coal-mining setting.
- Lighting: three warm lantern pools contrast with the cold cyan sentinel core.
- Character: Choko's coat, scarf, satchel, miner's clip lamp and pickaxe are now more legible at the 320×180 resolution.
- Target: a cracked stone sentinel with a charged core replaces the generic rectangular dummy.

## UX and readability
- Top strip separates player health, coal and aim mode from the encounter bar.
- Action controls use unique icons and smaller, consistent circular plates.
- Contextual mine button appears only when an active seam is in range.
- Roll cooldown meter is visible below the roll button.
- Pause opens a panel with Resume and Restart Room hit areas.

## Feel
- Combo callouts distinguish the third, heavier hit.
- Damage and mining rewards use floating text.
- Hit-stop and screen shake are stronger on the finisher.
- Sentinel wind-up shows its target point and lock-on line before the projectile launches.
- Dodge creates an afterimage and can avoid the sentinel pulse.

## Still planned
Final hand-authored Choko and boss sprite sheets, frame-by-frame animation, per-boss backgrounds, original music, sound design, menu art, options, campaign save data and the boss framework remain future phases. This update intentionally avoids presenting procedural drawing as finished production art.
