# Phase 4.2 — STORY / BOSSES / SETTINGS Architecture & High-Craft Visual Overhaul

## Major Additions
- **Dedicated Animated Title Menu (`STORY` | `BOSSES` | `SETTINGS`):** Replaced the single crowded Hub with an atmospheric underground quarry Title Screen (`assets/arenas/title_quarry.png` + live swaying lanterns, volumetric light cones, rising embers, and animated Choko) branching cleanly into **STORY**, **BOSSES**, and **SETTINGS**.
- **STORY Campaign Screen & Prologue Cutscene ("THE SHIFT"):** Added a visual underground route map across all 5 main shafts + hidden Dead Cat branch, chapter portrait & story summary cards, and the playable opening Story Prologue where Choko discovers Farhan's brass signal token.
- **BOSSES & Practice Select Screen:** Dedicated Boss Rush selector featuring ornate `96×96` portraits, HP/Posture stats, Mastery Crowns (`★ NO-HIT`, Best Time, Best PD), mechanic hints, and the explicitly non-campaign Quarry Sentinel practice construct.
- **Upgraded SETTINGS & Accessibility:** Added an 8th toggle — **Hitbox Debug Overlay (`F3`)** — alongside Music/SFX Volume, Touch Opacity/Scale, Screen Shake, Hit Flash, and Haptics.

## Background Elements & Visual Quality Overhaul
- **Official Godot 4 Nearest-Neighbor Path:** Switched `project.godot` to `textures/canvas_textures/default_texture_filter=0` (keeping `640×360` `canvas_items` HD text scaling) and added `.editorconfig` / `.gitattributes`.
- **Upgraded All 7 `640×360` Underground Arena PNGs + `title_quarry.png`:** Added deeper vertical cavern gradients, beveled flagstone grout/highlights, wall ambient occlusion shadows, volumetric light beams, and depth vignettes.
- **Rich Live Animated Arena Elements:** Added swaying chains, swinging volumetric mine lanterns, animated drainage water drips & puddle ripples (John Paul), swaying glowing white flora (Allan), rising welding embers (Farhan), glowing skull alcoves (Aaron), stained-glass light shafts (Grandfather), floating cyan wisps (Dead Cat), and Choko running boot dust puffs.

## Verification
- Static verification passed: 8 scripts, 24 PNGs, 30 WAVs, `project.godot`, `scenes/main.tscn`, cross-module symbols, Godot 4.7.2 strict typing, and ZIP archive integrity (`0` errors, `0` warnings).
- Runtime execution in Godot 4.x was not performed because no Godot binary is installed in this environment.
