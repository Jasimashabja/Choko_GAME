# Phase 4.4 — Nightmare Souls-Like Boss AI & Attack Style Overhaul

## Core AI & Difficulty Systems
- **Predictive Lead Aiming:** `main.gd` now computes `player_vel` and passes it to `boss.update()`, enabling bosses to lead bombs, projectiles, pounces, and ground traps ahead of Choko's movement vector.
- **Relentless Multi-Attack Combo Chains:** Added `combo_chain_left` so bosses chain 2–3 attacks seamlessly across Phases 1–3 before entering shorter, earned punish recovery windows.
- **Per-Boss Anti-Greed Retaliations:** Landing 3+ consecutive melee hits outside a `staggered` Riposte triggers a fast `0.36s` glint-telegraphed counter burst unique to each boss (dodgeable into a Perfect Dodge → Counter-Strike!).
- **New Delayed Slash-Line Hazard (`slash_lines`):** Added full simulation and neon/spectral cut-line rendering for John Paul's X-Slash Claw Rifts, Aaron's Center Bone Lance, and Dead Cat's Phantom Cross-Blink Slashes.
- **Souls-Like Balance Tuning:** Boss HP raised (`Farhan 390`, `Allan 430`, `John Paul 450`, `Aaron 480`, `Grandfather 620`, `Dead Cat 560`), Posture raised (`125–170`) with faster drain, roll cooldown tightened to `0.88s` for aggressive dodge chaining, post-hit i-frames set to `0.88s` (`1.0s` on heavy hits), coal vein respawn set to `10.5s`, and Perfect Dodge Posture reward increased to `+22`.

## Verification
- Static audit passed across all 8 GDScript files, 24 PNGs, 32 WAVs, `project.godot`, `scenes/main.tscn`, cross-module symbols, strict Godot 4.7.2 typing, and ZIP integrity (`0` errors, `0` warnings).
- Runtime testing NOT performed in this environment (no Godot executable available).
