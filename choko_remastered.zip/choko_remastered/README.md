# Choko - Remastered (Phase 4.5 — Android APK Ready)

> **Phone-Only APK Build Included:** See `ANDROID_APK_GUIDE.md` for step-by-step instructions to build `choko-remastered.apk` directly from your phone browser via GitHub Actions (`.github/workflows/build-apk.yml` + `export_presets.cfg`).

# CHOKO — Phase 4.5: Easy / Nightmare Modes & Overhauled Boss Encounters

Phase 4.5 builds directly on Phase 4.4 without restarting. It adds a full **EASY / NIGHTMARE** difficulty toggle (accessible on the Title Screen, Bosses Screen, and Settings menu, saved automatically) and overhauls all six underground boss encounters with rewritten iconic intro/victory dialogues, live mid-fight Phase 2 & Phase 3 portrait speech callouts, and storytelling arena props.

Self-contained offline Godot 4.x project (`640×360` `canvas_items` HD crisp text + `textures/canvas_textures/default_texture_filter=0` nearest-neighbor pixel art, `gl_compatibility` mobile renderer).

## Import on Android / Desktop
1. Extract this ZIP into a new folder.
2. Open Godot Project Manager → **Import**.
3. Select this folder's `project.godot`.
4. Let Godot finish importing the PNG sprites/arenas and WAV audio files, then press **Play**.

## What Changed in Phase 4.5
- **EASY & NIGHTMARE Difficulty Modes:**
  - Switch instantly on the **Title Screen** (`DIFFICULTY` pill right above `STORY`, or press `M`), on the **Bosses Screen** top bar, or Row 1 of **Settings** (persisted in `user://choko_save.json`).
  - **NIGHTMARE Mode (Default):** Full Souls-like intensity — `390–620` Boss HP, `125–170` Posture, predictive velocity lead-aim (`1.0x`), 2–3 attack combo chains, per-boss Anti-Greed Retaliations after 3 melee hits, full `2♥` and rare `3♥` strikes, `0.13s` Perfect Dodge window, `0.88s` dodge cooldown, `10.5s` coal vein respawn.
  - **EASY Mode:** Accessible & forgiving while keeping every boss mechanic — `65%` Boss HP, `75%` Posture with `50%` slower drain, single-attack cadence (no relentless chaining) + `1.38x` longer punish recovery, **no** Anti-Greed Retaliations, gentler `0.35x` lead-aim, `0.80x` projectile speed, `1.22x` longer telegraphs, **damage capped (`2♥ → 1♥`, `3♥ → 2♥`)**, `8` starting coal, `6.5s` vein respawn, `0.18s` Perfect Dodge window, `0.72s` roll cooldown, and `1.28s–1.35s` hit i-frames.
- **Overhauled Boss Encounter Lines & Live Mid-Fight Phase Banter:**
  - Every boss now features polished iconic opening dialogues, victory beats, AND live **mid-fight Phase 2 & Phase 3 portrait callout banners**:
    1. **Farhan:** *"Stop right there, Choko. I cannot let you leave, my love—we will always be together down here in this dungeon!"* (+ flashing blast-shutter lock seals in P2/P3).
    2. **Allan:** *"Step no closer, little miner. I will protect my cotton at all costs! Grandfather—lend me your darkness!"* (+ drifting glowing white cotton fluff tufts across the cathedral).
    3. **John Paul:** *"You just kicked the grate open and interrupted my kitten business, Choko... Now you will feel the wrath of the Mighty Shaji Kitten!"* (+ golden-cyan Shaji Kitten aura shimmer in P2/P3).
    4. **Aaron:** *"You have got some nerve, boy. You just interrupted my love life with Steve!"* (+ a flickering romantic candlelit stone slab in the crypt background for Steve's ruined date night!).
    5. **Grandfather** *(visibly elderly in all 3 phases)*: *"Going somewhere, Choko? You will never leave this dungeon—you will mine coal for my heaters forever!"* (+ glowing cast-iron coal heater grates along the chapel wall that roar hotter in P2/P3).
    6. **The Dead Cat / Ghost Cat** *(hidden post-Grandfather; connection to John Paul remains unconfirmed)*: *"I have waited beneath the chapel in the dark... I will take my revenge for the murder you committed upon me!"*

## Verification & Known Limits
- All 8 GDScript files, `project.godot`, `scenes/main.tscn`, 24 PNGs, 32 WAV audio files, cross-module symbols, strict Godot 4.7.2 typing, and ZIP integrity were statically verified (`0` errors, `0` warnings).
- **Not runtime-tested:** No Godot executable is available in this environment, so live Godot 4.7.2 execution and Android playtesting have not yet been performed.
