Phase 4.0 original self-contained chiptune music loops (22050 Hz, 16-bit mono WAV):
- hub_mine.wav (Hub & Quarry Sentinel practice ambience)
- farhan.wav (Restless breakbeat & rival square lead)
- allan.wav (Sparse sub-drone, detuned bells, creeping Phrygian arpeggio)
- john_paul.wav (Staccato bass, tense feline square lead, syncopated hats)
- aaron.wav (Hollow bone-click percussion & rattling minor ostinato)
- grandfather.wav (Church-bell motif over heavy pounding chords)
- dead_cat.wav (Fragile music-box melody & reverse-envelope swells)
- escape_plane.wav (Hopeful major escape theme over warm prop-plane thrum)
