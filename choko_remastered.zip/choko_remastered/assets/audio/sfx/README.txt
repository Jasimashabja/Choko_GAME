Phase 4.3 synthesized 16-bit mono WAV combat, boss & cutscene SFX (24 files):
pickaxe_1, pickaxe_2, pickaxe_finisher, counter_strike, coal_throw, coal_impact,
mine_tick, mine_complete, dodge_whoosh, perfect_dodge, player_hurt, heavy_hurt,
posture_break, boss_glint, phase_shift, boss_defeated, bomb_blast, brazier_light,
bell_toll, dead_cat_chime, text_blip, shaft_transition, ui_select, ui_confirm.
