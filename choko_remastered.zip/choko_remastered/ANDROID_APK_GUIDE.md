# How to Build `Choko - Remastered` APK Using Only Your Phone

This project includes a pre-configured `export_presets.cfg`, custom Android launcher icons (`assets/icon_192.png` + adaptive icons), and a free cloud GitHub Actions builder (`.github/workflows/build-apk.yml`).

## Step-by-Step (Phone Browser Only — ~3 Minutes)
1. **Extract this ZIP** on your phone so you can see the folder `choko_remastered/`.
2. **Create a free GitHub account & new repository** in your phone browser (`github.com` → **+** → **New repository**, e.g. `choko-remastered`, Private or Public → **Create repository**).
3. **Upload the project files** to your repository:
   - Make sure the `.github/workflows/build-apk.yml` file is placed at `.github/workflows/build-apk.yml` in the root of your repository (GitHub only detects workflows inside the root `.github/workflows/` folder).
   - *Phone tip:* If GitHub's mobile web upload skips hidden dot-folders like `.github`, upload everything else first, then tap **Add file → Create new file**, type `.github/workflows/build-apk.yml` as the filename, and paste the contents of `build-apk.yml` from this ZIP!
4. **Run the Cloud Build:**
   - Open the **Actions** tab on your GitHub repo.
   - If the build didn't start automatically on push, tap **Build Choko - Remastered Android APK → Run workflow → Run workflow**.
   - Wait ~2–3 minutes for the green checkmark.
5. **Download & Install the APK:**
   - Tap the finished green workflow run.
   - Scroll down to **Artifacts** and tap **`Choko-Remastered-APK`** to download it.
   - Unzip the downloaded artifact on your phone to get **`choko-remastered.apk`**.
   - Tap **`choko-remastered.apk`**, allow **Install unknown apps** if prompted, and install **`Choko - Remastered`**!

## App Details Included
- **App Name:** `Choko - Remastered`
- **Package ID:** `com.choko.remastered`
- **Architectures:** `arm64-v8a` + `armeabi-v7a` (installs on both 64-bit and 32-bit Android phones)
- **Orientation:** Landscape + Immersive Fullscreen Mode
- **Permissions:** Vibrate only (for combat & Perfect Dodge haptics; zero internet/camera/location permissions)
